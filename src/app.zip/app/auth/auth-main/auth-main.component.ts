import { Component, OnInit } from '@angular/core';
import { HttpRequestComponent } from 'src/app/provider/http-request/http-request.component';
import { TokenStorageService } from '../auth/token-storage.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-auth-main',
  templateUrl: './auth-main.component.html',
  styleUrls: ['./auth-main.component.scss']
})
export class AuthMainComponent implements OnInit {

  request: any = {};
    private roles: string[];
    private authority: string;
    
    constructor(private http: HttpRequestComponent, private tokenStorage: TokenStorageService, private token: TokenStorageService, private router: Router) {
    }

    getResult(item){
      console.log(item);
    }

    getDeathDetails(result){
  this.request= result;
  console.log(this.request);
    }

    ngOnInit() {
      if (this.tokenStorage.getToken()) {
        this.roles = this.tokenStorage.getAuthorities();
        this.roles.every(role => {
          if (role === 'ROLE_ADMIN') {
            this.authority = 'admin';
            return false;
          } else if (role === 'ROLE_PM') {
            this.authority = 'pm';
            return false;
          }
          this.authority = 'user';
          return true;
        });
      }
    }

    
  logout() {
    this.token.signOut();
    window.location.reload();
    this.router.navigate(['/auth/login']);
  }

}
