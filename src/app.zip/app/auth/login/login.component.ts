import { Component, OnInit } from '@angular/core';

import { AuthService } from '../auth/auth.service';
import { TokenStorageService } from '../auth/token-storage.service';
import { AuthLoginInfo } from '../auth/login-info';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login-auth',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponentAuth implements OnInit {
  form: any = {};
  isLoggedIn = false;
  isLoginFailed = false;
  errorMessage = '';
  roles: string[] = [];
  private loginInfo: AuthLoginInfo;

  registered = true;
  authority: string;
 
  constructor(private authService: AuthService, private tokenStorage: TokenStorageService, private router: Router) { }

  ngOnInit() {
    if (this.tokenStorage.getToken()) {
      this.isLoggedIn = true;
      this.roles = this.tokenStorage.getAuthorities();
    }
  }

  onSubmit() {
    console.log(this.form);

    this.loginInfo = new AuthLoginInfo(
      this.form.username,
      this.form.password);

    this.authService.attemptAuth(this.loginInfo).subscribe(
      data => {
        this.tokenStorage.saveToken(data.accessToken);
        this.tokenStorage.saveUsername(data.username);
        this.tokenStorage.saveAuthorities(data.authorities);

        this.isLoginFailed = false;
        this.isLoggedIn = true;
        this.roles = this.tokenStorage.getAuthorities();
        this.reloadPage();
      },
      error => {
        console.log(error);
        this.errorMessage = error.error.message;
        this.isLoginFailed = true;
      }
    );
  }

  reloadPage() {
    window.location.reload();
  }
  continue(){

    // for( string role : this.roles)
    // {
    //   switch(role) { 
    //     case : { 
    //        //statements; 
    //        break; 
    //     } 
    //     case : { 
    //        //statements; 
    //        break; 
    //     } 
    //     default: { 
    //        //statements; 
    //        break; 
    //     } 
    //  }
    // }

  //   if (this.tokenStorage.getToken()) {
  //     this.roles = this.tokenStorage.getAuthorities();
  //   for (let role in this.roles) {
  //     if (role === 'ROLE_ADMIN') {
  //       this.router.navigate(['/admin']);
  //     } 
  //     else if (role === 'ROLE_PM') {
  //       this.router.navigate(['/signed']);
  //     }
  //     else if (role === 'ROLE_USER') {
  //       this.router.navigate(['/user']);
  //     }
  //     console.log(role)
  //  }
  // }

  if (this.tokenStorage.getToken()) {
    this.roles = this.tokenStorage.getAuthorities();
    this.roles.every(role => {
      if (role === 'ROLE_ADMIN') {
        this.authority = 'admin';
        this.router.navigate(['/admin']);
        return false;
      } else if (role === 'ROLE_PM') {
        this.authority = 'pm';
        this.router.navigate(['/pm']);
        return false;
      }
      this.authority = 'user';
      this.router.navigate(['/user']);
      return true;
    });
  }
}
}
