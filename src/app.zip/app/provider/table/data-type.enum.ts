export enum DataType {
    Plain,
    Date,
    Selection,
    Check,
    CheckAndMessage,
    Image,
    Money
}