export enum MortuaryProcesses{
    Arrival = 1,
    PostMortem,
    Collection
}