import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CaptureDeathInformationComponent } from './capture-death-information.component';

describe('CaptureDeathInformationComponent', () => {
  let component: CaptureDeathInformationComponent;
  let fixture: ComponentFixture<CaptureDeathInformationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CaptureDeathInformationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CaptureDeathInformationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
