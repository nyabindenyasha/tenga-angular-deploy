import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Deceased } from '../../../../model/mortuary/deceased';
import { Validation } from 'src/app/provider/validation/validation';
import { ValidationType } from 'src/app/provider/validation/validation-type.enum';
import { Doctor } from 'src/app/model/mortuary/doctor';
import { HttpRequestComponent } from 'src/app/provider/http-request/http-request.component';


@Component({
  selector: 'app-capture-death-information',
  templateUrl: './capture-death-information.component.html',
  styleUrls: ['./capture-death-information.component.scss']
})
export class CaptureDeathInformationComponent implements OnInit {
  validation: Validation;
  doctors: Doctor[];
  @Input() deceased: Deceased;
  @Input() step: any;
  @Output() result: EventEmitter<any> = new EventEmitter<Deceased>();
  @Output() backWizard = new EventEmitter<any>();

  constructor(private http: HttpRequestComponent) {
    this.http.get('hospitalmanagement/doctors', (doctors) => this.doctors = doctors)
  }

  ngOnInit() {
    if (this.deceased == null)
      this.deceased = new Deceased();
    this.loadValidation();
  }

  loadValidation() {
    this.validation = new Validation();
    this.validation.addField({ name: 'dateOfDeath', display: 'Date of Death', type: ValidationType.Date },  new Date(this.deceased.dateOfDeath).getTime());
    this.validation.addField({ name: 'location', display: 'Location of Death', type: ValidationType.Required });
    this.validation.addField({ name: 'doctorId', display: 'Doctor', type: ValidationType.Required });

  }

  next() {
    this.result.emit(this.deceased);
  }
  
  prev(){
    this.step--;
    this.backWizard.emit(this.step)
  }
  getDate(value){
    this.loadValidation();
  }
}