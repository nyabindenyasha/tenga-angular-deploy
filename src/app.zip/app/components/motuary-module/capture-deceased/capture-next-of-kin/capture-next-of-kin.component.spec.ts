import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CaptureNextOfKinComponent } from './capture-next-of-kin.component';

describe('CaptureNextOfKinComponent', () => {
  let component: CaptureNextOfKinComponent;
  let fixture: ComponentFixture<CaptureNextOfKinComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CaptureNextOfKinComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CaptureNextOfKinComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
