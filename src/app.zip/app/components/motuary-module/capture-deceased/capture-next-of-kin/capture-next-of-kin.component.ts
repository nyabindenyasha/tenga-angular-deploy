import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';
import { Validation } from 'src/app/provider/validation/validation';
import { ValidationType } from 'src/app/provider/validation/validation-type.enum';
import { Deceased } from 'src/app/model/mortuary/deceased';
import { HttpRequestComponent } from 'src/app/provider/http-request/http-request.component';
import { TableCompose } from 'src/app/provider/table/table-compose';
import { Relationship } from 'src/app/model/mortuary/relationship';
import { NextOfKin } from 'src/app/model/mortuary/nextOfKin';
import { HttpBackend } from '@angular/common/http';

@Component({
  selector: 'app-capture-next-of-kin',
  templateUrl: './capture-next-of-kin.component.html',
  styleUrls: ['./capture-next-of-kin.component.scss']
})
export class CaptureNextOfKinComponent implements OnInit {
  @Input() step: any;
  @Input() deceased: Deceased
  @Output() result: EventEmitter<any> = new EventEmitter<Deceased>();
  @Output() backWizard = new EventEmitter<any>();
  validation: Validation;
  tableData: TableCompose;
  relationships: Relationship[];

  constructor(private http: HttpRequestComponent) {
    this.http.get('/hospitalmanagement/relationship', (relationship) => this.relationships = relationship);
  }

  ngOnInit() {
    if (this.deceased.nextOfKin == null)
      this.deceased.nextOfKin = new NextOfKin();
    this.loadValidation();
  }

  loadValidation() {
    this.validation = new Validation();
    this.validation.addField({ name: 'fullName', display: 'First Name', type: ValidationType.Required });
    this.validation.addField({ name: 'contactInfo', display: 'Address', type: ValidationType.Required });
    this.validation.addField({ name: 'relationshipId', display: 'Relationship', type: ValidationType.Required });

  }

  next() {
    this.result.emit(this.deceased)
  }
  
  prev(){
    this.step--;
    this.backWizard.emit(this.step)
  }
}