import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Deceased } from '../../../../model/mortuary/deceased';
import { Validation } from 'src/app/provider/validation/validation';
import { ValidationType } from 'src/app/provider/validation/validation-type.enum';
import { HttpRequestComponent } from 'src/app/provider/http-request/http-request.component';
import { Observable, forkJoin } from 'rxjs';
import { Gender } from 'src/app/model/mortuary/gender';
import { Race } from 'src/app/model/mortuary/race';
import { log } from 'util';

@Component({
  selector: 'app-capture-personal-information',
  templateUrl: './capture-personal-information.component.html',
  styleUrls: ['./capture-personal-information.component.scss']
})
export class CapturePersonalInformationComponent implements OnInit {
  @Input() deceased: Deceased;
  @Input() step;
  @Output() result: EventEmitter<any> = new EventEmitter<Deceased>();
  @Output() backWizard = new EventEmitter<any>();

  public genderTypes: any;
  public raceTypes: any;
  validation: Validation;
  constructor(  private http:HttpRequestComponent) { 
    this.http.get('hospitalmanagement/deceaseddetails/race', (races) => this.getRace(races)),
    this.http.get('hospitalmanagement/deceaseddetails/gender', (genders) => this.getGender(genders))
  }

  ngOnInit() {
    if (this.deceased == null)
      this.deceased = new Deceased();
    this.loadValidation();
  }

  loadValidation() {
    this.validation = new Validation();
    this.validation.addField({ name: 'firstName', display: 'First Name', type: ValidationType.Required });
    this.validation.addField({ name: 'lastName', display: 'Last Name', type: ValidationType.Required });
    this.validation.addField({ name: 'genderId', display: 'Gender', type: ValidationType.Required });
    this.validation.addField({ name: 'dateOfBirth', display: 'Date Of Birth', type: ValidationType.Date }, new Date(this.deceased.dateOfBirth).getTime());
    this.validation.addField({ name: 'raceId', display: 'Race', type: ValidationType.Required });
    this.validation.addField({ name: 'plce_of_birth', display: 'Place of birth', type: ValidationType.Required });
    this.validation.addField({ name: 'identificationnumber', display: 'National ID Number', type: ValidationType.Required });
  }

  getGender(genders:  Gender) {
    this.genderTypes = genders;
    
  }
  
  getRace(races:  Race) {
    this.raceTypes = races;    
  }

  next() {
    this.result.emit(this.deceased);
  }

  prev(){
    this.step--;
    this.backWizard.emit(this.step)
  }

  getDate(value){
    this.loadValidation();
  }
}