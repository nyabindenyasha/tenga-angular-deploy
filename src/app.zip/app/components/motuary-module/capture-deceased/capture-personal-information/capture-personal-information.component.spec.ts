import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CapturePersonalInformationComponent } from './capture-personal-information.component';

describe('CapturePersonalInformationComponent', () => {
  let component: CapturePersonalInformationComponent;
  let fixture: ComponentFixture<CapturePersonalInformationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CapturePersonalInformationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CapturePersonalInformationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
