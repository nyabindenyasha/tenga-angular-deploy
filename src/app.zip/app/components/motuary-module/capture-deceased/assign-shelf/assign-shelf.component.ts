import { Component, OnInit, Input } from '@angular/core';
import { TableCompose } from 'src/app/provider/table/table-compose';
import { HttpRequestComponent } from 'src/app/provider/http-request/http-request.component';
import { DataType } from 'src/app/provider/table/data-type.enum';
import swal from 'sweetalert2';
import { Output, EventEmitter } from '@angular/core';
import { Deceased } from 'src/app/model/mortuary/deceased';
import { MortuaryShelf } from 'src/app/model/mortuary/mortuary-shelf';
import { Gender } from 'src/app/model/mortuary/gender';
import { Race } from 'src/app/model/mortuary/race';


@Component({
  selector: 'app-assign-shelf',
  templateUrl: './assign-shelf.component.html',
  styleUrls: ['./assign-shelf.component.scss']
})
export class AssignShelfComponent implements OnInit {
  @Input() deceased: Deceased;
  @Input() step: any;
  @Output() result = new EventEmitter<Deceased>();
  @Output() backWizard = new EventEmitter<any>();
  shelves: MortuaryShelf[] = [];
  Gender: Gender[];
  deceasedGender: Gender[];

  constructor(private http: HttpRequestComponent) {
    this.http.get('/hospitalmanagement/deceaseddetails/gender', (gender)=> this.getGender(gender));
    this.getShelves();
  }
  ngOnInit() {
    this.http.get('/hospitalmanagement/deceaseddetails/race/' +this.deceased.raceId, (race)=> this.getRace(race));
  }
  next() {
    this.deceased.shelf = this.shelf;
    this.result.emit(this.deceased);
  }

  getShelves() {
    this.http.get('/shelves/getAll', (shelves) => this.loadShelvesTable(shelves));
  }
  itemClick(shelf) {
    this.formData = new TableCompose()
      .composeHeader('shelfNumber', 'Shelf Number', DataType.Plain)
      .composeHeader('description', 'Description', DataType.Plain)
      .composeHeader('isActive', 'Active', DataType.Check)
      .setBody(this.shelves.filter(s => s.isOccupied));
    this.shelf = shelf;
    this.deceased.shelf = this.shelf;
  }

  tableData: TableCompose;
  formData: TableCompose;
  shelf: MortuaryShelf;
  loadShelvesTable(shelves: MortuaryShelf[]) {
    this.shelves = shelves;
    this.tableData = new TableCompose()
      .composeHeader('shelfNumber', 'Shelf Number', DataType.Plain)
      .composeHeader('isActive', 'Active', DataType.Check)
      .setBody(this.shelves.filter(s => s.isOccupied == false));
  }

  prev(){
    this.step--;
    this.backWizard.emit(this.step)
  }

  getGender(gender: Gender[]){
    this.Gender = gender;
    this.deceasedGender = this.Gender.filter(gen=> gen.genderId == this.deceased.genderId);
    this.deceased.genderName = this.deceasedGender[0].genderDescription;
  }

  getRace(race: Race){
    this.deceased.race = race.raceName;
  }
}