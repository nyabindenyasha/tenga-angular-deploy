import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AssignShelfComponent } from './assign-shelf.component';

describe('AssignShelfComponent', () => {
  let component: AssignShelfComponent;
  let fixture: ComponentFixture<AssignShelfComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AssignShelfComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AssignShelfComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
