import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { TableCompose } from 'src/app/provider/table/table-compose';
import { Deceased } from 'src/app/model/mortuary/deceased';
import { DataType } from 'src/app/provider/table/data-type.enum';
import swal from 'sweetalert2';
import { HttpRequestComponent } from 'src/app/provider/http-request/http-request.component';

@Component({
  selector: 'app-confirm-information',
  templateUrl: './confirm-information.component.html',
  styleUrls: ['./confirm-information.component.scss']
})
export class ConfirmInformationComponent implements OnInit {
  formData: TableCompose;
  @Input() deceased: Deceased;
  @Output() emitter = new EventEmitter<any>();
  step: any;
  @Output() backWizard = new EventEmitter<any>();
  constructor(private http: HttpRequestComponent) { }

  ngOnInit() {
    this.loadFormData();
  }

  loadFormData() {
    this.formData = new TableCompose()
      .composeHeader('firstName', 'First Name', DataType.Plain)
      .composeHeader('lastName', 'Last Name', DataType.Plain)
      .composeHeader('genderName', 'Gender', DataType.Plain)
      .composeHeader('dateOfDeath', 'Date of Death', DataType.Date)
      .composeHeader('location', 'Place of Death', DataType.Plain)
      .composeHeader('race', 'Race', DataType.Plain)
      .composeHeader('identificationnumber', 'Identity Number', DataType.Plain)
      .composeHeader('shelf', 'Shelf', DataType.Selection, 'shelfNumber')
  }

  submit() {
    this.deceased.shelf.isOccupied = true;  
      this.http.put('shelves/update/' +this.deceased.shelf.shelfNumber, this.deceased.shelf, (result)=> this.addDeceased(result)) 
  }

  addDeceased(result: any){
    this.deceased.processId = 1;
    this.http.post('hospitalmanagement/deceaseddetails/deceased/add', this.deceased, (result) => {  
      swal(result.message);
      this.emitter.emit(this.deceased);
    }); 
  }

  prev(){
    this.step--;
    this.backWizard.emit(this.step)
  }
}