import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CaptureDeceasedComponent } from './capture-deceased.component';

describe('CaptureDeceasedComponent', () => {
  let component: CaptureDeceasedComponent;
  let fixture: ComponentFixture<CaptureDeceasedComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CaptureDeceasedComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CaptureDeceasedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
