import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CaptureInstructionsComponent } from './capture-instructions.component';

describe('CaptureInstructionsComponent', () => {
  let component: CaptureInstructionsComponent;
  let fixture: ComponentFixture<CaptureInstructionsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CaptureInstructionsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CaptureInstructionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
