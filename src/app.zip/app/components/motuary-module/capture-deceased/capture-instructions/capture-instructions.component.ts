import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { Deceased } from 'src/app/model/mortuary/deceased';
import { Router } from '@angular/router';

@Component({
  selector: 'app-capture-instructions',
  templateUrl: './capture-instructions.component.html',
  styleUrls: ['./capture-instructions.component.scss']
})
export class CaptureInstructionsComponent implements OnInit {
  @Output() result: EventEmitter<any> = new EventEmitter<any>();
  constructor() { }

  ngOnInit() {
  }

  start() {
    var deceased: Deceased = new Deceased();
    this.result.emit(deceased);
  }
}
