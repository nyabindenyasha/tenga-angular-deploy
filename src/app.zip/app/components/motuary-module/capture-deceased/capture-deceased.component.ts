import { Component, OnInit, Input } from '@angular/core';
import { Deceased } from 'src/app/model/mortuary/deceased';
import { Router } from '@angular/router';

@Component({
  selector: 'app-capture-deceased',
  templateUrl: './capture-deceased.component.html',
  styleUrls: ['./capture-deceased.component.scss']
})
export class CaptureDeceasedComponent implements OnInit {
  @Input() body : Deceased;
  step: number = 0;
  constructor(private router: Router) { }

  ngOnInit() {
  }

  next() {
      this.step++;
  }

  prev() {
    if (this.step > 0)
      this.step--;
  }

  deceased: Deceased;
  loadResult($event) {
    this.deceased = $event;
    this.next();
  }

  viewDeceased(deceased){
    this.step = 0
    this.router.navigateByUrl('mortuary/autopsy')
  }
}