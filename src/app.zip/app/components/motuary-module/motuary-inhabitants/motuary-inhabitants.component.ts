import { Component, OnInit } from '@angular/core';
import { TableCompose } from 'src/app/provider/table/table-compose';
import { HttpRequestComponent } from 'src/app/provider/http-request/http-request.component';
import { DataType } from 'src/app/provider/table/data-type.enum';
import { Deceased } from 'src/app/model/mortuary/deceased';


@Component({
  selector: 'app-motuary-inhabitants',
  templateUrl: './motuary-inhabitants.component.html',
  styleUrls: ['./motuary-inhabitants.component.scss']
})
export class MotuaryInhabitantsComponent implements OnInit {
  constructor(private http: HttpRequestComponent) {
    
  }

  ngOnInit() {
  }
}