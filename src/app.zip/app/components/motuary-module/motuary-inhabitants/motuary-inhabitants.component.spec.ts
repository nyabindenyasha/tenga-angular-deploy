import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MotuaryInhabitantsComponent } from './motuary-inhabitants.component';

describe('MotuaryInhabitantsComponent', () => {
  let component: MotuaryInhabitantsComponent;
  let fixture: ComponentFixture<MotuaryInhabitantsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MotuaryInhabitantsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MotuaryInhabitantsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
