import { Component, OnInit } from '@angular/core';
import { Deceased } from 'src/app/model/mortuary/deceased';
import { NextOfKin } from 'src/app/model/mortuary/nextOfKin';
import { HttpRequestComponent } from 'src/app/provider/http-request/http-request.component';
import { TableCompose } from 'src/app/provider/table/table-compose';
import { DataType } from 'src/app/provider/table/data-type.enum';
import { MortuaryProcesses } from 'src/app/provider/enums/mortuary-processes';


@Component({
  selector: 'app-post-moterm',
  templateUrl: './post-moterm.component.html',
  styleUrls: ['./post-moterm.component.scss']
})
export class PostMotermComponent implements OnInit {
  _search : boolean = false;
  deceased: Deceased;
  nextOfKin: NextOfKin;
  postMortemDetails: any[];
  tableData: TableCompose;
  isAdd: boolean;
  viewDetails: boolean;
  deceasedPeople: Deceased[];
  formView: TableCompose;

  constructor(private http: HttpRequestComponent) {
    this._search = true;
    this.fetchInhabitants();
  }

  ngOnInit() {
  }

  fetchInhabitants() {
    this.deceased = null;
    this.http.get('hospitalmanagement/deceaseddetails/all', (bodies) => this.getDeceasedDetails(bodies));
  }

  getDeceasedDetails(deceasedDetails: Deceased[]) {
    this.deceasedPeople = deceasedDetails.filter(dets => dets.processId == MortuaryProcesses.Arrival)
    this.tableData = new TableCompose()
      .composeHeader('dateOfDeath', 'Date of Death', DataType.Plain)
      .composeHeader('firstName', 'First Name', DataType.Plain)
      .composeHeader('lastName', 'Last Name', DataType.Plain)
      .composeHeader('identificationnumber', 'Identification Number', DataType.Plain)
      .setBody(this.deceasedPeople);
  }

  receiveReport($event) {
    this.fetchInhabitants();
  }

  editClick(item) {
    this.deceased = item;
    this.isAdd = true;
  }

  itemClick($event) {
    this.formView = new TableCompose()
      .composeHeader('firstName', 'First Name', DataType.Plain)
      .composeHeader('lastName', 'Last Name', DataType.Plain)
      .composeHeader('identificationnumber', 'Identification Number', DataType.Plain)
      .composeHeader('dateOfDeath', 'Date Of Birth', DataType.Plain)
      .composeHeader('plce_of_birth', 'Place Of Birth', DataType.Plain)
      .composeHeader('dateOfDeath', 'Date of Death', DataType.Plain)
      .composeHeader('location', 'Location Of Death', DataType.Plain)
    this.isAdd = false;
    this.deceased = $event;
  }
}