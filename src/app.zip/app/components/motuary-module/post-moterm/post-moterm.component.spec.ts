import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PostMotermComponent } from './post-moterm.component';

describe('PostMotermComponent', () => {
  let component: PostMotermComponent;
  let fixture: ComponentFixture<PostMotermComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PostMotermComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PostMotermComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
