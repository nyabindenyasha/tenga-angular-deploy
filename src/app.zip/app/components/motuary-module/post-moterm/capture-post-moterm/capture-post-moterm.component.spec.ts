import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CapturePostMotermComponent } from './capture-post-moterm.component';

describe('CapturePostMotermComponent', () => {
  let component: CapturePostMotermComponent;
  let fixture: ComponentFixture<CapturePostMotermComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CapturePostMotermComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CapturePostMotermComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
