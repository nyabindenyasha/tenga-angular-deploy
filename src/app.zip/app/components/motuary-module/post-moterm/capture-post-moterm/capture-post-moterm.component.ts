import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Deceased } from 'src/app/model/mortuary/deceased';
import { Autopsy } from 'src/app/model/mortuary/autopsy';
import { Validation } from 'src/app/provider/validation/validation';
import { ValidationType } from 'src/app/provider/validation/validation-type.enum';
import { HttpRequestComponent } from 'src/app/provider/http-request/http-request.component';
import swal from 'sweetalert2';
import { Gender } from 'src/app/model/mortuary/gender';

@Component({
  selector: 'app-capture-post-moterm',
  templateUrl: './capture-post-moterm.component.html',
  styleUrls: ['./capture-post-moterm.component.scss']
})
export class CapturePostMotermComponent implements OnInit {
  @Input() deceased: Deceased;
  @Input() autopsy: Autopsy;
  @Output() result = new EventEmitter();
  validation: Validation;
  Gender: Gender[] = [];
  deceasedGender: any;
  genderOfDeceased: any;

  constructor(private http: HttpRequestComponent) {
    this.http.get('/hospitalmanagement/deceaseddetails/gender', (gender) => this.getGender(gender));
  }

  ngOnInit() {
    if (this.autopsy == null) {
      this.autopsy = new Autopsy();
      this.autopsy.deceasedId = this.deceased.deceasedId;
    };
    this.loadValidation();
  }

  loadValidation() {
    this.validation = new Validation();
    this.validation.addField({ name: 'timeOfDeath', display: 'Date Of Death', type: ValidationType.Date },  new Date(this.autopsy.timeOfDeath).getTime());
    this.validation.addField({ name: 'causeOfDeath', display: 'Cause Of Death', type: ValidationType.Required });
  }

  getGender(gender: Gender[]) {
    this.Gender = gender;
    this.deceasedGender = this.Gender.filter(gen => gen.genderId == this.deceased.genderId);
    this.genderOfDeceased = this.deceasedGender[0].genderDescription;
  }
  getDate(value){
    this.loadValidation();
  }

  submit() {
    var url: string = this.autopsy.postMortemId > 0 ? 'hospitalmanagement/postmortemdetails/edited' : 'hospitalmanagement/postmortemdetails/add';
    this.http.post(url, this.autopsy, (result) => {
      swal('', result.message, 'success');
      this.result.emit();
    });
  }
}