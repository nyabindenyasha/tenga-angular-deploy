import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-motuary-module',
  templateUrl: './motuary-module.component.html',
  styleUrls: ['./motuary-module.component.scss']
})
export class MotuaryModuleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
