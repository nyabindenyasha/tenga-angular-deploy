import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MotuaryHomeComponent } from './motuary-home.component';

describe('MotuaryHomeComponent', () => {
  let component: MotuaryHomeComponent;
  let fixture: ComponentFixture<MotuaryHomeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MotuaryHomeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MotuaryHomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
