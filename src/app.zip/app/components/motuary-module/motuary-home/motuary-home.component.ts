import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-motuary-home',
  templateUrl: './motuary-home.component.html',
  styleUrls: ['./motuary-home.component.scss']
})
export class MotuaryHomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
