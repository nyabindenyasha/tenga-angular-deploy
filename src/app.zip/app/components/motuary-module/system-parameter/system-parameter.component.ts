import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-system-parameter',
  templateUrl: './system-parameter.component.html',
  styleUrls: ['./system-parameter.component.scss']
})
export class SystemParameterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
