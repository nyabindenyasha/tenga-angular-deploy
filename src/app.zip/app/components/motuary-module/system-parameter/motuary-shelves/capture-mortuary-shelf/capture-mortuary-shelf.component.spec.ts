import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CaptureMortuaryShelfComponent } from './capture-mortuary-shelf.component';

describe('CaptureMortuaryShelfComponent', () => {
  let component: CaptureMortuaryShelfComponent;
  let fixture: ComponentFixture<CaptureMortuaryShelfComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CaptureMortuaryShelfComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CaptureMortuaryShelfComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
