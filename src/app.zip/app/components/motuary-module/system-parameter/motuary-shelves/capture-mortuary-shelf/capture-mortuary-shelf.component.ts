import { Component, OnInit, Input, Output } from '@angular/core';
import { MortuaryShelf } from 'src/app/model/mortuary/mortuary-shelf';
import { Validation } from 'src/app/provider/validation/validation';
import { ValidationType } from 'src/app/provider/validation/validation-type.enum';
import { HttpRequestComponent } from 'src/app/provider/http-request/http-request.component';
import swal from 'sweetalert2';
import { EventEmitter } from '@angular/core';

@Component({
  selector: 'app-capture-mortuary-shelf',
  templateUrl: './capture-mortuary-shelf.component.html',
  styleUrls: ['./capture-mortuary-shelf.component.scss']
})
export class CaptureMortuaryShelfComponent implements OnInit {
  @Input() shelf: MortuaryShelf;
  @Output() data: EventEmitter<any> = new EventEmitter<MortuaryShelf>();

  validation: Validation;
  motuaryRooms: any[];
  constructor(private http: HttpRequestComponent) {
    this.http.get('/room/getAll', (rooms) => this.getRooms(rooms))
  }


  ngOnInit() {
    if (this.shelf == null) this.shelf = new MortuaryShelf();
    this.loadValidation();
  }
  getRooms(rooms) {
    this.motuaryRooms = rooms;
  }

  loadValidation() {
    this.validation = new Validation();
    this.validation.addField({ name: 'shelfNumber', display: 'Shelf number', type: ValidationType.Required });
    this.validation.addField({ name: 'roomNumber', display: 'Mortuary Room', type: ValidationType.Required });
    this.validation.addField({ name: 'description', display: 'Description ', type: ValidationType.Required });
  }

  onSubmit() {
    this.http.post('/shelves/add', this.shelf, (result) => {
      swal('', result.object.message, 'success');
      this.data.emit(this.shelf);
    });
  }
}