import { Component, OnInit } from '@angular/core';
import { MortuaryShelf } from 'src/app/model/mortuary/mortuary-shelf';
import { TableCompose } from 'src/app/provider/table/table-compose';
import { DataType } from 'src/app/provider/table/data-type.enum';
import { HttpRequestComponent } from 'src/app/provider/http-request/http-request.component';
import swal from 'sweetalert2';

@Component({
  selector: 'app-motuary-shelves',
  templateUrl: './motuary-shelves.component.html',
  styleUrls: ['./motuary-shelves.component.scss']
})
export class MotuaryShelvesComponent implements OnInit {
  shelves: MortuaryShelf[] = [];
  tableData: TableCompose;
  selected: any;
  isAdd: boolean;

  constructor(private http: HttpRequestComponent) {
    this.getShelves();
  }

  getShelves() {
    this.http.get('/shelves/getAll', (shelves) => this.loadShelvesTable(shelves))
  }

  ngOnInit() {
  }

  loadShelvesTable(shelves: MortuaryShelf[]) {
    this.shelves = shelves;
    this.tableData = new TableCompose()
      .composeHeader('shelfNumber', 'Shelf Number', DataType.Plain)
      .composeHeader('roomNumber', 'Room Number', DataType.Plain)
      .composeHeader('description', 'Description', DataType.Plain)
      .composeHeader('isOccupied', 'Occupied?', DataType.Check)
      .setBody(this.shelves);
  }

  itemClick(item) {
    this.selected = item;
    this.isAdd = false;
  }

  onCompleteCapture() {
    this.getShelves();
    this.selected = null;
    this.isAdd = false;
  }

  addClick() {
    this.selected = {};
    this.isAdd = true;
  }

  editClick(item) {
    this.selected = item;
    this.isAdd = true;

  }

  deleteClick(item: MortuaryShelf) {
    this.http.delete('shelves/delete/' + item.shelfNumber, (result) => {
      swal('', result.message, 'success');
      this.onCompleteCapture();
    })
  }
}