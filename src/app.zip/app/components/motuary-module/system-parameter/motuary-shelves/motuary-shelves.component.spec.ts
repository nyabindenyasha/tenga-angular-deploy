import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MotuaryShelvesComponent } from './motuary-shelves.component';

describe('MotuaryShelvesComponent', () => {
  let component: MotuaryShelvesComponent;
  let fixture: ComponentFixture<MotuaryShelvesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MotuaryShelvesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MotuaryShelvesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
