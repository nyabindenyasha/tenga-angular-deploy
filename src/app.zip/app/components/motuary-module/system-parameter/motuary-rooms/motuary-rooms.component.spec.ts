import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MotuaryRoomsComponent } from './motuary-rooms.component';

describe('MotuaryRoomsComponent', () => {
  let component: MotuaryRoomsComponent;
  let fixture: ComponentFixture<MotuaryRoomsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MotuaryRoomsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MotuaryRoomsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
