import { Component, OnInit } from '@angular/core';
import { TableCompose } from 'src/app/provider/table/table-compose';
import { DataType } from 'src/app/provider/table/data-type.enum';
import { rooms } from 'src/app/model/mortuary/options';
import { HttpRequestComponent } from 'src/app/provider/http-request/http-request.component';
import { MortuaryRoom } from 'src/app/model/mortuary/mortuary-room';
import swal from 'sweetalert2';


@Component({
  selector: 'app-motuary-rooms',
  templateUrl: './motuary-rooms.component.html',
  styleUrls: ['./motuary-rooms.component.scss']
})
export class MotuaryRoomsComponent implements OnInit {
  roomDetails: any[];
  tableData: TableCompose;
  selected: any;
  isAdd: boolean;
  constructor(private http: HttpRequestComponent) {
    this.fetchRooms();
  }

  fetchRooms(){
    this.selected = null;
    this.isAdd = false; 
    this.http.get('/room/getAll', (rooms) => this.getMortuaryRooms(rooms))
  }

  ngOnInit() {
  }

  getMortuaryRooms(rooms: MortuaryRoom[]) {
    this.roomDetails = rooms;
    this.tableData = new TableCompose()
      .composeHeader('roomName', 'Room Name', DataType.Plain)
      .composeHeader('roomNumber', 'Room Number', DataType.Plain)
      .setBody(this.roomDetails);
  }

  itemClick(item) {
    this.selected = item;
    this.isAdd = false;
  }

  addClick() {
    this.selected = {};
    this.isAdd = true;
    console.log();
  }

  editClick(item) {
    this.selected = item;
    this.isAdd = true;
  }

  deleteClick(item: MortuaryRoom) {
    this.http.delete('room/delete/' + item.roomNumber, (result) => {
      swal('', result.message, 'success');
      this.fetchRooms();
    })
  }

}
