import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CaptureMotuaryRoomComponent } from './capture-motuary-room.component';

describe('CaptureMotuaryRoomComponent', () => {
  let component: CaptureMotuaryRoomComponent;
  let fixture: ComponentFixture<CaptureMotuaryRoomComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CaptureMotuaryRoomComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CaptureMotuaryRoomComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
