import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { MortuaryRoom } from '../../../../../model/mortuary/mortuary-room';
import { Validation } from 'src/app/provider/validation/validation';
import { ValidationType } from 'src/app/provider/validation/validation-type.enum';
import { HttpRequestComponent } from 'src/app/provider/http-request/http-request.component';
import swal from 'sweetalert2';

@Component({
  selector: 'app-capture-motuary-room',
  templateUrl: './capture-motuary-room.component.html',
  styleUrls: ['./capture-motuary-room.component.scss']
})
export class CaptureMotuaryRoomComponent implements OnInit {
  @Input() room: MortuaryRoom
  @Output() data: EventEmitter<any> = new EventEmitter<MortuaryRoom>();
  validation: Validation;

  constructor(private http: HttpRequestComponent) {
   
  }

 
  ngOnInit() {
    if (this.room == null) this.room = new MortuaryRoom();
    this.loadValidation();

  }

  loadValidation() {
    this.validation = new Validation();
    this.validation.addField({ name: 'roomNumber', display: 'Room Number', type: ValidationType.Required });
    this.validation.addField({ name: 'roomName', display: 'Room Name', type: ValidationType.Required });
    this.validation.addField({ name: 'description', display: 'Description', type: ValidationType.Required });
  }

  onSubmitRoom() {
    this.http.post('room/add', this.room, result => swal(result))
    this.data.emit(this.room);
  }
}
