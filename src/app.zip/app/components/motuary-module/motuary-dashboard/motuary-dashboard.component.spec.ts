import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MotuaryDashboardComponent } from './motuary-dashboard.component';

describe('MotuaryDashboardComponent', () => {
  let component: MotuaryDashboardComponent;
  let fixture: ComponentFixture<MotuaryDashboardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MotuaryDashboardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MotuaryDashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
