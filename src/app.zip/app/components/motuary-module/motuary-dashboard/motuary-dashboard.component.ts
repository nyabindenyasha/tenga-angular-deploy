import { Component, OnInit } from '@angular/core';
import { MortuaryShelf } from 'src/app/model/mortuary/mortuary-shelf';
import { HttpRequestComponent } from 'src/app/provider/http-request/http-request.component';

@Component({
  selector: 'app-motuary-dashboard',
  templateUrl: './motuary-dashboard.component.html',
  styleUrls: ['./motuary-dashboard.component.scss']
})
export class MotuaryDashboardComponent implements OnInit {
  shelves: MortuaryShelf[];

  constructor(private http: HttpRequestComponent) {
    this.http.get('/shelves/getAll', (shelfData) => this.shelves = shelfData);
    this.http.get('/shelves/getAll', () => this.shelvesChart());
  }

  ngOnInit() {
  }

  shelvesChart() {
    var occupied = this.shelves.filter(s => s.isOccupied).length;
    var unOccupied = this.shelves.length - occupied;
    this.chartData = [unOccupied, occupied];
  }

  public chartLabels = ["Occupied", "Unoccupied"];
  public chartData: Array<any> = [];
  public chartColors: Array<any> = [{
    backgroundColor: this.getColors()
  }];

  public chartOptions: any = {
    responsive: true
  };
  public chartClicked(e: any): void { }
  public chartHovered(e: any): void { }

  private getColors(): string[] {
    var colors: string[] = [];
    for (var count: number = 0; count < 10; count++) {
      colors.push(this.getColor(count))
    }
    return colors;
  }

  getColor(count: number) {
    switch (count % 3) {
      case 0:
        return '#A11D0D';
      case 1:
        return '#0A3981';
      default:
        return '#6c757d';
    }
  }
}
