import { Component, OnInit } from '@angular/core';
import { TableCompose } from 'src/app/provider/table/table-compose';
import { HttpRequestComponent } from 'src/app/provider/http-request/http-request.component';
import { DataType } from 'src/app/provider/table/data-type.enum';
import { Deceased } from 'src/app/model/mortuary/deceased';

@Component({
  selector: 'app-deceased-collection',
  templateUrl: './deceased-collection.component.html',
  styleUrls: ['./deceased-collection.component.scss']
})
export class DeceasedCollectionComponent implements OnInit {
  _search : boolean = false;
  inhabitantProfile: any;
  data: any[];
  tableData: TableCompose;
  selected: any;
  isAdd: boolean;
  deadbodies: any[];
  formView: TableCompose;

  constructor(private http: HttpRequestComponent) {
    this._search = true;
    this.fetchInhabitants();
  }

  ngOnInit() {
  }

  fetchInhabitants(){
    this.selected = null;
    this.http.get('hospitalmanagement/deceaseddetails/all', (bodies) => this.getMotuaryInhabitants(bodies));
  }

  getMotuaryInhabitants(bodies: Deceased[]) {
    this.deadbodies = bodies;
    this.tableData = new TableCompose()
      .composeHeader('dateOfDeath', 'Date of Death', DataType.Plain)
      .composeHeader('firstName', 'First Name', DataType.Plain)
      .composeHeader('lastName', 'Last Name', DataType.Plain)
      .composeHeader('identificationnumber', 'Identification Number', DataType.Plain)
      .setBody(this.deadbodies.filter((body) => body.processId == 2))
  }


  itemClick(item) {
    this.formView = new TableCompose()
      .composeHeader('firstName', 'First Name', DataType.Plain)
      .composeHeader('lastName', 'Last Name', DataType.Plain)
      .composeHeader('identificationnumber', 'Identification Number', DataType.Plain)
      .composeHeader('dateOfDeath', 'Date Of Birth', DataType.Plain)
      .composeHeader('plce_of_birth', 'Place Of Birth', DataType.Plain)
      .composeHeader('dateOfDeath', 'Date of Death', DataType.Plain)
      .composeHeader('location', 'Location Of Death', DataType.Plain)
    this.selected = item;
    this.isAdd = false;
  }

  addClick() {
    this.selected = {};
    this.isAdd = true;
  }

  editClick(item) {
    this.selected = item;
    this.isAdd = true;
  }

  addResult($event){
    this.fetchInhabitants();
  }

  
}