import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CaptureCollectionInformationComponent } from './capture-collection-information.component';

describe('CaptureCollectionInformationComponent', () => {
  let component: CaptureCollectionInformationComponent;
  let fixture: ComponentFixture<CaptureCollectionInformationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CaptureCollectionInformationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CaptureCollectionInformationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
