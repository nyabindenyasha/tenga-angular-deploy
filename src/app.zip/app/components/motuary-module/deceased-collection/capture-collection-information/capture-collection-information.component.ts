import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Validation } from 'src/app/provider/validation/validation';
import { ValidationType } from 'src/app/provider/validation/validation-type.enum';
import { Deceased } from 'src/app/model/mortuary/deceased';
import { Collection } from 'src/app/model/mortuary/collection';
import { HttpRequestComponent } from 'src/app/provider/http-request/http-request.component';
import { NextOfKin } from 'src/app/model/mortuary/nextOfKin';
import swal from 'sweetalert2';

@Component({
  selector: 'app-capture-collection-information',
  templateUrl: './capture-collection-information.component.html',
  styleUrls: ['./capture-collection-information.component.scss']
})
export class CaptureCollectionInformationComponent implements OnInit {
  @Input() deceased: Deceased;
  @Input() collection: Collection;
  @Output() result = new EventEmitter<any>();
  nextOfKin: NextOfKin;
  validation: Validation;
  collectorTypes: Array<any> = [{ Name: 'Next Of Kin', value: false }, { Name: 'Other', value: true }];
  collectorType: boolean = false;

  constructor(private http: HttpRequestComponent) {
    this.http.get('hospitalmanagement/deceaseddetails/ShowAllNextOfKin', (nextOfKin: NextOfKin[]) => {
      if (nextOfKin.length < 1) return;
      this.nextOfKin = nextOfKin[0];
      this.loadNextOfKin();
    });
  }

  onChange($event) {
    if (!this.collectorType) this.loadNextOfKin();
  }

  loadNextOfKin() {
    this.collection.collectorFullName = this.nextOfKin.fullName;
  }

  ngOnInit() {
    if (this.collection == null) {
      this.collection = new Collection();
      this.collection.documentDetailsId = 1;
      this.collection.deceasedId = this.deceased.deceasedId;
    }
    this.loadValidation();
  }

  loadValidation() {
    this.validation = new Validation();
    this.validation.addField({ name: 'collectionDate', display: 'Time of Collection', type: ValidationType.Date }, new Date(this.collection.collectionDate).getTime());
    this.validation.addField({ name: 'collectorFullName', display: 'Collector Name', type: ValidationType.Required });
    this.validation.addField({ name: 'collectorNationalIdNumber', display: 'Collector National Id', type: ValidationType.Required });
  }

  getDate(value){
    this.loadValidation();
  }

  submit() {
    this.http.post('collection/add', this.collection, (result) => {
      swal('Collection details updated');
      this.result.emit();
    });
  }
}