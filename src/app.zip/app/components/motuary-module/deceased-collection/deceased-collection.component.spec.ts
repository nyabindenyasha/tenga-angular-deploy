import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DeceasedCollectionComponent } from './deceased-collection.component';

describe('DeceasedCollectionComponent', () => {
  let component: DeceasedCollectionComponent;
  let fixture: ComponentFixture<DeceasedCollectionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DeceasedCollectionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DeceasedCollectionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
