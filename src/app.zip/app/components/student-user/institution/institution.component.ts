import { Contacts } from './../../../model/student/contacts';
import { Component, OnInit } from '@angular/core';
import { TableCompose } from 'src/app/provider/table/table-compose';
import { DataType } from 'src/app/provider/table/data-type.enum';
import swal from 'sweetalert2';
import { Institutions } from 'src/app/model/student/institutions';
import { Provinces } from 'src/app/model/student/provinces';
import { Countries } from 'src/app/model/student/countries';
import { HttpRequest2Component } from 'src/app/provider/http-request/http-request2/http-request2.component';
import { Addresses } from 'src/app/model/student/addresses';



@Component({
  selector: 'app-institution',
  templateUrl: './institution.component.html',
  styleUrls: ['./institution.component.scss']
})
export class InstitutionComponent implements OnInit {

  institutionDetails: Institutions[];
  contactDetails: Contacts[];
  addressDetails: Addresses[];
  provinceDetails: Provinces[];
  countryDetails: Countries[];
  tableData: TableCompose;
  selected: any;
  isAdd: boolean;

  constructor(private http: HttpRequest2Component) { }

  ngOnInit() {
    this.getAll();
    this.loadInstitutions();
  }

  getContacts() {
    this.http.get('/contacts', (contacts) => {
      this.contactDetails = contacts;
      console.log("contactDetails " + this.contactDetails)
    })
  }

  getAddress() {
    this.http.get('/addresses', (addresses) => {
      this.addressDetails = addresses;
      console.log("addressDetails " + this.addressDetails)
    })
  }

  getProvince() {
    this.http.get('/provinces', (province) => {
      this.provinceDetails = province;
      console.log("provinceDetails " + this.provinceDetails)
    })
  }

  getCountries() {
    this.http.get('/countries', (country) => {
      this.countryDetails = country;
      console.log("countryDetails " + this.countryDetails)
      this.loadInstitutions();
    })
  }

  getAll() {
    this.http.get('/contacts', (contacts) => {
      this.contactDetails = contacts;
    })
    this.http.get('/addresses', (addresses) => {
      this.addressDetails = addresses;
    })
    this.http.get('/provinces', (provinces) => {
      this.provinceDetails = provinces;
    })
    this.http.get('/countries', (countries) => {
      this.countryDetails = countries;
    })
  }

  mapContacts(contactId: number): Contacts {
    return this.contactDetails.find(type => type.id == contactId);
  }

  mapAddress(addressId: number): Addresses {
    return this.addressDetails.find(type => type.id == addressId);
  }

  mapProvince(provinceId: number): Provinces {
    return this.provinceDetails.find(type => type.id == provinceId);
  }

  mapCountry(countryId: number): Countries {
    return this.countryDetails.find(type => type.id == countryId);
  }

  loadInstitutions() {
    this.http.get('/highSchoolInstitutions', (categories) => this.loadInstitutions2(categories));
  }

  loadInstitutions2(institutions: Institutions[]) {
    institutions.forEach(category => category.phoneNumber = this.mapContacts(category.contactId));
    institutions.forEach(category => category.addressStreet = this.mapAddress(category.addressId));
    institutions.forEach(category => category.provinceName = this.mapProvince(category.provinceId));
    institutions.forEach(category => category.countryName = this.mapCountry(category.countryId));
    this.institutionDetails = institutions;
    console.log("loadInstitutions " + this.institutionDetails);
    this.tableData = new TableCompose()
      .composeHeader('name', ' Name ', DataType.Plain)
      .composeHeader('email', 'Email', DataType.Plain)
       .composeHeader('contact', 'Contacts', DataType.Selection, 'phoneNumber')
       .composeHeader('address', 'Address', DataType.Selection, 'street')
       .composeHeader('province', 'Province', DataType.Selection, 'name')
       .composeHeader('country', 'Country', DataType.Selection, 'name')
      .setBody(this.institutionDetails);
    console.log(this.institutionDetails);
  }

  itemClick(item) {
    this.selected = item;
    this.isAdd = false;
  }
  addClick() {
    this.selected = {};
    this.isAdd = true;
  }
  editClick(item) {
    this.selected = item;
    this.isAdd = true;
  }

  deleteClick(item: Institutions) {
    this.http.delete('/highSchoolInstitutions/' + item.id, (result) => {
      swal('', result.message, 'success');
      console.log(result);
      this.reloadInstitutions(result)
    });

  }
  reloadInstitutions($event) {
    setTimeout(() => {
      this.loadInstitutions();
    }, 1000);
    this.isAdd = false;
    this.selected = null;
  }

}
