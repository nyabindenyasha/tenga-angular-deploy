import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Validation } from 'src/app/provider/validation/validation';
import { ValidationType } from 'src/app/provider/validation/validation-type.enum';
import { HttpRequest2Component } from 'src/app/provider/http-request/http-request2/http-request2.component';
import swal from 'sweetalert2';
import { Institutions } from 'src/app/model/student/institutions';
import { Addresses } from 'src/app/model/student/addresses';
import { Contacts } from 'src/app/model/student/contacts';
import { Countries } from 'src/app/model/student/countries';
import { Provinces } from 'src/app/model/student/provinces';


@Component({
  selector: 'app-capture-institution',
  templateUrl: './capture-institution.component.html',
  styleUrls: ['./capture-institution.component.scss']
})
export class CaptureInstitutionComponent implements OnInit {

  @Input() institutions: Institutions
  @Output() data: EventEmitter<any> = new EventEmitter<Institutions>()
  validation: Validation;
  provinceName: any[];
  countryName: any[];
  institutionsModel = new Institutions(0, '', '', new Contacts(''), new Addresses('',''), 0, 0);
  modelOrNot: boolean;

  constructor(private http: HttpRequest2Component) {
    this.http.get("/countries", ((result) => this.getCountries(result)));
    this.http.get("/provinces", ((result) => this.getProvinces(result)));
   }

  ngOnInit() { 
   if (this.institutions == null){ 
     // this.modelOrNot = true;
      // this.institutionsModel.id = this.institutions.id;
      // this.institutionsModel.name = this.institutions.name;
      // this.institutionsModel.email = this.institutions.email;
      // this.institutionsModel.contact = this.institutions.contact;
      // this.institutionsModel.address = this.institutions.address;
      // this.institutionsModel.countryId = this.institutions.countryId;
      // this.institutionsModel.provinceId = this.institutions.provinceId;

      // this.institutions.id = this.institutionsModel.id;
      // this.institutions.name = this.institutionsModel.name;
      // this.institutions.email = this.institutionsModel.email;
      // this.institutions.contact = this.institutionsModel.contact;
      // this.institutions.address = this.institutionsModel.address;
      // this.institutions.countryId = this.institutionsModel.countryId;
      // this.institutions.provinceId = this.institutionsModel.provinceId;

      this.institutions = new Institutions(0, '', '', new Contacts(''), new Addresses('',''), 0, 0);
      //this.institutions = this.institutionsModel;
    }
    this.loadValidation();
  }

  getCountries(type) {
    this.countryName = type;
  }
 
  getProvinces(type) {
    this.provinceName = type;
  }

  loadValidation() {
    this.validation = new Validation();
    this.validation.addField({ name: 'name', display: ' Name of Institution', type: ValidationType.Required });
    this.validation.addField({ name: 'email', display: ' Email ', type: ValidationType.Required });
    this.validation.addField({ name: 'contact', display: ' Contact Details', type: ValidationType.Required });
    this.validation.addField({ name: 'address', display: ' Address', type: ValidationType.Required });
    this.validation.addField({ name: 'countryId', display: 'Country ', type: ValidationType.Required });
    this.validation.addField({ name: 'provinceId', display: ' Province ', type: ValidationType.Required });
  }

  onSubmit() {
    if (this.institutions.id > 0) {
      this.http.update('/highSchoolInstitutions/' + this.institutions.id, this.institutions, (result) => swal('', result.message, 'success'));
      this.data.emit(this.institutions);
      return;
    } else {
      this.http.post('/highSchoolInstitutions ', this.institutionsModel, (result) => swal('', result.message, 'success'));
      this.data.emit(this.institutions);
    }
  }

}
