import { Component, OnInit } from '@angular/core';
import { TableCompose } from 'src/app/provider/table/table-compose';
import { DataType } from 'src/app/provider/table/data-type.enum';
import { HttpRequest2Component } from 'src/app/provider/http-request/http-request2/http-request2.component';
import { AreasOfInterest } from 'src/app/model/student/areas-of-interest';
import swal from 'sweetalert2';


@Component({
  selector: 'app-areas-of-interest',
  templateUrl: './areas-of-interest.component.html',
  styleUrls: ['./areas-of-interest.component.scss']
})
export class AreasOfInterestComponent implements OnInit {

  areasOfInterest: AreasOfInterest[] = [];
  tableData: TableCompose;
  selected: any;
  isAdd: boolean;
  areasOfInterestDetails: any[];

  constructor(private http: HttpRequest2Component) { 
    this.getAreasOfInterest();
  }

   getAreasOfInterest() {
    this.http.get('/areasOfInterest', (result) => this.loadAreasOfInterest(result))
  }

  loadAreasOfInterest(areas: AreasOfInterest[]){
    this.areasOfInterestDetails = areas;
    this.tableData = new TableCompose()
      .composeHeader('name', 'Areas. Name', DataType.Plain)
      .composeHeader('description', 'Areas. Description', DataType.Plain)
      .setBody(this.areasOfInterestDetails);
  }

  ngOnInit() {
  }

  itemClick(item) {
    this.selected = item;
    this.isAdd = false;
  }

  addClick() {
    this.selected = {};
    this.isAdd = true;
  }

  editClick(item) {
    this.selected = item;
    this.isAdd = true;
  }

  deleteClick(item: AreasOfInterest) {
    this.http.delete('/areasOfInterest/' + item.id, (result) => {
      swal('', result.message, 'success');
      this.reloadAreasOfInterest(result)
    });
  }

  reloadAreasOfInterest($event) {
    this.getAreasOfInterest();
    this.isAdd = false;
    this.selected = null;
  }

} 
