import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CaptureAreasOfInterestComponent } from './capture-areas-of-interest.component';

describe('CaptureAreasOfInterestComponent', () => {
  let component: CaptureAreasOfInterestComponent;
  let fixture: ComponentFixture<CaptureAreasOfInterestComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CaptureAreasOfInterestComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CaptureAreasOfInterestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
