import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Validation } from 'src/app/provider/validation/validation';
import { ValidationType } from 'src/app/provider/validation/validation-type.enum';
import { HttpRequest2Component } from 'src/app/provider/http-request/http-request2/http-request2.component';
import { AreasOfInterest } from 'src/app/model/student/areas-of-interest';
import swal from 'sweetalert2';


@Component({
  selector: 'app-capture-areas-of-interest',
  templateUrl: './capture-areas-of-interest.component.html',
  styleUrls: ['./capture-areas-of-interest.component.scss']
})
export class CaptureAreasOfInterestComponent implements OnInit {

  @Input() areasOfInterest: AreasOfInterest;
  @Output() data: EventEmitter<any> = new EventEmitter<AreasOfInterest>()
  validation: Validation;

  constructor(private http: HttpRequest2Component) { }

  ngOnInit() {
    if (this.areasOfInterest == null)
    this.areasOfInterest = new AreasOfInterest();
  this.loadValidation();
  }
 
  loadValidation() {
    this.validation = new Validation();
    this.validation.addField({ name: 'name', display: 'Name', type: ValidationType.Required });
    this.validation.addField({ name: 'description', display: 'Description', type: ValidationType.Required });
  }

  onSubmit() {
    if (this.areasOfInterest.id > 0) {
      this.http.update('/areasOfInterest/' + this.areasOfInterest.id, this.areasOfInterest, (result) => this.submitResult(result));
      return;
    }
    this.http.post('/areasOfInterest', this.areasOfInterest, (result) => this.submitResult(result));
  }

  submitResult(result) {
    swal('', 'Success', 'success');
    this.data.emit(this.areasOfInterest);
  }

}
 