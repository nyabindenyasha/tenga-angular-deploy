import { Component, OnInit } from '@angular/core';
import { HttpRequest2Component } from 'src/app/provider/http-request/http-request2/http-request2.component';
import { TableCompose } from 'src/app/provider/table/table-compose';
import { DataType } from 'src/app/provider/table/data-type.enum';
import { Countries } from 'src/app/model/student/countries';

@Component({
  selector: 'app-countries-list',
  templateUrl: './countries-list.component.html',
  styleUrls: ['./countries-list.component.scss']
})
export class CountriesListComponent implements OnInit {

  countries: Countries[] = [];
  tableData: TableCompose;
  selected: any;
  isAdd: boolean;
  countriesDetails: any[];

  constructor(private http: HttpRequest2Component) { 
    this.getCountries();
  }

  getCountries(){
    this.http.get('/countries', (result) => this.loadCountries(result))
  }

  loadCountries(countries: Countries[]){
    this.countriesDetails = countries;
    this.tableData = new TableCompose()
      .composeHeader('id', 'Id', DataType.Plain)
      .composeHeader('name', 'Name', DataType.Plain)
      .composeHeader('code', 'Code', DataType.Plain)
      .composeHeader('areaCode', 'AreasCode', DataType.Plain)
      .setBody(this.countriesDetails);
  }

  ngOnInit() {
  }

  itemClick(item) {
    this.selected = item;
    this.isAdd = false;
  }

  addClick() {
    this.selected = {};
    this.isAdd = true;
  }

  editClick(item) {
    this.selected = item;
    this.isAdd = true;
  }
 
}
