import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { StudentUserParametersComponent } from './student-user-parameters.component';

describe('StudentUserParametersComponent', () => {
  let component: StudentUserParametersComponent;
  let fixture: ComponentFixture<StudentUserParametersComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ StudentUserParametersComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StudentUserParametersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
