import { Component, OnInit } from '@angular/core';
import { TableCompose } from 'src/app/provider/table/table-compose';
import { DataType } from 'src/app/provider/table/data-type.enum';
import { HttpRequest2Component } from 'src/app/provider/http-request/http-request2/http-request2.component';
import { Programs } from 'src/app/model/student/programs';
import swal from 'sweetalert2';


@Component({
  selector: 'app-programs',
  templateUrl: './programs.component.html',
  styleUrls: ['./programs.component.scss']
})
export class ProgramsComponent implements OnInit {

  programs: Programs[] = [];
  tableData: TableCompose;
  selected: any;
  isAdd: boolean;
  programDetails: any[];

  constructor(private http: HttpRequest2Component) { 
    this.getPrograms();
  }

  getPrograms(){
    this.http.get('/programs', (result) => this.loadPrograms(result))
  }

  loadPrograms(programs: Programs[]){
    this.programDetails = programs;
    this.tableData = new TableCompose()
      .composeHeader('name', 'Name', DataType.Plain)
      .composeHeader('comment', 'Comment', DataType.Plain)
      .setBody(this.programDetails);
  }

  ngOnInit() {
  }

  itemClick(item) {
    this.selected = item;
    this.isAdd = false;
  }

  addClick() {
    this.selected = {};
    this.isAdd = true;
  }

  editClick(item) {
    this.selected = item;
    this.isAdd = true;
  }

  deleteClick(item: Programs) {
    this.http.delete('/programs/' + item.id, (result) => {
      swal('', result.message, 'success');
      this.reloadPrograms(result)
    });
  }

  reloadPrograms($event) {
    this.getPrograms();
    this.isAdd = false;
    this.selected = null;
  }

}
