import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Validation } from 'src/app/provider/validation/validation';
import { ValidationType } from 'src/app/provider/validation/validation-type.enum';
import { HttpRequest2Component } from 'src/app/provider/http-request/http-request2/http-request2.component';
import { Programs } from 'src/app/model/student/programs';
import swal from 'sweetalert2';

@Component({
  selector: 'app-capture-programs',
  templateUrl: './capture-programs.component.html',
  styleUrls: ['./capture-programs.component.scss']
})
export class CaptureProgramsComponent implements OnInit {

  @Input() programs: Programs;
  @Output() data: EventEmitter<any> = new EventEmitter<Programs>()
  validation: Validation;

  constructor(private http: HttpRequest2Component) { }

  ngOnInit() {
    if (this.programs == null)
    this.programs = new Programs('');
  this.loadValidation();
  }

  loadValidation() {
    this.validation = new Validation();
    this.validation.addField({ name: 'name', display: 'Name', type: ValidationType.Required });
    this.validation.addField({ name: 'comment', display: 'Comment', type: ValidationType.Required });
  }

  onSubmit() {
    if (this.programs.id > 0) {
      this.http.update('/programs/' + this.programs.id, this.programs, (result) => this.submitResult(result));
      return;
    }
    this.http.post('/programs', this.programs, (result) => this.submitResult(result));
  }

  submitResult(result) {
    swal('', 'Success', 'success');
    this.data.emit(this.programs);
  }

}
