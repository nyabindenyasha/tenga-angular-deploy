import { Component, OnInit } from '@angular/core';
import { TableCompose } from 'src/app/provider/table/table-compose';
import { DataType } from 'src/app/provider/table/data-type.enum';
import { HttpRequest2Component } from 'src/app/provider/http-request/http-request2/http-request2.component';
import { Provinces } from 'src/app/model/student/provinces';
import swal from 'sweetalert2';


@Component({
  selector: 'app-province',
  templateUrl: './province.component.html',
  styleUrls: ['./province.component.scss']
})
export class ProvinceComponent implements OnInit {

  province: Provinces[] = [];
  tableData: TableCompose;
  selected: any;
  isAdd: boolean;
  provinceDetails: any[];

  constructor(private http: HttpRequest2Component) { 
    this.getProvinces();
  }

  getProvinces() {
    this.http.get('/provinces', (result) => this.loadProvinces(result))
  }

  loadProvinces(province: Provinces[]){
    this.provinceDetails = province;
    this.tableData = new TableCompose()
      .composeHeader('name', 'Name', DataType.Plain)
      .composeHeader('countryId', 'Country', DataType.Plain)
      .setBody(this.provinceDetails);
  }

  ngOnInit() {
  }

  itemClick(item) {
    this.selected = item;
    this.isAdd = false;
  }

  addClick() {
    this.selected = {};
    this.isAdd = true;
  }

  editClick(item) {
    this.selected = item;
    this.isAdd = true;
  }

  deleteClick(item: Provinces) {
    this.http.delete('/provinces/' + item.id, (result) => {
      swal('', result.message, 'success');
      this.reloadProvinces(result)
    });
  }

  reloadProvinces($event) {
    this.getProvinces();
    this.isAdd = false;
    this.selected = null;
  }

}
 