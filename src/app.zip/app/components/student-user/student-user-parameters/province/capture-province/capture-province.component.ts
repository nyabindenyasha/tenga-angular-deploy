import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Validation } from 'src/app/provider/validation/validation';
import { ValidationType } from 'src/app/provider/validation/validation-type.enum';
import { HttpRequest2Component } from 'src/app/provider/http-request/http-request2/http-request2.component';
import { Provinces } from 'src/app/model/student/provinces';
import swal from 'sweetalert2';

@Component({
  selector: 'app-capture-province',
  templateUrl: './capture-province.component.html',
  styleUrls: ['./capture-province.component.scss']
})
export class CaptureProvinceComponent implements OnInit {

  @Input() province: Provinces;
  @Output() data: EventEmitter<any> = new EventEmitter<Provinces>()
  validation: Validation;

  constructor(private http: HttpRequest2Component) { }

  ngOnInit() {
    if (this.province == null)
    this.province = new Provinces('');
  this.loadValidation();
  }
 
  loadValidation() {
    this.validation = new Validation();
    this.validation.addField({ name: 'name', display: 'Name', type: ValidationType.Required });
    this.validation.addField({ name: 'countryId', display: 'Country', type: ValidationType.Required });
  }

  onSubmit() {
    if (this.province.id > 0) {
      this.http.update('/provinces/' + this.province.id, this.province, (result) => this.submitResult(result));
      return;
    }
    this.http.post('/provinces', this.province, (result) => this.submitResult(result));
  }

  submitResult(result) {
    swal('', 'Success', 'success');
    this.data.emit(this.province);
  }
}
 