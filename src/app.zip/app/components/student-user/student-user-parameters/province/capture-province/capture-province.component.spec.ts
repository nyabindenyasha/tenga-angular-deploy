import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CaptureProvinceComponent } from './capture-province.component';

describe('CaptureProvinceComponent', () => {
  let component: CaptureProvinceComponent;
  let fixture: ComponentFixture<CaptureProvinceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CaptureProvinceComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CaptureProvinceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
