import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-student-user-parameters',
  templateUrl: './student-user-parameters.component.html',
  styleUrls: ['./student-user-parameters.component.scss']
})
export class StudentUserParametersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
