import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-capture-student',
  templateUrl: './capture-student.component.html',
  styleUrls: ['./capture-student.component.scss']
})
export class CaptureStudentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
