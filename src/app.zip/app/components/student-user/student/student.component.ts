import { Component, OnInit } from '@angular/core';
import { TableCompose } from 'src/app/provider/table/table-compose';
import { DataType } from 'src/app/provider/table/data-type.enum';
import swal from 'sweetalert2';
import { Institutions } from 'src/app/model/student/institutions';
import { Contacts } from 'src/app/model/student/contacts';
import { Provinces } from 'src/app/model/student/provinces';
import { Countries } from 'src/app/model/student/countries';
import { HttpRequest2Component } from 'src/app/provider/http-request/http-request2/http-request2.component';
import { Addresses } from 'src/app/model/student/addresses';
import { HighSchoolStudent } from 'src/app/model/student/high-school-student';
import { Gender } from 'src/app/model/gender';
import { Programs } from 'src/app/model/student/programs';
import { AreasOfInterest } from 'src/app/model/student/areas-of-interest';

@Component({
  selector: 'app-student',
  templateUrl: './student.component.html',
  styleUrls: ['./student.component.scss']
})
export class StudentComponent implements OnInit {

  studentDetails: HighSchoolStudent[];
  institutionDetails: Institutions[];
  contactDetails: Contacts[];
  addressDetails: Addresses[];
  genderDetails: Gender[];
  provinceDetails: Provinces[];
  countryDetails: Countries[];
  programDetails: Programs[];
  areaOfInterestDetails: AreasOfInterest[];

  tableData: TableCompose;
  selected: any;
  isAdd: boolean;

  constructor(private http: HttpRequest2Component) { }

  ngOnInit() {
    this.getAll();
    this.loadStudents();
  }

  getAll(){
    this.http.get('/contacts', (contacts) => {
      this.contactDetails = contacts;
    })
    this.http.get('/addresses', (addresses) => {
      this.addressDetails = addresses;
    })
    this.http.get('/provinces', (provinces) => {
      this.provinceDetails = provinces;
    })
    this.http.get('/countries', (countries) => {
      this.countryDetails = countries;
    })
    this.http.get('/gender', (gender) => {
      this.genderDetails = gender;
    })  
    this.http.get('/institutions', (institutions) => {
      this.institutionDetails = institutions;
    })
    this.http.get('/institutions', (institutions) => {
      this.institutionDetails = institutions;
    })
  }

  mapContacts(contactId: number): Contacts {
    return this.contactDetails.find(type => type.id == contactId);
  }

  mapAddress(addressId: number): Addresses {
    return this.addressDetails.find(type => type.id == addressId);
  }

  mapProvince(provinceId: number): Provinces {
    return this.provinceDetails.find(type => type.id == provinceId);
  }

  mapCountry(countryId: number): Countries {
    return this.countryDetails.find(type => type.id == countryId);
  }

  mapGender(genderId: number): Gender {
    return this.genderDetails.find(type => type.id == genderId);
  }

  mapInstitution(institutionId: number): Institutions {
    return this.institutionDetails.find(type => type.id == institutionId);
  }

  mapAreaOfInterest(areaOfInterestId: number): AreasOfInterest {
    return this.areaOfInterestDetails.find(type => type.id == areaOfInterestId);
  }

  loadStudents() {
    this.http.get('/highSchoolStudent ', (categories) => this.loadStudents2(categories));
  }

  loadStudents2(students: HighSchoolStudent[]){
    students.forEach(category => category.contactPhoneNumber = this.mapContacts(category.contactId));
    students.forEach(category => category.addressNumber = this.mapAddress(category.addressId));
    students.forEach(category => category.addressStreet = this.mapAddress(category.addressId));
    students.forEach(category => category.provinceName = this.mapProvince(category.provinceId));
    students.forEach(category => category.countryName= this.mapCountry(category.countryId));
    students.forEach(category => category.areaOfInterestName= this.mapAreaOfInterest(category.areaOfInterestId));
    students.forEach(category => category.genderName= this.mapGender(category.genderId));
    students.forEach(category => category.institutionName= this.mapInstitution(category.institutionId));
    
    this.studentDetails = students;
    console.log("studentDetails " + this.studentDetails);
    this.tableData = new TableCompose()
      .composeHeader('firstName', ' FirstName ', DataType.Plain)
      .composeHeader('lastName', ' LastName ', DataType.Plain)
      .composeHeader('email', 'Email', DataType.Plain)
      .composeHeader('contactPhoneNumber', 'Contacts', DataType.Selection, 'phoneNumber')
      .composeHeader('addressNumber', 'Address', DataType.Selection, 'number')
      .composeHeader('addressStreet', 'Address', DataType.Selection, 'street')
      .composeHeader('provinceName', 'Province', DataType.Selection, 'name')
      .composeHeader('countryName', 'Country', DataType.Selection, 'name')
      .setBody(this.institutionDetails);
  }

  itemClick(item) {
    this.selected = item;
    this.isAdd = false;
  }
  addClick() {
    this.selected = {};
    this.isAdd = true;
  }
  editClick(item) {
    this.selected = item;
    this.isAdd = true;
  }

  deleteClick(item: Institutions) {
    this.http.delete('/instihighSchoolStudent/' + item.id, (result) => {
      swal('', result.message, 'success'); 
      console.log(result);    
       this.reloadEmployees(result)
    });
  
  }
  reloadEmployees($event) {
    setTimeout(() => {
      this.loadStudents();
    }, 1000);
    this.isAdd = false;
    this.selected = null;
  }

}
