import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-student-user',
  templateUrl: './student-user.component.html',
  styleUrls: ['./student-user.component.scss']
})
export class StudentUserComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
