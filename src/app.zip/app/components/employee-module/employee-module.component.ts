import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-employee-module',
  templateUrl: './employee-module.component.html',
  styleUrls: ['./employee-module.component.scss']
})
export class EmployeeModuleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
