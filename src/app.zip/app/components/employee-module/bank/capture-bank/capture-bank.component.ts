import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Validation } from 'src/app/provider/validation/validation';
import { ValidationType } from 'src/app/provider/validation/validation-type.enum';
import { HttpRequestComponent } from 'src/app/provider/http-request/http-request.component';
import { Bank } from 'src/app/model/employees/bank';
import swal from 'sweetalert2';

@Component({
  selector: 'app-capture-bank',
  templateUrl: './capture-bank.component.html',
  styleUrls: ['./capture-bank.component.scss']
})
export class CaptureBankComponent implements OnInit {

  @Input() asset: Bank;
  @Output() data: EventEmitter<any> = new EventEmitter<Bank>();
  validation: Validation;

  constructor(private http: HttpRequestComponent) { }

  ngOnInit() {
    if (this.asset == null)
      this.asset = new Bank();
    this.loadValidation();
  }

  loadValidation() {
    this.validation = new Validation();
    this.validation.addField({ name: 'bankName', display: 'Bank Full Name', type: ValidationType.Required });
    this.validation.addField({ name: 'shortName', display: 'Short Name', type: ValidationType.Required });
  }

  onSubmitAsset() {
    if (this.asset.bankId > 0) {
      this.http.update('bank/' + this.asset.bankId, this.asset, (result) => this.submitResult(result));
      return;
    }
    this.http.post('bank', this.asset, (result) => this.submitResult(result));
  }

  submitResult(result) {
    swal('', 'Success', 'success');
    this.data.emit(this.asset);
  }

}
