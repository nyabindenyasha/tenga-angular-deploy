import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CaptureBankComponent } from './capture-bank.component';

describe('CaptureBankComponent', () => {
  let component: CaptureBankComponent;
  let fixture: ComponentFixture<CaptureBankComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CaptureBankComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CaptureBankComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
