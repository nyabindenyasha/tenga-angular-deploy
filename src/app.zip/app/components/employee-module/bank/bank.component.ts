import { Component, OnInit } from '@angular/core';
import { TableCompose } from 'src/app/provider/table/table-compose';
import { DataType } from 'src/app/provider/table/data-type.enum';
import { HttpRequestComponent } from 'src/app/provider/http-request/http-request.component';
import { Bank } from 'src/app/model/employees/bank';
import swal from 'sweetalert2';

@Component({
  selector: 'app-bank',
  templateUrl: './bank.component.html',
  styleUrls: ['./bank.component.scss']
})
export class BankComponent implements OnInit {

  banks: Bank[] = [];
  tableData: TableCompose;
  selected: any;
  isAdd: boolean;
  bankDetails: any[];

  constructor(private http: HttpRequestComponent) {
    this.fetchBanks();
  }

  fetchBanks() {
    this.http.get('/bank', (banks) => this.getBanks(banks))
  }

  ngOnInit() {
  }

  getBanks(asset: Bank[]) {
    this.bankDetails = asset;
    this.tableData = new TableCompose()
      .composeHeader('bankId', 'Id', DataType.Plain)
      .composeHeader('bankName', 'Bank Name', DataType.Plain)
      .composeHeader('shortName', 'Short Name', DataType.Plain)
      .setBody(this.bankDetails);
  }

  itemClick(item) {
    this.selected = item;
    this.isAdd = false;
  }

  addClick() {
    this.selected = {};
    this.isAdd = true;
  }

  editClick(item) {
    this.selected = item;
    this.isAdd = true;
  }

  deleteClick(item: Bank) {
    this.http.delete('/bank/' + item.bankId, (result) => {
      swal('', result.message, 'success');
      this.reloadBanks(result)
    });
  }

  reloadBanks($event) {
    this.fetchBanks();
    this.isAdd = false;
    this.selected = null;
  }

}
