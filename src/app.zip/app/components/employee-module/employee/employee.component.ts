import { Component, OnInit } from '@angular/core';
import { TableCompose } from 'src/app/provider/table/table-compose';
import { DataType } from 'src/app/provider/table/data-type.enum';

import { HttpRequestComponent } from 'src/app/provider/http-request/http-request.component';

import swal from 'sweetalert2';
import { Employee } from 'src/app/model/employees/employee';
import { Bank } from 'src/app/model/employees/bank';
import { Branch } from 'src/app/model/employees/branch';
import { Gender } from 'src/app/model/mortuary/gender';
import { MaritalStatus } from 'src/app/model/employees/marital-status';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.scss']
})
export class EmployeeComponent implements OnInit {

  employeesDetails: Employee[];
  bankDetails: Bank[];
  branchDetails: Branch[];
  genderDetails: Gender[];
  maritalDetails: MaritalStatus[];
  tableData: TableCompose;
  selected: any;
  isAdd: boolean;

  constructor(private http: HttpRequestComponent) { }

  ngOnInit() {
    // this.getBanks();
    // this.getBranches();
    // this.getGender();
    // this.getMaritalStatus();
    this.getAll();
    this.loadEmployees();
  }

  getBanks(){
    this.http.get('/bank', (bank) => {
      this.bankDetails = bank;
      console.log("bankDetails "+this.bankDetails)
      //this.loadEmployees();
    })
  }

  getBranches(){
    this.http.get('/branch', (branch) => {
      this.branchDetails = branch;
      console.log("branchDetails "+this.branchDetails)
    })
  }

  getGender(){
    this.http.get('/hospitalmanagement/deceaseddetails/gender', (gender) => {
      this.genderDetails = gender;
      console.log("genderDetails "+this.genderDetails)
    })
  }

  getMaritalStatus(){
    this.http.get('/marital', (marital) => {
      this.maritalDetails = marital;
      console.log("maritalDetails "+this.maritalDetails)
      this.loadEmployees();
    })
  }

  getAll(){
    this.http.get('/bank', (bank) => {
      this.bankDetails = bank;
    })
    this.http.get('/marital', (marital) => {
      this.maritalDetails = marital;
    })
    this.http.get('/branch', (branch) => {
      this.branchDetails = branch;
    })
    this.http.get('/hospitalmanagement/deceaseddetails/gender', (gender) => {
      this.genderDetails = gender;
    })
    //this.loadEmployees();
  }

  mapBank(bankid: number): Bank {
    return this.bankDetails.find(type => type.bankId == bankid);
  }

  mapBranch(branchId: number): Branch {
    return this.branchDetails.find(type => type.branchId == branchId);
  }

  mapGender(genderid: number): Gender {
    return this.genderDetails.find(type => type.genderId == genderid);
  }

  mapMaritalStatus(maritalStatusId: number): MaritalStatus {
    return this.maritalDetails.find(type => type.id == maritalStatusId);
  }

  loadEmployees() {
    this.http.get('/employees', (categories) => this.loadEmployees2(categories));
  }

  loadEmployees2(employees: Employee[]){
    employees.forEach(category => category.bankName = this.mapBank(category.bankId));
    employees.forEach(category => category.branchName = this.mapBranch(category.branchId));
    employees.forEach(category => category.genderName = this.mapGender(category.genderId));
    employees.forEach(category => category.maritalStatusName= this.mapMaritalStatus(category.maritalStatusId));
    this.employeesDetails = employees
    console.log("loadEmployees2 " + this.employeesDetails);
    this.tableData = new TableCompose()
      .composeHeader('name', ' FirstName ', DataType.Plain)
      .composeHeader('surname', 'LastName', DataType.Plain)
      .composeHeader('bankName', 'Bank', DataType.Selection, 'bankName')
      .composeHeader('branchName', 'Branch', DataType.Selection, 'branchName')
      .composeHeader('genderName', 'Gender', DataType.Selection, 'genderDescription')
      .composeHeader('maritalStatusName', 'M status', DataType.Selection, 'description')
      .composeHeader('email', 'Email', DataType.Plain)
      .setBody(this.employeesDetails);
  }
  
  itemClick(item) {
    this.selected = item;
    this.isAdd = false;
  }
  addClick() {
    this.selected = {};
    this.isAdd = true;
  }
  editClick(item) {
    this.selected = item;
    this.isAdd = true;
  }

  deleteClick(item: Employee) {
    this.http.delete('/employees/' + item.id, (result) => {
      swal('', result.message, 'success'); 
      console.log(result);    
       this.reloadEmployees(result)
    });
  
  }
  reloadEmployees($event) {
    setTimeout(() => {
      this.loadEmployees();
    }, 1000);
    this.isAdd = false;
    this.selected = null;
  }
  // reloadEmployees2(employees) {
  //   this.isAdd = false;
  //   this.selected = null;
  //   this.loadEmployees()
  // }
}
