import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Employee } from 'src/app/model/employees/employee';
import { Validation } from 'src/app/provider/validation/validation';
import { ValidationType } from 'src/app/provider/validation/validation-type.enum';
import { HttpRequestComponent } from 'src/app/provider/http-request/http-request.component';
import swal from 'sweetalert2';


@Component({
  selector: 'app-capture-employee',
  templateUrl: './capture-employee.component.html',
  styleUrls: ['./capture-employee.component.scss']
})
export class CaptureEmployeeComponent implements OnInit {

    @Input() employees: Employee
    @Output() data: EventEmitter<any> = new EventEmitter<Employee>();
    validation: Validation;
    bankNames: any[];
    branchName: any[];
    genderName: any[];
    maritalName: any[];

    constructor(private http: HttpRequestComponent) {
      this.http.get("/bank", ((result) => this.getBank(result)));
      this.http.get("/branch", ((result) => this.getBranch(result)));
      this.http.get("/marital", ((result) => this.getMarital(result)));
      this.http.get("/hospitalmanagement/deceaseddetails/gender", ((result) => this.getGender(result)));
    }

    ngOnInit() {
      if (this.employees == null) this.employees = new Employee();
      this.loadValidation();
    }

    getBank(type) {
      this.bankNames = type;
      console.log("ropa "+this.bankNames);
    }
    
    getBranch(type) {
      this.branchName = type;
    }

    getGender(type) {
      this.genderName = type;
    }

    getMarital(type) {
      this.maritalName = type;
    }

    loadValidation() {
      this.validation = new Validation();
      this.validation.addField({ name: 'name', display: ' Firstname', type: ValidationType.Required });
      this.validation.addField({ name: 'surname', display: ' Lastname', type: ValidationType.Required });
      this.validation.addField({ name: 'adress', display: ' Address', type: ValidationType.Required });
      this.validation.addField({ name: 'bankId', display: ' Bank ', type: ValidationType.Required });
      this.validation.addField({ name: 'branchId', display: 'Branch ', type: ValidationType.Required });
      this.validation.addField({ name: 'genderId', display: ' Gender ', type: ValidationType.Required });
      this.validation.addField({ name: 'maritalStatusId', display: ' MaritalStatus ', type: ValidationType.Required });
      //this.validation.addField({ name: 'd_o_b', display: 'Date of Birth', type: ValidationType.Required });
      this.validation.addField({ name: 'email', display: 'Email', type: ValidationType.Required });
      this.validation.addField({ name: 'phoneNumber', display: ' Phone Number ', type: ValidationType.Required });
    }

    onSubmit() {
      if (this.employees.id > 0) {
        this.http.update('/employees/' + this.employees.id, this.employees, (result) => swal('', result.message, 'success'));
        this.data.emit(this.employees);
        return;
      } else {
        this.http.post('/employees', this.employees, (result) => swal('', result.message, 'success'));
        this.data.emit(this.employees);
      }
    }

}
