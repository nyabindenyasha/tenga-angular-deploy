import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CaptureEmployeeComponent } from './capture-employee.component';

describe('CaptureEmployeeComponent', () => {
  let component: CaptureEmployeeComponent;
  let fixture: ComponentFixture<CaptureEmployeeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CaptureEmployeeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CaptureEmployeeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
