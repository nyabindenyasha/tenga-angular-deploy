import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CaptureBranchComponent } from './capture-branch.component';

describe('CaptureBranchComponent', () => {
  let component: CaptureBranchComponent;
  let fixture: ComponentFixture<CaptureBranchComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CaptureBranchComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CaptureBranchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
