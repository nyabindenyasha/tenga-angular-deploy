import { Component, OnInit, Input, Output } from '@angular/core';
import { Validation } from 'src/app/provider/validation/validation';
import { ValidationType } from 'src/app/provider/validation/validation-type.enum';
import { HttpRequestComponent } from 'src/app/provider/http-request/http-request.component';
import swal from 'sweetalert2';
import { EventEmitter } from '@angular/core';
import { Branch } from 'src/app/model/employees/branch';

@Component({
  selector: 'app-capture-branch',
  templateUrl: './capture-branch.component.html',
  styleUrls: ['./capture-branch.component.scss']
})
export class CaptureBranchComponent implements OnInit {

  @Input() asset: Branch;
  @Output() data: EventEmitter<any> = new EventEmitter<Branch>();

  validation: Validation;
  bank: any[];
  constructor(private http: HttpRequestComponent) {
    this.http.get("/bank", ((result) => this.getBank(result)));
  }


  ngOnInit() {
    console.log(this.asset);
    if (this.asset == null) this.asset = new Branch();
    this.loadValidation();
  }

  getBank(bank) {
    this.bank = bank;
    console.log("nya "+this.bank)
  }

  loadValidation() {
    this.validation = new Validation();
    this.validation.addField({ name: 'bankId', display: 'Bank', type: ValidationType.Required });
    this.validation.addField({ name: 'branchName', display: 'Branch', type: ValidationType.Required });
    // this.validation.addField({ name: 'branchName', display: 'Branch', type: ValidationType.GreaterThan }, 0);
  }

  onSubmit() {
    this.http.post('/branch', this.asset, (result) => swal('', result.message, 'success'));
    this.data.emit(this.asset);
  }
}
