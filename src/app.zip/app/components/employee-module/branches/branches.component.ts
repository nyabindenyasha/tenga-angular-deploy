import { Component, OnInit } from '@angular/core';
import { Branch } from 'src/app/model/employees/branch';
import { Bank } from 'src/app/model/employees/bank';
import { TableCompose } from 'src/app/provider/table/table-compose';
import { HttpRequestComponent } from 'src/app/provider/http-request/http-request.component';
import { DataType } from 'src/app/provider/table/data-type.enum';
import swal from 'sweetalert2';

@Component({
  selector: 'app-branches',
  templateUrl: './branches.component.html',
  styleUrls: ['./branches.component.scss']
})
export class BranchesComponent implements OnInit {

  branchDetails: Branch[];
  bankDetails: Bank[];
  tableData: TableCompose;
  selected: Branch;
  isAdd: boolean;

  constructor(private http: HttpRequestComponent) { }

  ngOnInit() {
    this.getBranches()
  }

  getBranches(){
    this.http.get('/bank', (banks) => {
      this.bankDetails = banks;
      console.log("banks "+this.bankDetails)
      this.loadBranches();
    })
  }

  loadBranches(){
    this.http.get('/branch', (assets) => this.loadBranches2(assets));
  }

  mapBanks(bankId: number): Bank {
    return this.bankDetails.find(type => type.bankId == bankId);
  }

  loadBranches2(branches: Branch[]){
    branches.forEach(asset => asset.bankName = this.mapBanks(asset.bankId));
    this.branchDetails = branches;
    console.log(this.branchDetails)
    this.tableData = new TableCompose()
      .composeHeader('branchId', 'BranchId', DataType.Plain)
      .composeHeader('bankName', 'Bank', DataType.Selection , 'bankName')
      .composeHeader('branchName', 'Branch Name', DataType.Plain)
      .setBody(this.branchDetails);
  }

  itemClick(item) {
    this.selected = item;
    this.isAdd = false;
  }

  addClick() {
    this.selected = new Branch();
    this.isAdd = true;
  }

  editClick(item) {
    this.selected = item;
    this.isAdd = true;
  }

  deleteClick(item: Branch) {
    this.http.delete('/branch/' + item.bankId, (result) => {
      swal('', result.message, 'success');
      this.reloadBranches(result)
    });
  }
  
  reloadBranches(asset) {
    this.isAdd = false;
    this.selected = null;
    this.getBranches()
  }

}
