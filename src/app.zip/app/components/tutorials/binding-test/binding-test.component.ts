import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-binding-test',
  templateUrl: './binding-test.component.html',
  styleUrls: ['./binding-test.component.scss']
})
export class BindingTestComponent implements OnInit {

  public isEnabled: boolean;
  public successClass = "text-mySuccess";
  public isSpecial = false;
  public hasError = true;

  //two-way name gets updated as the view gets updated
  name="";

  // style binding
  public highlightColor = "orange";

  public classesToBeApplied = {
    "text-mySuccess": !this.hasError,
    "text-myDanger": this.hasError,
    "text-mySpecial": this.isSpecial
  };

  constructor() { }

  ngOnInit() {
  }

  enable(){
    if(this.isEnabled) this.isEnabled = false;
     else this.isEnabled = true;
    //this.isEnabled = !this.isEnabled;
  }

  special(){
    this.isSpecial = !this.isSpecial;
  }

  error(){
    console.log("error() "+this.hasError)
    this.hasError = !this.hasError;
  }
 
}
