import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-interpolation-test',
  templateUrl: './interpolation-test.component.html',
  styleUrls: ['./interpolation-test.component.scss']
})
export class InterpolationTestComponent implements OnInit {

  public name = "Nyasha";

  constructor() { }

  ngOnInit() {
  }

}
