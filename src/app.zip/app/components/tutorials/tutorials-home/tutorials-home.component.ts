import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tutorials-home',
  templateUrl: './tutorials-home.component.html',
  styleUrls: ['./tutorials-home.component.scss']
})
export class TutorialsHomeComponent implements OnInit {

  public name = "Nyasha Nyabz";
  public message = "";

  constructor() { }

  ngOnInit() {
  }

  receiveMessage(event){
    this.message = event;
  }

}
