import { Component, OnInit } from '@angular/core';
import {QuantityTypes} from 'src/app/model/kitchen/quantityTypes';
import { TableCompose } from 'src/app/provider/table/table-compose';
import { DataType } from 'src/app/provider/table/data-type.enum';
import { HttpRequestComponent } from 'src/app/provider/http-request/http-request.component';
import swal from 'sweetalert2';


@Component({
  selector: 'app-kitchen-quantity-type',
  templateUrl: './kitchen-quantity-type.component.html',
  styleUrls: ['./kitchen-quantity-type.component.scss']
})
export class KitchenQuantityTypeComponent implements OnInit {
   tableData:TableCompose;
   quantityTypes:any[];
   selectedQuantityType:any;
   isAdd:boolean;
  constructor(private http:HttpRequestComponent) {
       this.fetchQuantityTypes();
   }

  ngOnInit() {

  }

  fetchQuantityTypes() {
    this.http.get('/kitchen/inventory/quantity/type', (quantityTypes) => this.getQuantityType(quantityTypes));
  }

  getQuantityType(quantityTypes: QuantityTypes[]) {
    this.quantityTypes = quantityTypes
    this.tableData = new TableCompose()
      .composeHeader('name', 'Quantity Name', DataType.Plain)
      .setBody(this.quantityTypes);
  }

  itemClick(item) {
    this.selectedQuantityType = item;
    this.isAdd = false;
  }
 
  addClick() {
    this.selectedQuantityType ={}
    this.isAdd = true;
    console.log();
  }

  editClick(item) {
    this.selectedQuantityType = item;
    this.isAdd = true;
  }

  deleteClick(item:QuantityTypes) {
    this.http.delete('/kitchen/inventory/quantity/type/' + item.id, (result) => {
      swal('', result.message, 'success'); 
       this.reloadQuantityType(result)
    });
  }

  reloadQuantityType($event) {
    this.fetchQuantityTypes();
    this.isAdd = false;
    this.selectedQuantityType= null;
  }
}
