import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { QuantityTypes } from '../../../../../model/kitchen/quantityTypes';
import { Validation } from 'src/app/provider/validation/validation';
import { ValidationType } from 'src/app/provider/validation/validation-type.enum';
import { HttpRequestComponent } from 'src/app/provider/http-request/http-request.component';
import swal from 'sweetalert2';

@Component({
  selector: 'app-capture-kitchen-quantity',
  templateUrl: './capture-kitchen-quantity.component.html',
  styleUrls: ['./capture-kitchen-quantity.component.scss']
})
export class CaptureKitchenQuantityComponent implements OnInit {
  @Input() quantityType: QuantityTypes
  @Output() data: EventEmitter<any> = new EventEmitter<QuantityTypes>();
  validation: Validation;

  constructor(private http: HttpRequestComponent) { }

  ngOnInit() {
    if (this.quantityType == null) this.quantityType = new QuantityTypes();
    this.loadValidation();
  }


  loadValidation() {
    this.validation = new Validation();
    this.validation.addField({ name: 'name', display: 'Quantity Type Name', type: ValidationType.Required });
  }

  onSubmitType() {
    if (this.quantityType.id > 0) {
      this.http.update('/kitchen/inventory/quantity/type/' + this.quantityType.id , this.quantityType, (result) => {
        swal('', result.message, 'success');
        this.data.emit(this.quantityType);
      });
      return;

    } else {
      this.http.post('/kitchen/inventory/quantity/type', this.quantityType, (result) => {
        swal('', result.message, 'success');
        this.data.emit(this.quantityType);
      });
    }

  }
}
