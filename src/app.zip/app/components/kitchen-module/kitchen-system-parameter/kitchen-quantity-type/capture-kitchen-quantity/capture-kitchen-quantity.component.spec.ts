import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CaptureKitchenQuantityComponent } from './capture-kitchen-quantity.component';

describe('CaptureKitchenQuantityComponent', () => {
  let component: CaptureKitchenQuantityComponent;
  let fixture: ComponentFixture<CaptureKitchenQuantityComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CaptureKitchenQuantityComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CaptureKitchenQuantityComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
