import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { KitchenQuantityTypeComponent } from './kitchen-quantity-type.component';

describe('KitchenQuantityTypeComponent', () => {
  let component: KitchenQuantityTypeComponent;
  let fixture: ComponentFixture<KitchenQuantityTypeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ KitchenQuantityTypeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(KitchenQuantityTypeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
