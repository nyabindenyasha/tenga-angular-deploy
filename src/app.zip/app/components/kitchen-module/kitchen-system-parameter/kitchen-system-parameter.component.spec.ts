import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { KitchenSystemParameterComponent } from './kitchen-system-parameter.component';

describe('KitchenSystemParameterComponent', () => {
  let component: KitchenSystemParameterComponent;
  let fixture: ComponentFixture<KitchenSystemParameterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ KitchenSystemParameterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(KitchenSystemParameterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
