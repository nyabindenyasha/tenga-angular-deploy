
import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Validation } from 'src/app/provider/validation/validation';
import { ValidationType } from 'src/app/provider/validation/validation-type.enum';
import { HttpRequestComponent } from 'src/app/provider/http-request/http-request.component';
import swal from 'sweetalert2';
import { KitchenTasks } from 'src/app/model/kitchen/kitchen-tasks';


@Component({
  selector: 'app-capture-kitchen-tasks',
  templateUrl: './capture-kitchen-tasks.component.html',
  styleUrls: ['./capture-kitchen-tasks.component.scss']
})
export class CaptureKitchenTasksComponent implements OnInit {

  @Input() task: KitchenTasks
  @Output() emitter = new EventEmitter<KitchenTasks>()
  validation: Validation;

  constructor(private http: HttpRequestComponent) { }

  ngOnInit() {
     if (this.task == null)
     this.task = new KitchenTasks();
     this.loadValidation();
  }

  loadValidation(){
    this.validation = new Validation();
    this.validation.addField({ name: 'name', display: 'Kitchen Task', type: ValidationType.Required });
  
  }

  onSubmit(){
    if(this.task.id)
      this.http.put('/kitchen/task/' +this.task.id, this.task, (result) => swal(result.message,'', 'success'));
    else 
      this.http.post('/kitchen/task', this.task, (result) => swal(result.message,'', 'success'));
      
    this.emitter.emit(this.task);
  }
}
