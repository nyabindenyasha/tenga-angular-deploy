import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CaptureKitchenTasksComponent } from './capture-kitchen-tasks.component';

describe('CaptureKitchenTasksComponent', () => {
  let component: CaptureKitchenTasksComponent;
  let fixture: ComponentFixture<CaptureKitchenTasksComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CaptureKitchenTasksComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CaptureKitchenTasksComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
