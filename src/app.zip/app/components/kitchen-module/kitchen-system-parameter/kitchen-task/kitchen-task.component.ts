import { Component, OnInit } from '@angular/core';
import { HttpRequestComponent } from 'src/app/provider/http-request/http-request.component';
import { TableCompose } from 'src/app/provider/table/table-compose';
import { DataType } from 'src/app/provider/table/data-type.enum';
import { KitchenTasks } from 'src/app/model/kitchen/kitchen-tasks';
import swal from 'sweetalert2';

@Component({
  selector: 'app-kitchen-task',
  templateUrl: './kitchen-task.component.html',
  styleUrls: ['./kitchen-task.component.scss']
})
export class KitchenTaskComponent implements OnInit {
  tasks: any;
  tableData: any;
  selectedTask: any;
  isAdd: boolean;

  constructor(private http: HttpRequestComponent) { }

  ngOnInit() {
    this.getTasks();
  }

  getTasks(){
    this.http.get('/kitchen/task', (tasks) => this.KitchenTasks(tasks));
  }
  
  KitchenTasks(tasks:KitchenTasks[]) { 
    this.tasks=tasks;
    this.tableData = new TableCompose()
      .composeHeader('name','Task Name',DataType.Plain)
      .setBody(this.tasks);
 }

  itemClick(task) {
    this.selectedTask = task;
    this.isAdd = false;
  }

  addClick() {
    this.selectedTask = new KitchenTasks();
    this.isAdd = true;
  }

  editClick(item) {
    this.selectedTask = item;
    this.isAdd = true;
  }

  deleteClick(task: KitchenTasks) {
    this.http.delete('/kitchen/task/' + task.id, (result) => {
      swal('', result.message, 'success');
      this.reloadTasks(result)
    });
  }

  reloadTasks(task) {  
    this.isAdd = false;
    this.selectedTask = task = null;
    this.tasks = null;
    setTimeout(() => {
      this.getTasks();
    }, 100);
  }
}
