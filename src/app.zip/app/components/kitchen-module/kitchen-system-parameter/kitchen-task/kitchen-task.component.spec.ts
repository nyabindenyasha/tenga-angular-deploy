import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { KitchenTaskComponent } from './kitchen-task.component';

describe('KitchenTaskComponent', () => {
  let component: KitchenTaskComponent;
  let fixture: ComponentFixture<KitchenTaskComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ KitchenTaskComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(KitchenTaskComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
