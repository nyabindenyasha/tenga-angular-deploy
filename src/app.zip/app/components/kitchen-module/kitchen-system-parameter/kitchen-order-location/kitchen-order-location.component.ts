import { Component, OnInit } from '@angular/core';
import { TableCompose } from 'src/app/provider/table/table-compose';
import { DataType } from 'src/app/provider/table/data-type.enum';
import {KitchenOrderLocation } from 'src/app/model/kitchen/kitchen-order-location';
import { HttpRequestComponent } from 'src/app/provider/http-request/http-request.component';
import swal from 'sweetalert2';

@Component({
  selector: 'app-kitchen-order-location',
  templateUrl: './kitchen-order-location.component.html',
  styleUrls: ['./kitchen-order-location.component.scss']
})
export class KitchenOrderLocationComponent implements OnInit {
 orderLocationDetails: KitchenOrderLocation[]; 
  tableData: TableCompose;
  selected: any;
  isAdd: boolean;

  constructor(private http: HttpRequestComponent) { 
    this.getLocations();
  }

  ngOnInit() {
  }  
  getLocations(){
    this.http.get('/order/location', (locations) => this.loadOrderLocation(locations));
  }
  

  loadOrderLocation(locations: KitchenOrderLocation[]) {  
    this.orderLocationDetails = locations
    this.tableData = new TableCompose()
      .composeHeader('name', ' Name ', DataType.Plain)
      .setBody(this.orderLocationDetails);
  }

  itemClick(item) {
    this.selected = item;
    this.isAdd = false;
  }
  addClick() {
    this.selected = {};
    this.isAdd = true;
  }
  editClick(item) {
    this.selected = item;
    this.isAdd = true;
  }
  
  deleteClick(item:KitchenOrderLocation) {
    this.http.delete('/order/location/' + item.id, (result) => {
      swal('', result.message, 'success'); 
      console.log(result);    
       this.reloadOrderLocations(result)
    });

  }
  reloadOrderLocations($event) {
    setTimeout(() => {
      this.getLocations();
    }, 1000);
    this.isAdd = false;
    this.selected = null;
  }

}
