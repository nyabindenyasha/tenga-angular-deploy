import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import {KitchenOrderLocation } from 'src/app/model/kitchen/kitchen-order-location';
import { Validation } from 'src/app/provider/validation/validation';
import { ValidationType } from 'src/app/provider/validation/validation-type.enum';
import { HttpRequestComponent } from 'src/app/provider/http-request/http-request.component';
import swal from 'sweetalert2';

@Component({
  selector: 'app-capture-kitchen-order-location',
  templateUrl: './capture-kitchen-order-location.component.html',
  styleUrls: ['./capture-kitchen-order-location.component.scss']
})
export class CaptureKitchenOrderLocationComponent implements OnInit {
  @Input() orderLocation: KitchenOrderLocation
  @Output() data: EventEmitter<any> = new EventEmitter<KitchenOrderLocation>();
  validation: Validation;
  constructor(private http: HttpRequestComponent) { }

  ngOnInit() {
    if (this.orderLocation == null) this.orderLocation = new KitchenOrderLocation();
    this.loadValidation();
  }


  loadValidation() {
    this.validation = new Validation();
    this.validation.addField({ name: 'name', display: 'Location Name', type: ValidationType.Required });
  }

  onSubmitLocation() {
    if (this.orderLocation.id > 0) {
      this.http.update('/order/location/' + this.orderLocation.id, this.orderLocation, (result) => swal('', result.message, 'success'));
      this.data.emit(this.orderLocation);

      return;

    } else {
      this.http.post('/order/location', this.orderLocation, (result) => swal('', result.message, 'success'));
      this.data.emit(this.orderLocation);

    }

  }

}
