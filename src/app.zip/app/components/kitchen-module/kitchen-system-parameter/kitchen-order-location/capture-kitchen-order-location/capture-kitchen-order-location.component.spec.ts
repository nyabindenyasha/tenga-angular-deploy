import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CaptureKitchenOrderLocationComponent } from './capture-kitchen-order-location.component';

describe('CaptureKitchenOrderLocationComponent', () => {
  let component: CaptureKitchenOrderLocationComponent;
  let fixture: ComponentFixture<CaptureKitchenOrderLocationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CaptureKitchenOrderLocationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CaptureKitchenOrderLocationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
