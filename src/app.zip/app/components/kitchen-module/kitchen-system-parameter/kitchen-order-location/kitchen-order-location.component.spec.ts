import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { KitchenOrderLocationComponent } from './kitchen-order-location.component';

describe('KitchenOrderLocationComponent', () => {
  let component: KitchenOrderLocationComponent;
  let fixture: ComponentFixture<KitchenOrderLocationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ KitchenOrderLocationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(KitchenOrderLocationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
