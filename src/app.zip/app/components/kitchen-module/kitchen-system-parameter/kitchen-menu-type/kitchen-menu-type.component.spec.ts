import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { KitchenMenuTypeComponent } from './kitchen-menu-type.component';

describe('KitchenMenuTypeComponent', () => {
  let component: KitchenMenuTypeComponent;
  let fixture: ComponentFixture<KitchenMenuTypeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ KitchenMenuTypeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(KitchenMenuTypeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
