import { Component, OnInit } from '@angular/core';
import { TableCompose } from 'src/app/provider/table/table-compose';
import { DataType } from 'src/app/provider/table/data-type.enum';
import { HttpRequestComponent } from 'src/app/provider/http-request/http-request.component';
import { KitchenFoodMenu } from 'src/app/model/kitchen/kitchen-food-menu';

@Component({
  selector: 'app-kitchen-menu-type',
  templateUrl: './kitchen-menu-type.component.html',
  styleUrls: ['./kitchen-menu-type.component.scss']
})
export class KitchenMenuTypeComponent implements OnInit {
  _search : boolean = false;
  foodItems: KitchenFoodMenu[] = [];
  tableData: TableCompose;
  selected: any;
  isAdd: boolean;
  constructor(private http: HttpRequestComponent) {
  this.fetchfoodMenuItems();
  }

  ngOnInit() {
    this._search = true;
  }
  fetchfoodMenuItems() {
    this.http.get('/food/menu', (fooditems) => this.foodMenuItems(fooditems));
  }

  foodMenuItems(menu: KitchenFoodMenu[]) {
    this.foodItems = menu;
    this.tableData = new TableCompose()
      .composeHeader('name', 'Name', DataType.Plain)
      .composeHeader('cost', 'Price', DataType.Money)
      .composeHeader('isAvailable', 'Food Available?', DataType.Check)
      .setBody(this.foodItems);
  }

  itemClick(item) {
    this.selected = item;
    this.isAdd = false;
  }

  addClick() {
    this.selected = {};
    this.isAdd = true;
  }

  editClick(item) {
    this.selected = item;
    this.isAdd = true;
  }

  reloadKitchenMenuType($event) {
    this.fetchfoodMenuItems()
    this.isAdd = false;
    this.selected = null;
  }
}