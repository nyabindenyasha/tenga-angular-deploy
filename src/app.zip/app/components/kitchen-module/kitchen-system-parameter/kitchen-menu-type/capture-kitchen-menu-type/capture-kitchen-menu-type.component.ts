import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Validation } from 'src/app/provider/validation/validation';
import { ValidationType } from 'src/app/provider/validation/validation-type.enum';
import swal from 'sweetalert2';
import { HttpRequestComponent } from 'src/app/provider/http-request/http-request.component';
import { KitchenFoodMenu } from 'src/app/model/kitchen/kitchen-food-menu';

@Component({
  selector: 'app-capture-kitchen-menu-type',
  templateUrl: './capture-kitchen-menu-type.component.html',
  styleUrls: ['./capture-kitchen-menu-type.component.scss']
})
export class CaptureKitchenMenuTypeComponent implements OnInit {
  @Input() menu: KitchenFoodMenu;
  @Output() result: EventEmitter<any> = new EventEmitter<KitchenFoodMenu>();
  validation: Validation

  constructor(private http: HttpRequestComponent) { }

  ngOnInit() {
    if (this.menu == null)
      this.menu = new KitchenFoodMenu();
    this.loadValidation();
  }
  loadValidation() {
    this.validation = new Validation();
    this.validation.addField({ name: 'name', display: 'Food Menu', type: ValidationType.Required });
    this.validation.addField({ name: 'cost', display: 'Cost', type: ValidationType.GreaterThan }, 0);
  }

  onSubmitMenu() {
    if (this.menu.id > 0) {
      this.http.update('food/menu/' + this.menu.id, this.menu, (result) => this.submitResult(result, 'updated'));
      return;
    }
    this.http.post('food/menu', this.menu, (result) => this.submitResult(result, 'added'));
  }

  submitResult(result, message) {
    swal('', 'Menu successfully ' + message, 'success');
    this.result.emit(this.menu);
  }
}