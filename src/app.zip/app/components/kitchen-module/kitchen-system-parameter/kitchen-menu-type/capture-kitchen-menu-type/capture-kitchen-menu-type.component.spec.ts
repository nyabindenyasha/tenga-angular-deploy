import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CaptureKitchenMenuTypeComponent } from './capture-kitchen-menu-type.component';

describe('CaptureKitchenMenuTypeComponent', () => {
  let component: CaptureKitchenMenuTypeComponent;
  let fixture: ComponentFixture<CaptureKitchenMenuTypeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CaptureKitchenMenuTypeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CaptureKitchenMenuTypeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
