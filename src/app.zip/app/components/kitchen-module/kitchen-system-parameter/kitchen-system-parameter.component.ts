import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-kitchen-system-parameter',
  templateUrl: './kitchen-system-parameter.component.html',
  styleUrls: ['./kitchen-system-parameter.component.scss']
})
export class KitchenSystemParameterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
