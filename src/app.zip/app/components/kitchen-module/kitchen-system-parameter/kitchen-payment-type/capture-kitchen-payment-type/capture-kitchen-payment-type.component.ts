import { Component, OnInit } from '@angular/core';
import { Validation } from 'src/app/provider/validation/validation';
import { ValidationType } from 'src/app/provider/validation/validation-type.enum';
import { HttpRequestComponent } from 'src/app/provider/http-request/http-request.component';
import swal from 'sweetalert2';
import { PaymentType } from 'src/app/model/kitchen/kitchen-payment-type';
import { EventEmitter, Output, Input } from '@angular/core';

@Component({
  selector: 'app-capture-kitchen-payment-type',
  templateUrl: './capture-kitchen-payment-type.component.html',
  styleUrls: ['./capture-kitchen-payment-type.component.scss']
})
export class CaptureKitchenPaymentTypeComponent implements OnInit {
  @Input() paymentType: PaymentType;
  @Output() data: EventEmitter<any> = new EventEmitter<PaymentType>()
  validation: Validation;
  constructor( private http : HttpRequestComponent) { }

  ngOnInit() {
    if (this.paymentType == null)
    this.paymentType = new PaymentType();
    this.loadValidation();
  }

 loadValidation(){
   this.validation = new Validation();
   this.validation.addField({ name: 'name', display: 'Kitchen Payment Type', type: ValidationType.Required });
 }
 onSubmit(){
   this.http.post('/payment/type', this.paymentType, (result) => swal('', result.message, 'success'));
   this.data.emit(this.paymentType);
 }
}
