import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CaptureKitchenPaymentTypeComponent } from './capture-kitchen-payment-type.component';

describe('CaptureKitchenPaymentTypeComponent', () => {
  let component: CaptureKitchenPaymentTypeComponent;
  let fixture: ComponentFixture<CaptureKitchenPaymentTypeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CaptureKitchenPaymentTypeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CaptureKitchenPaymentTypeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
