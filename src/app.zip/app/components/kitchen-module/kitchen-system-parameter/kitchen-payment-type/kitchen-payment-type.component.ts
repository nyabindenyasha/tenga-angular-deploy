import { Component, OnInit } from '@angular/core';
import { TableCompose } from 'src/app/provider/table/table-compose';
import { DataType } from 'src/app/provider/table/data-type.enum';
import { HttpRequestComponent } from 'src/app/provider/http-request/http-request.component';
import { PaymentType } from 'src/app/model/kitchen/kitchen-payment-type';
import swal from 'sweetalert2';

@Component({
  selector: 'app-kitchen-payment-type',
  templateUrl: './kitchen-payment-type.component.html',
  styleUrls: ['./kitchen-payment-type.component.scss']
})
export class KitchenPaymentTypeComponent implements OnInit {
  isAdd: boolean;
  selected: any;
  tableData: TableCompose;
  paymentType: PaymentType[];
  constructor(private http: HttpRequestComponent) {

  }

  ngOnInit() {
    this.getPaymentTypes();
  }
  getPaymentTypes() {
    this.http.get('/payment/type', (result) => this.paymentTypes(result));
  }

  paymentTypes(type: PaymentType[]) {
    this.paymentType = type;
    this.tableData = new TableCompose()
      .composeHeader('name', 'Payment Type', DataType.Plain)
      .setBody(this.paymentType);
  }
  itemClick(item) {
    this.selected = item;
    this.isAdd = false;
  }
  addClick() {
    this.selected = {};
    this.isAdd = true;
  }
  editClick(item) {
    this.selected = item;
    this.isAdd = true;
  }
  deleteClick(item: PaymentType) {
    this.http.delete('/payment/type/' + item.id, (result) => {
      swal('', result.message, 'success')
    });
    setTimeout(()=> {
      this.getPaymentTypes();
    }, 100);
    this.reloadPaymentType(item);
  }
  reloadPaymentType(item) {
    setTimeout(()=> {
      this.getPaymentTypes();
    }, 10);
    this.isAdd = false;
    this.selected = null;
  }
}
