import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { KitchenPaymentTypeComponent } from './kitchen-payment-type.component';

describe('KitchenPaymentTypeComponent', () => {
  let component: KitchenPaymentTypeComponent;
  let fixture: ComponentFixture<KitchenPaymentTypeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ KitchenPaymentTypeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(KitchenPaymentTypeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
