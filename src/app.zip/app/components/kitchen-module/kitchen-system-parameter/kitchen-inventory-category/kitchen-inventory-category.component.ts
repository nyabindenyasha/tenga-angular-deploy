import { Component, OnInit } from '@angular/core';
import { TableCompose } from 'src/app/provider/table/table-compose';
import { DataType } from 'src/app/provider/table/data-type.enum';
import { KitchenInventoryCategory } from 'src/app/model/kitchen/kitchen-inventory-category';
import { HttpRequestComponent } from 'src/app/provider/http-request/http-request.component';
import { QuantityTypes } from 'src/app/model/kitchen/quantityTypes';
import { KitchenInventoryType } from 'src/app/model/kitchen/kitchen-inventory-type';
import swal from 'sweetalert2';

@Component({
  selector: 'app-kitchen-inventory-category',
  templateUrl: './kitchen-inventory-category.component.html',
  styleUrls: ['./kitchen-inventory-category.component.scss']
})
export class KitchenInventoryCategoryComponent implements OnInit {
  inventoryCategoryDetails: KitchenInventoryCategory[];
  quantityTypeDetails: QuantityTypes[];
  inventoryTypeDetails: KitchenInventoryType[];
  tableData: TableCompose;
  selected: any;
  isAdd: boolean;


  constructor(private http: HttpRequestComponent) { }

  ngOnInit() {
    this.getKitchenQuantityType();
    this.getKitchenInventoryType();
  }

  getKitchenQuantityType() {
    this.http.get('/kitchen/inventory/quantity/type', (quantityType) => {
      this.quantityTypeDetails = quantityType;
      console.log("quantityTypeDetails "+this.quantityTypeDetails)
      this.loadCategories();
    })
  }

  getKitchenInventoryType() {
    this.http.get('/kitchen/inventory/type', (inventoryType) => {
      this.inventoryTypeDetails = inventoryType;
    })
  }

  loadCategories() {
    this.http.get('/kitchen/inventory/category', (categories) => this.loadInventoryCategory(categories));
  }

  mapQuantityType(quantityTypeid: number): QuantityTypes {
    return this.quantityTypeDetails.find(type => type.id == quantityTypeid);
  }


  mapInventoryType(typeId: number): KitchenInventoryType {
    return this.inventoryTypeDetails.find(type => type.id == typeId);
  }

  loadInventoryCategory(categories: KitchenInventoryCategory[]) {
    categories.forEach(category => category.quantityTypeName = this.mapQuantityType(category.quantityTypeid));
    categories.forEach(category => category.typeName = this.mapInventoryType(category.typeId));
    this.inventoryCategoryDetails = categories
    console.log(this.inventoryCategoryDetails);
    this.tableData = new TableCompose()
      .composeHeader('name', ' Name ', DataType.Plain)
      .composeHeader('typeName', 'Type', DataType.Selection, 'name')
      .composeHeader('quantityTypeName', 'Quantity Type', DataType.Selection, 'name')
      .setBody(this.inventoryCategoryDetails);
  }
  
  itemClick(item) {
    this.selected = item;
    this.isAdd = false;
  }
  addClick() {
    this.selected = {};
    this.isAdd = true;
  }
  editClick(item) {
    this.selected = item;
    this.isAdd = true;
  }

  deleteClick(item:KitchenInventoryCategory) {
    this.http.delete('/kitchen/inventory/category/' + item.id, (result) => {
      swal('', result.message, 'success'); 
      console.log(result);    
       this.reloadInventoryCategories(result)
    });
  
  }
  reloadInventoryCategories($event) {
    setTimeout(() => {
      this.loadCategories();
    }, 1000);
    this.isAdd = false;
    this.selected = null;
  }
}
