import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { KitchenInventoryCategoryComponent } from './kitchen-inventory-category.component';

describe('KitchenInventoryCategoryComponent', () => {
  let component: KitchenInventoryCategoryComponent;
  let fixture: ComponentFixture<KitchenInventoryCategoryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ KitchenInventoryCategoryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(KitchenInventoryCategoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
