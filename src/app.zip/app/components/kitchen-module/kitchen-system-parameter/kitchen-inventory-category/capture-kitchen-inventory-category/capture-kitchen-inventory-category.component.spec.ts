import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CaptureKitchenInventoryCategoryComponent } from './capture-kitchen-inventory-category.component';

describe('CaptureKitchenInventoryCategoryComponent', () => {
  let component: CaptureKitchenInventoryCategoryComponent;
  let fixture: ComponentFixture<CaptureKitchenInventoryCategoryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CaptureKitchenInventoryCategoryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CaptureKitchenInventoryCategoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
