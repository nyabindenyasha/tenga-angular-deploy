import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { KitchenInventoryCategory } from 'src/app/model/kitchen/kitchen-inventory-category';
import { Validation } from 'src/app/provider/validation/validation';
import { ValidationType } from 'src/app/provider/validation/validation-type.enum';
import { HttpRequestComponent } from 'src/app/provider/http-request/http-request.component';
import swal from 'sweetalert2';

@Component({
  selector: 'app-capture-kitchen-inventory-category',
  templateUrl: './capture-kitchen-inventory-category.component.html',
  styleUrls: ['./capture-kitchen-inventory-category.component.scss']
})
export class CaptureKitchenInventoryCategoryComponent implements OnInit {
  @Input() inventoryCategory: KitchenInventoryCategory
  @Output() data: EventEmitter<any> = new EventEmitter<KitchenInventoryCategory>();
  validation: Validation;
  inventoryTypes: any[];
  quantityTypes: any[];
  constructor(private http: HttpRequestComponent) {
    this.http.get('/kitchen/inventory/type', (type) => this.getInventoryType(type));
    this.http.get('/kitchen/inventory/quantity/type', (type) => this.getQuantityType(type))
  }

  ngOnInit() {
    if (this.inventoryCategory == null) this.inventoryCategory = new KitchenInventoryCategory();
    this.loadValidation();
  }
  getInventoryType(type) {
    this.inventoryTypes = type;
  }

  getQuantityType(type) {
    this.quantityTypes = type;
  }

  loadValidation() {
    this.validation = new Validation();
    this.validation.addField({ name: 'name', display: 'Category  Name', type: ValidationType.Required });
    this.validation.addField({ name: 'typeId', display: '  Inventory Type ', type: ValidationType.Required });
    this.validation.addField({ name: 'quantityTypeid', display: 'Quantity Type ', type: ValidationType.Required });
  }

  onSubmitCategory() {
    if (this.inventoryCategory.id > 0) {
      this.http.update('/kitchen/inventory/category/' + this.inventoryCategory.id, this.inventoryCategory, (result) => swal('', result.message, 'success'));
      this.data.emit(this.inventoryCategory);

      return;

    } else {
      this.http.post('/kitchen/inventory/category', this.inventoryCategory, (result) => swal('', result.message, 'success'));
      this.data.emit(this.inventoryCategory);

    }

  }
}