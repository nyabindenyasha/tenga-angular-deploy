import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CaptureKitchenInventoryTypeComponent } from './capture-kitchen-inventory-type.component';

describe('CaptureKitchenInventoryTypeComponent', () => {
  let component: CaptureKitchenInventoryTypeComponent;
  let fixture: ComponentFixture<CaptureKitchenInventoryTypeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CaptureKitchenInventoryTypeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CaptureKitchenInventoryTypeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
