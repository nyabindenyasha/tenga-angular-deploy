import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { KitchenInventoryType } from 'src/app/model/kitchen/kitchen-inventory-type';
import { KitchenInventoryCategory } from 'src/app/model/kitchen/kitchen-inventory-category';
import { Validation } from 'src/app/provider/validation/validation';
import { HttpRequestComponent } from 'src/app/provider/http-request/http-request.component';
import { ValidationType } from 'src/app/provider/validation/validation-type.enum';
import swal from 'sweetalert2';

@Component({
  selector: 'app-capture-kitchen-inventory-type',
  templateUrl: './capture-kitchen-inventory-type.component.html',
  styleUrls: ['./capture-kitchen-inventory-type.component.scss']
})
export class CaptureKitchenInventoryTypeComponent implements OnInit {
  @Input() inventory: KitchenInventoryType
  @Output() data: EventEmitter<any> = new EventEmitter<KitchenInventoryCategory>()
  validation: Validation;

  constructor(private http: HttpRequestComponent) { }

  ngOnInit() {
    if (this.inventory == null)
      this.inventory = new KitchenInventoryType();
    this.loadValidation();
  }

  loadValidation() {
    this.validation = new Validation();
    this.validation.addField({ name: 'name', display: 'Kitchen Inventory Type', type: ValidationType.Required });

  }

  onSubmitInventory() {
    this.http.post('/kitchen/inventory', this.inventory, (result) => {
      swal('', result.message, 'success')
      this.data.emit(this.inventory);
    });
  }
}
