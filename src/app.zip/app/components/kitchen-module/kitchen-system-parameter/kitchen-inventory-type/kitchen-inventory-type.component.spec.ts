import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { KitchenInventoryTypeComponent } from './kitchen-inventory-type.component';

describe('KitchenInventoryTypeComponent', () => {
  let component: KitchenInventoryTypeComponent;
  let fixture: ComponentFixture<KitchenInventoryTypeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ KitchenInventoryTypeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(KitchenInventoryTypeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
