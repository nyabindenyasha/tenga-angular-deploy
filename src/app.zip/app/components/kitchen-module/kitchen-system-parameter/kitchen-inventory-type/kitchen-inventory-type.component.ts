import { Component, OnInit } from '@angular/core';
import { KitchenInventoryType } from 'src/app/model/kitchen/kitchen-inventory-type';
import { TableCompose } from 'src/app/provider/table/table-compose';
import { HttpRequestComponent } from 'src/app/provider/http-request/http-request.component';
import { DataType } from 'src/app/provider/table/data-type.enum';
import swal from 'sweetalert2';

@Component({
  selector: 'app-kitchen-inventory-type',
  templateUrl: './kitchen-inventory-type.component.html',
  styleUrls: ['./kitchen-inventory-type.component.scss']
})
export class KitchenInventoryTypeComponent implements OnInit {

  inventoryTypes: KitchenInventoryType[];
  tableData: TableCompose;
  selected: any;
  isAdd: boolean;

  constructor(private http: HttpRequestComponent) { }

  ngOnInit() {
    this.getKitchenInventoryType();
  }

  getKitchenInventoryType() {
    this.http.get('/kitchen/inventory', (inventoryTypes) => this.kitchenInventoryTypes(inventoryTypes));
  }

  kitchenInventoryTypes(inventory: KitchenInventoryType[]) {
    this.inventoryTypes = inventory;
    this.tableData = new TableCompose()
      .composeHeader('name', 'Name', DataType.Plain)
      .setBody(this.inventoryTypes);
  }

  itemClick(item) {
    this.selected = item;
    this.isAdd = false;
  }

  addClick() {
    this.selected = {};
    this.isAdd = true;
  }

  editClick(item) {
    this.selected = item;
    this.isAdd = true;
  }

  deleteClick(item: KitchenInventoryType) {
    this.http.delete('/kitchen/inventory/' + item.id, (result) => {
      swal('', result.message, 'success');
      this.reloadKitchenInventoryType(result)
    });
  }


  reloadKitchenInventoryType($event) {
    this.getKitchenInventoryType()
    this.isAdd = false;
    this.selected = null;
  }
}
