import { Component, OnInit } from '@angular/core';
import { KitchenCreditTransactions } from 'src/app/model/kitchen/kitchen-credit-transactions';
import { TableCompose } from 'src/app/provider/table/table-compose';
import { DataType } from 'src/app/provider/table/data-type.enum';
import { HttpRequestComponent } from 'src/app/provider/http-request/http-request.component';
import { KitchenStaff } from 'src/app/model/kitchen/kitchen-staff';
import { KitchenSales } from 'src/app/model/kitchen/kitchen-sales'


@Component({
  selector: 'app-kitchen-credit-transactions',
  templateUrl: './kitchen-credit-transactions.component.html',
  styleUrls: ['./kitchen-credit-transactions.component.scss']
})
export class KitchenCreditTransactionsComponent implements OnInit {

  transactions = new Array<KitchenCreditTransactions>();
  workers: KitchenStaff[];
  sales: KitchenSales[];
  tableData: TableCompose;
  selected: any;
  isAdd: boolean;
  _search : boolean = false;

  constructor(private http: HttpRequestComponent) { }

  ngOnInit() {
    this._search = true;
    this.getKitchenStaff();
  }

  getKitchenStaff() {
    this.http.get('/staff', (staff) => {
      this.workers = staff;
      this.getKitchenSales();
    })
  }

  getKitchenSales() {
    this.http.get('/kitchen/sales', (sale) => {
      this.sales = sale;
      this.getCreditTransactions();
    })
  }


  getCreditTransactions() {
    this.http.get('/kitchen/credit/transactions', (transaction) => this.creditTransactions(transaction));
  }


  mapStaffName(staffId: number): KitchenStaff {
    return this.workers.find(staff => staff.id == staffId);
  }

  mapAmount(kitchenSalesId: number): KitchenSales {
    return this.sales.find(amount => amount.id == kitchenSalesId);
  }

  mapFoodName(kitchenSalesId: number): KitchenSales {
    return this.sales.find(name => name.id == kitchenSalesId)
  }

  creditTransactions(transaction: KitchenCreditTransactions[]) {
    this.transactions = transaction;
    transaction.forEach(name => name.staffName = this.mapStaffName(name.staffId));
    transaction.forEach(figure => figure.amount = this.mapAmount(figure.kitchenSalesId));
    transaction.forEach(foodName => foodName.foodItem = this.mapFoodName(foodName.kitchenSalesId))
    this.tableData = new TableCompose()
      .composeHeader('staffName', 'Debtor', DataType.Selection, 'username')
      .composeHeader('foodItem', 'Food Item', DataType.Selection, 'foodName')
      .composeHeader('amount', 'Amount', DataType.Selection, 'cost')
      .composeHeader('dateCreated', 'Date', DataType.Date)
      .composeHeader('isPaid', 'Paid?', DataType.Check)
      .setBody(transaction);
  }


  itemClick(item) {
    this.selected = item;
    this.isAdd = false;
  }

  addClick() {
    this.selected = {};
    this.isAdd = true;
  }


}
