import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { KitchenCreditTransactionsComponent } from './kitchen-credit-transactions.component';

describe('KitchenCreditTransactionsComponent', () => {
  let component: KitchenCreditTransactionsComponent;
  let fixture: ComponentFixture<KitchenCreditTransactionsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ KitchenCreditTransactionsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(KitchenCreditTransactionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
