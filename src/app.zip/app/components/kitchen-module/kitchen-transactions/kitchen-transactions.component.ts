import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-kitchen-transactions',
  templateUrl: './kitchen-transactions.component.html',
  styleUrls: ['./kitchen-transactions.component.scss']
})
export class KitchenTransactionsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
