import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CaptureKitchenPurchaseComponent } from './capture-kitchen-purchase.component';

describe('CaptureKitchenPurchaseComponent', () => {
  let component: CaptureKitchenPurchaseComponent;
  let fixture: ComponentFixture<CaptureKitchenPurchaseComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CaptureKitchenPurchaseComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CaptureKitchenPurchaseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
