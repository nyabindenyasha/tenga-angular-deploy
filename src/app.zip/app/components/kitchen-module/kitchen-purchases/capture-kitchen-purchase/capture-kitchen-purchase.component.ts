import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { KitchenPurchases } from 'src/app/model/kitchen/kitchen-purchases';
import { HttpRequestComponent } from 'src/app/provider/http-request/http-request.component';
import { Validation } from 'src/app/provider/validation/validation';
import swal from 'sweetalert2';
import { KitchenInventoryCategory } from 'src/app/model/kitchen/kitchen-inventory-category';
import { ValidationType } from 'src/app/provider/validation/validation-type.enum';
import { KitchenPurchasesProcess, KitchenPurchasesProcessHelper } from 'src/app/model/kitchen/kitchen-purchases-process';

@Component({
  selector: 'app-capture-kitchen-purchase',
  templateUrl: './capture-kitchen-purchase.component.html',
  styleUrls: ['./capture-kitchen-purchase.component.scss']
})
export class CaptureKitchenPurchaseComponent implements OnInit {

  @Input() purchase : KitchenPurchases;
  @Input() inventoryCategoryId;
  @Output() data: EventEmitter<any> = new EventEmitter<KitchenInventoryCategory>();
  categories : KitchenInventoryCategory[];
  processes:Array<KitchenPurchasesProcess> = [ KitchenPurchasesProcess.request, KitchenPurchasesProcess.approval, KitchenPurchasesProcess.collection, KitchenPurchasesProcess.reject,
     KitchenPurchasesProcess.delivered,
 ];
  kitchenProcesses: Array<any> = [];
  processHelper: KitchenPurchasesProcessHelper;
  message: boolean;
  process: string;
  type: any;
  validation : Validation


  constructor(private http : HttpRequestComponent) { 
    this.http.get('/kitchen/inventory/category', (assetCategories)=>this.getAssetCategories(assetCategories));
  }

  ngOnInit() {
    if (this.purchase == null)
     this.purchase = new KitchenPurchases();
    if(this.inventoryCategoryId) this.purchase.categoryId = this.inventoryCategoryId;
    this.loadValidation();
  }

   
  getAssetCategories(assetCategories: KitchenInventoryCategory[]){
    this.categories = assetCategories;
  }


  
  loadValidation() {
    this.validation = new Validation();
    this.validation.addField({ name: 'categoryId', display: 'Category', type: ValidationType.Required });
    this.validation.addField({ name: 'quantity', display: 'Quantity', type: ValidationType.GreaterThan}, 0);
    this.validation.addField({ name: 'cost', display: 'Cost', type: ValidationType.GreaterThan }, 0);
    this.validation.addField({ name: 'dateCreated', display: 'Date', type: ValidationType.Date },  new Date(this.purchase.dateCreated).getTime());
  }
  getDate(value){
    this.loadValidation();
  }

  onSubmitPurchase() {
      this.http.post('/kitchen/inventory/purchase', this.purchase, (result) => {
        swal('', result.message, 'success')
        this.data.emit(this.purchase);
      });  
  }

}

