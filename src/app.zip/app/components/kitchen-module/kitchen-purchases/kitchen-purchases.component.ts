import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { KitchenPurchases } from 'src/app/model/kitchen/kitchen-purchases';
import { TableCompose } from 'src/app/provider/table/table-compose';
import { DataType } from 'src/app/provider/table/data-type.enum';
import { HttpRequestComponent } from 'src/app/provider/http-request/http-request.component';
import { KitchenPurchasesProcessHelper, KitchenPurchasesProcess } from 'src/app/model/kitchen/kitchen-purchases-process';
import { KitchenInventoryCategory } from 'src/app/model/kitchen/kitchen-inventory-category'
import swal from 'sweetalert2';

@Component({
  selector: 'app-kitchen-purchases',
  templateUrl: './kitchen-purchases.component.html',
  styleUrls: ['./kitchen-purchases.component.scss']
})
export class KitchenPurchasesComponent implements OnInit {
  _search : boolean = false;
  @Input() inventoryCategoryId;
  purchases= new Array<KitchenPurchases>();
  categories: KitchenInventoryCategory[];
  tableData: TableCompose;
  selected: KitchenPurchases;
  isAdd: boolean;
  @Output() emitter = new EventEmitter<any>();
  isBack: boolean;
  title: any;

  constructor(private http: HttpRequestComponent) {
    this.getKitchenInventoryCategories();
  }

  ngOnInit() {
    this._search = true;
  }

  getKitchenInventoryCategories() {
    this.http.get('/kitchen/inventory/category', (category) => this.categories = category);
    this.getKitchenPurchases()
  }

  getKitchenPurchases() {
    this.http.get('/kitchen/inventory/purchase', (purchases) => this.kitchenPurchases(purchases));
  }

  mapCategory(id: number): KitchenInventoryCategory {
    return this.categories.find(cat => cat.id == id);
  }

  kitchenPurchases(purchase) {
    if (this.inventoryCategoryId)
      this.purchases = purchase.filter(p => p.categoryId == this.inventoryCategoryId)
    else
      this.purchases = purchase;
    this.purchases.forEach(l => l.process = KitchenPurchasesProcessHelper.get(l.processingId));
    this.purchases.forEach(purchase => purchase.categoryName = this.mapCategory(purchase.categoryId));
    this.tableData = new TableCompose()
      .composeHeader('quantity', 'Quantity', DataType.Plain)
      .composeHeader('cost', 'Cost', DataType.Money)
      .composeHeader('process', 'Process', DataType.Plain)
      .composeHeader('categoryName', 'Item', DataType.Selection, 'name')
      .composeHeader('dateCreated', 'Date', DataType.Date)
      .setBody(this.purchases);
  }

  itemClick(item) {
    this.selected = item;
    this.isAdd = false;
    this.title = this.getTitleButton();
  }

  addClick() {
    this.selected = new KitchenPurchases();
    this.isAdd = true;
  }

  backClick() {
    this.isBack = true;
    this.emitter.emit(this.isBack)
  }

  reloadKitchenPurchases(item) {
    setTimeout(() => {
      this.getKitchenInventoryCategories();
    }, 1000);
    this.isAdd = false;
    this.selected = null;
  }

  getTitleButton() {
    switch (this.selected.processingId) {
      case KitchenPurchasesProcess.request:
        return { title: 'Approve' };
      case KitchenPurchasesProcess.approval:
        return { title: 'Confirm Collection' };
      case KitchenPurchasesProcess.collection:
        return { title: 'Confirm Collection' };
      default:
        return null;
    }
  }

  updatePurchaseOrder($event) {
    this.http.update('kitchen/inventory/purchase/processing/' + this.selected.id, {
      id: this.selected.id,
      processingId: this.selected.processingId + 1
    }, (result) => {
      swal('', result.message, 'success');
      this.reloadKitchenPurchases(result);
    })
  }
}