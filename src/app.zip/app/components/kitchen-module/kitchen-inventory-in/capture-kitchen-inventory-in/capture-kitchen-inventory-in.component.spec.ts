import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CaptureKitchenInventoryInComponent } from './capture-kitchen-inventory-in.component';

describe('CaptureKitchenInventoryInComponent', () => {
  let component: CaptureKitchenInventoryInComponent;
  let fixture: ComponentFixture<CaptureKitchenInventoryInComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CaptureKitchenInventoryInComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CaptureKitchenInventoryInComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
