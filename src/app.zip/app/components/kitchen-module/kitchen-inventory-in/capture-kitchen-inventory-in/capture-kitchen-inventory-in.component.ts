import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { HttpRequestComponent } from 'src/app/provider/http-request/http-request.component';
import { KitchenInventoryIn } from 'src/app/model/kitchen/kitchen-inventory-in';
import { Validation } from 'src/app/provider/validation/validation';
import swal from 'sweetalert2';
import { ValidationType } from 'src/app/provider/validation/validation-type.enum';
import { TableCompose } from 'src/app/provider/table/table-compose';
import { KitchenInventoryOut } from 'src/app/model/kitchen/kitchen-inventory-out';
import { DataType } from 'src/app/provider/table/data-type.enum';
import { KitchenInventoryCategory } from 'src/app/model/kitchen/kitchen-inventory-category';
import { KitchenFoodRequest } from 'src/app/model/kitchen/kitchen-food-request';

@Component({
  selector: 'app-capture-kitchen-inventory-in',
  templateUrl: './capture-kitchen-inventory-in.component.html',
  styleUrls: ['./capture-kitchen-inventory-in.component.scss']
})
export class CaptureKitchenInventoryInComponent implements OnInit {
  validation: any;
  limit: number;
  @Input() kitchenInventoryIn: KitchenInventoryIn;
  @Input() kitchenInventoryOut: KitchenInventoryOut;
  @Output() emitter = new EventEmitter<any>();
  tableData: TableCompose;

  constructor(private http: HttpRequestComponent) {
  }

  ngOnInit() {
    if (!this.kitchenInventoryIn) this.kitchenInventoryIn = new KitchenInventoryIn();
    if (this.kitchenInventoryOut) {
      this.itemClick(this.kitchenInventoryOut);
      return;
    }
    this.getKitchenInventoryCategories();
  }

  selectedInventory: KitchenInventoryOut;
  itemClick(selectedInventory: KitchenInventoryOut) {
    this.selectedInventory = selectedInventory;
    this.kitchenInventoryIn.kitchenInventoryOutId = selectedInventory.id;
    this.loadValidation();
  }

  getInventoryOut() {
    this.http.get('kitchen/inventory/out', (inventoryOut) => this.InventoryOutItems(inventoryOut));
  }

  InventoryOutItems(inventory: KitchenInventoryOut[]) {
    inventory.forEach(inventory => inventory.requestUsername = this.mapRequest(inventory.foodRequestId));
    inventory.forEach(inventory => inventory.categoryName = this.mapCategory(inventory.categoryId));
    this.tableData = new TableCompose()
      .composeHeader('categoryName', 'Item', DataType.Selection, 'name')
      .composeHeader('quantity', 'Quantity', DataType.Plain)
      .composeHeader('requestUsername', 'Requested By', DataType.Selection, 'username')
      .composeHeader('dateCreated', 'Date Requested', DataType.Date)
      .setBody(inventory);
  }

  mapCategory(id: number): KitchenInventoryCategory {
    return this.categories.find(cat => cat.id == id);
  }

  mapRequest(id: number): KitchenFoodRequest {
    return this.request.find(req => req.id == id);
  }

  getKitchenInventoryCategories() {
    this.http.get('/kitchen/inventory/category', (category) => {
      this.categories = category;
      this.getFoodRequest();
    })
  }
  categories: any;
  request: any;
  getFoodRequest() {
    this.http.get('/food/requests', (request) => {
      this.request = request;
      this.getInventoryOut();
    })
  }

  loadValidation() {
    this.validation = new Validation();
    this.validation.addField({ name: 'quantity', display: 'Quantity', type: ValidationType.Between }, this.selectedInventory.quantity);
  }

  submit() {
    if (this.kitchenInventoryIn.id)
      this.http.put('kitchen/inventory/in/' + this.kitchenInventoryIn.id, this.kitchenInventoryIn, (result) => swal('', result.message, 'success'));
    else {
      this.kitchenInventoryIn.id = 0;
      this.kitchenInventoryIn.dateCreated = new Date();
      this.http.post('kitchen/inventory/in/', this.kitchenInventoryIn, (result) => swal('', result.message, 'success'));
    }
    this.emitter.emit(this.kitchenInventoryIn);
  }
}