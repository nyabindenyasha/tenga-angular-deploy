import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { TableCompose } from 'src/app/provider/table/table-compose';
import { HttpRequestComponent } from 'src/app/provider/http-request/http-request.component';
import { DataType } from 'src/app/provider/table/data-type.enum';
import { KitchenInventoryOut } from 'src/app/model/kitchen/kitchen-inventory-out';
import { KitchenInventoryCategory } from 'src/app/model/kitchen/kitchen-inventory-category';
import { KitchenInventoryIn } from 'src/app/model/kitchen/kitchen-inventory-in';
import { RouterLink, Router } from '@angular/router';

@Component({
  selector: 'app-kitchen-inventory-in',
  templateUrl: './kitchen-inventory-in.component.html',
  styleUrls: ['./kitchen-inventory-in.component.scss']
})
export class KitchenInventoryInComponent implements OnInit {
  _search : boolean = false;
  inventory: any[];
  tableData: any;
  selectedItem: any;
  isAdd: boolean;
  @Input() kitchenInventoryOut: KitchenInventoryOut;
  categories: KitchenInventoryCategory[];
  outInventory: any;
  kitchenInventoryOutId: any;
  isBack: boolean;
  @Output() emitter = new EventEmitter<any>();

  constructor(private http: HttpRequestComponent, private router: Router) {
    this.http.get('kitchen/inventory/category', (categories)=> this.getCategories(categories));
    this.http.get('kitchen/inventory/out', (out)=> this.getAllInventoryOut(out));
   }

  ngOnInit() {
    this._search = true;
    if(!this.kitchenInventoryOut)this.kitchenInventoryOut = new KitchenInventoryOut();
    this.getKitchenInventoryIn();
  }

  ngOnChanges(){
    this.getKitchenInventoryIn();
  }

  getKitchenInventoryIn() {
    setTimeout(()=>
    this.http.get('kitchen/inventory/in', (inventory) => this.loadKitchenInventory(inventory)), 100);
  }
  getAllInventoryOut(outInventory: KitchenInventoryOut[]){
    this.outInventory = outInventory;
  }

  getCategories(categories: KitchenInventoryCategory[]){
    this.categories = categories; 
  }

  mapCategory(categoryId: number): KitchenInventoryCategory{
    return this.categories.find(c=> c.id == categoryId);
  }

  mapInventoryOut(kitchenInventoryOutId: number): KitchenInventoryCategory{
    return this.outInventory.find(c=> c.id == kitchenInventoryOutId);
  }

  loadKitchenInventory(inventory: KitchenInventoryIn[]) {
    if(this.kitchenInventoryOut.id){
      this.inventory = inventory.filter(i=> i.kitchenInventoryOutId == this.kitchenInventoryOut.id);
      this.kitchenInventoryOutId = this.kitchenInventoryOut.id;
    }
    else this.inventory = inventory;
    this.inventory.forEach(out=>{ 
      out.kitchenInventoryOut = this.mapInventoryOut(out.kitchenInventoryOutId);
      out.category = this.mapCategory(out.kitchenInventoryOut.categoryId);
    });
    this.tableData = new TableCompose()
      .composeHeader('category', 'Category', DataType.Selection, 'name')
      .composeHeader('quantity', 'Quantity', DataType.Plain)
      .composeHeader('dateCreated', 'Date of Return', DataType.Date)
      .setBody(this.inventory);
  }

  itemClick(item) {
    this.selectedItem = item;
    this.isAdd = false;
  }

  addClick() {
    this.selectedItem = null;
    this.isAdd = true;
  }

  backClick() {
    this.isBack = true;
    this.emitter.emit(this.isBack)
  }

  editClick(item) {
    this.selectedItem = item;
    this.kitchenInventoryOutId = item.kitchenInventoryOutId;
    this.isAdd = true;
  }

  addedClick() {
    this.isAdd = false;
    this.selectedItem = null;
    setTimeout(()=> this.getKitchenInventoryIn(), 100)
  }
}
