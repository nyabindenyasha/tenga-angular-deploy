import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { KitchenInventoryInComponent } from './kitchen-inventory-in.component';

describe('KitchenInventoryInComponent', () => {
  let component: KitchenInventoryInComponent;
  let fixture: ComponentFixture<KitchenInventoryInComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ KitchenInventoryInComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(KitchenInventoryInComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
