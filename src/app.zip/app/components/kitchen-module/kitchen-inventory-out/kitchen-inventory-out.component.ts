import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { HttpRequestComponent } from 'src/app/provider/http-request/http-request.component';
import { KitchenInventoryOut } from 'src/app/model/kitchen/kitchen-inventory-out';
import { TableCompose } from 'src/app/provider/table/table-compose';
import { DataType } from 'src/app/provider/table/data-type.enum';
import { KitchenInventoryCategory } from 'src/app/model/kitchen/kitchen-inventory-category';
import { KitchenFoodRequest } from 'src/app/model/kitchen/kitchen-food-request';
import { Router } from '@angular/router';

@Component({
  selector: 'app-kitchen-inventory-out',
  templateUrl: './kitchen-inventory-out.component.html',
  styleUrls: ['./kitchen-inventory-out.component.scss']
})
export class KitchenInventoryOutComponent implements OnInit {
  _search : boolean = false;
  request: KitchenFoodRequest[];
  categories: KitchenInventoryCategory[];
  isAdd: boolean;
  selected: any;
  tableData: TableCompose;
  inventory: KitchenInventoryOut[];
  isAddInventoryIn: boolean;
  inventoryIn: boolean;
  @Input() inventoryCategoryId;
  isBack: boolean;
  @Output() emitter= new EventEmitter<any>();

  constructor(private http: HttpRequestComponent, private router: Router) { }

  ngOnInit() {
    this._search = true;
    this.getKitchenInventoryCategories();
  }

  getInventoryOut() {
    this.http.get('kitchen/inventory/out', (inventoryOut) => this.InventoryOutItems(inventoryOut));
  }

  mapCategory(id: number): KitchenInventoryCategory {
    return this.categories.find(cat => cat.id == id);
  }

  mapRequest(id: number): KitchenFoodRequest {
    return this.request.find(req => req.id == id);
  }

  getKitchenInventoryCategories() {
    this.http.get('/kitchen/inventory/category', (category) => {
      this.categories = category;
      this.getFoodRequest();
    })
  }

  getFoodRequest() {
    this.http.get('/food/requests', (request) => {
      this.request = request;
      this.getInventoryOut();
    })
  }

  InventoryOutItems(inventory: KitchenInventoryOut[]) {
    if(this.inventoryCategoryId)
      this.inventory = inventory.filter(i=> i.categoryId == this.inventoryCategoryId)
    else this.inventory = inventory
    this.inventory.forEach(inventory => inventory.requestUsername = this.mapRequest(inventory.foodRequestId));
    this.inventory.forEach(inventory => inventory.categoryName = this.mapCategory(inventory.categoryId));
    this.tableData = new TableCompose()
      .composeHeader('categoryName', 'Item', DataType.Selection, 'name')
      .composeHeader('quantity', 'Quantity', DataType.Plain)
      .composeHeader('requestUsername', 'Requested By', DataType.Selection, 'username')
      .composeHeader('dateCreated', 'Date Requested', DataType.Date)
      .setBody(this.inventory);
  }

  itemClick(item) {
    this.selected = item;
    this.isAdd = false;
  }

  addClick() {
    this.inventoryIn = false;
    this.selected = {};
    this.isAdd = true;
  }

  reloadInventoryOut($event) {
    setTimeout(() => {
      this.getInventoryOut();
    }, 10);
    this.isAdd = false;
    this.selected = null;
    this.inventoryIn = false;
  }

  backClick() {
    this.isBack = true;
    this.emitter.emit(this.isBack)
  }
  
  reloadPage($event){
    if($event) this.inventoryIn = false;
  }

  addInventoryIn(){
    this.isAdd = false;
    this.inventoryIn = true;
  }
}