import { Component, OnInit, EventEmitter, Input, Output } from '@angular/core';
import { Validation } from 'src/app/provider/validation/validation';
import { ValidationType } from 'src/app/provider/validation/validation-type.enum';
import { HttpRequestComponent } from 'src/app/provider/http-request/http-request.component';
import swal from 'sweetalert2';
import { KitchenFoodRequest } from 'src/app/model/kitchen/kitchen-food-request';
import { KitchenInventoryOut } from 'src/app/model/kitchen/kitchen-inventory-out';
import { KitchenInventoryCategory } from 'src/app/model/kitchen/kitchen-inventory-category';
import { InventoryTrack } from 'src/app/model/kitchen/kitchen-inventory-track';


@Component({
  selector: 'app-capture-kitchen-inventory-out',
  templateUrl: './capture-kitchen-inventory-out.component.html',
  styleUrls: ['./capture-kitchen-inventory-out.component.scss']
})
export class CaptureKitchenInventoryOutComponent implements OnInit {
  trackedCategories = Array<KitchenInventoryCategory>();
  @Output() result = new EventEmitter<any>();
  @Input() inventoryOut: KitchenInventoryOut;
  @Input() inventoryCategoryId;
  validation: Validation;
  request: KitchenFoodRequest[];
  category = new Array<KitchenInventoryCategory>();
  validQuantity = 1;
  inventoryTracks = new Array<InventoryTrack>();


  constructor(private http: HttpRequestComponent) {
    this.http.get('kitchen/inventory/tracker', ((result) => this.getInventoryTrack(result)));
    this.http.get("/food/requests", ((result) => this.getRequest(result)));
    this.http.get("/kitchen/inventory/category", ((result) => this.getCategory(result)));
  }

  ngOnInit() {
    if (!this.inventoryOut) this.inventoryOut = new KitchenInventoryOut();
    if(this.inventoryCategoryId) this.inventoryOut.categoryId = this.inventoryCategoryId;
    this.inventoryOut.id = 0;
    this.loadValidation();
  }

  loadValidation() {
    this.validation = new Validation();
    this.validation.addField({ name: 'categoryId', display: 'Item', type: ValidationType.Required });
    this.validation.addField({ name: 'foodRequestId', display: 'Request', type: ValidationType.Required });
    this.validation.addField({ name: 'quantity', display: 'Quantity', type: ValidationType.Between }, this.validQuantity);
    this.validation.addField({ name: 'dateCreated', display: 'Date', type: ValidationType.Date },   new Date(this.inventoryOut.dateCreated).getTime());
  }

  getCategory(category) {
    this.category = category;
    this.trackedCategories = this.category.filter(function (e) {
      return this.indexOf(e.id) >= 0;
    }, this.inventoryTracks.map(a => a.categoryId));
  }

  getRequest(request) {
    this.request = request;
  }

  getInventoryTrack(tracks) {
    this.inventoryTracks = tracks;
  }

  validateQuantity(Id) {
    this.validQuantity = 1;
    this.validQuantity += this.inventoryTracks.find(x => x.categoryId == Id).storageQuantity;
    this.loadValidation();
  }
  getDate(value){
    this.loadValidation();
  }

  submit(inventoryOut) {
    this.http.post('kitchen/inventory/out', this.inventoryOut, (result) => {
      swal('', result.message, 'success');
      this.result.emit(inventoryOut);
    });
  }
}
