import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CaptureKitchenInventoryOutComponent } from './capture-kitchen-inventory-out.component';

describe('CaptureKitchenInventoryOutComponent', () => {
  let component: CaptureKitchenInventoryOutComponent;
  let fixture: ComponentFixture<CaptureKitchenInventoryOutComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CaptureKitchenInventoryOutComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CaptureKitchenInventoryOutComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
