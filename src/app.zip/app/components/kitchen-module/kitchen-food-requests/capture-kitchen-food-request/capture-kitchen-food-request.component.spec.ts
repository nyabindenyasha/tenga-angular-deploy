import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CaptureKitchenFoodRequestComponent } from './capture-kitchen-food-request.component';

describe('CaptureKitchenFoodRequestComponent', () => {
  let component: CaptureKitchenFoodRequestComponent;
  let fixture: ComponentFixture<CaptureKitchenFoodRequestComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CaptureKitchenFoodRequestComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CaptureKitchenFoodRequestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
