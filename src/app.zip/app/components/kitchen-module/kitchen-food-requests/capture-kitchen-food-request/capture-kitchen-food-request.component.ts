import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { KitchenFoodRequest } from 'src/app/model/kitchen/kitchen-food-request';
import { HttpRequestComponent } from 'src/app/provider/http-request/http-request.component';
import { TableCompose } from 'src/app/provider/table/table-compose';
import { DataType } from 'src/app/provider/table/data-type.enum';
import swal from 'sweetalert2';
import { KitchenFoodMenu } from 'src/app/model/kitchen/kitchen-food-menu';
import { KitchenOrderLocation } from 'src/app/model/kitchen/kitchen-order-location';
import { Validation } from 'src/app/provider/validation/validation';
import { ValidationType } from 'src/app/provider/validation/validation-type.enum';

@Component({
  selector: 'app-capture-kitchen-food-request',
  templateUrl: './capture-kitchen-food-request.component.html',
  styleUrls: ['./capture-kitchen-food-request.component.scss']
})
export class CaptureKitchenFoodRequestComponent implements OnInit {
  validation: any;
  orderLocation = new Array<KitchenOrderLocation>();
  foodMenu = new Array<KitchenFoodMenu>();
  @Input() foodRequest: KitchenFoodRequest;
  @Output() result = new EventEmitter<any>();
  staff: any[];

  constructor(private http: HttpRequestComponent) {
  }

  ngOnInit() {
    if (!this.foodRequest) this.foodRequest = new KitchenFoodRequest();
    this.loadValidation();
    this.getStaff();
  }
  getStaff(){    
    this.http.get('staff', (staff) => this.staff = staff);
    this.getFoodMenus();
  }

  getFoodMenus() {
  this.http.get('/food/menu', ((result) => this.getFoodMenu(result)));
  this.getOrderLocations();
  }

  getOrderLocations() {
    this.http.get("/order/location", ((result) => this.getOrderLocation(result)));
  }
  getFoodMenu(menu) {
    this.foodMenu = menu;
  }
  getOrderLocation(location) {
    this.orderLocation = location;
  }

  loadValidation() {
    this.validation = new Validation();
    this.validation.addField({ name: 'username', display: 'Username', type: ValidationType.Required });
    this.validation.addField({ name: 'foodMenuId', display: 'Menu', type: ValidationType.Required });
    this.validation.addField({ name: 'orderLocationId', display: 'Location', type: ValidationType.Required });
    this.validation.addField({ name: 'numberOfOrders', display: 'No. Of Orders', type: ValidationType.GreaterThan }, 0);
  }
  
  submit(foodRequest) {
    this.http.post('/food/requests', this.foodRequest, (result) => {
      swal('', result.message, 'success');
      this.result.emit(foodRequest);
    });
  }

}
