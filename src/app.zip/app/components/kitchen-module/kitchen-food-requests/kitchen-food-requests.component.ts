import { Component, OnInit } from '@angular/core';
import { TableCompose } from 'src/app/provider/table/table-compose';
import { DataType } from 'src/app/provider/table/data-type.enum';
import { KitchenFoodRequest } from 'src/app/model/kitchen/kitchen-food-request';
import { HttpRequestComponent } from 'src/app/provider/http-request/http-request.component';
import { KitchenFoodMenu } from 'src/app/model/kitchen/kitchen-food-menu';
import { KitchenOrderLocation } from 'src/app/model/kitchen/kitchen-order-location';
import { KitchenFoodRequestStatus } from 'src/app/model/kitchen/kitchen-food-request-status';


@Component({
  selector: 'app-kitchen-food-requests',
  templateUrl: './kitchen-food-requests.component.html',
  styleUrls: ['./kitchen-food-requests.component.scss']
})
export class KitchenFoodRequestsComponent implements OnInit {
  foodRequestDetails = new Array<KitchenFoodRequest>();
  foodMenuDetails: KitchenFoodMenu[];
  orderLocationDetails: KitchenOrderLocation[];
  foodRequestStatus: KitchenFoodRequestStatus[];
  tableData: TableCompose;
  selected: any;
  isAdd: boolean;
  _search : boolean = false;
  constructor(private http: HttpRequestComponent) { }

  ngOnInit() {
    this._search = true;
    this.getFoodMenu();  
  }

  getFoodMenu() {
    this.http.get('/food/menu', (menu) => {
      this.foodMenuDetails = menu;
      this.getKitchenOrderLocation();    
    })
  }

  getKitchenOrderLocation() {
    this.http.get('/order/location', (location) => {
      this.orderLocationDetails = location;
      this.getStatus();
    })
  }

  getStatus() {
    this.http.get('/food/request/status', (status) => {
      this.foodRequestStatus = status;
      this.loadRequests();
    })
  }

  loadRequests() {
    this.http.get('/food/requests', (requests) => this.loadFoodRequests(requests));
  }

  mapFoodMenu(foodMenuId: number): KitchenFoodMenu {
    return this.foodMenuDetails.find(item => item.id == foodMenuId);
  }


  mapOrderLocation(orderLocationId: number): KitchenOrderLocation {
    return this.orderLocationDetails.find(type => type.id == orderLocationId);
  }

  mapRequestStatus(statusId: number): KitchenFoodRequestStatus {
    return this.foodRequestStatus.find(stage => stage.id == statusId);
  }

  loadFoodRequests(requests: KitchenFoodRequest[]) {
    requests.forEach(menuItem => menuItem.foodMenuItem = this.mapFoodMenu(menuItem.foodMenuId));
    requests.forEach(orderLocation => orderLocation.location = this.mapOrderLocation(orderLocation.orderLocationId));
    requests.forEach(requestStatus => requestStatus.status = this.mapRequestStatus(requestStatus.orderLocationId));
    this.foodRequestDetails = requests
    console.log(requests);
    this.tableData = new TableCompose()
      .composeHeader('foodMenuItem', 'Order', DataType.Selection, 'name')
      .composeHeader('numberOfOrders', ' Quantity ', DataType.Plain)
      .composeHeader('location', ' Location', DataType.Selection, 'name')
      .composeHeader('username', ' Requested By ', DataType.Plain)
      .composeHeader('status', 'status', DataType.Selection, 'name')
      .composeHeader('dateCreated', 'Date Requested ', DataType.Date)
      .setBody(this.foodRequestDetails);
  }
  itemClick(item) {
    this.selected = item;
    this.isAdd = false;
  }
  addClick() {
    this.selected = {};
    this.isAdd = true;
  }
  editClick(item) {
    this.selected = item;
    this.isAdd = true;
  }
  reload($event) {
    setTimeout(() => {
      this.getFoodMenu();
      this.getKitchenOrderLocation();
      this.getStatus();
    }, 10);
    this.isAdd = false;
    this.selected = null;
  }
}
