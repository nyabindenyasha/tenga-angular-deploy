import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { KitchenFoodRequestsComponent } from './kitchen-food-requests.component';

describe('KitchenFoodRequestsComponent', () => {
  let component: KitchenFoodRequestsComponent;
  let fixture: ComponentFixture<KitchenFoodRequestsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ KitchenFoodRequestsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(KitchenFoodRequestsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
