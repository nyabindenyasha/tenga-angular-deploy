import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { HttpRequestComponent } from 'src/app/provider/http-request/http-request.component';
import { KitchenSales } from 'src/app/model/kitchen/kitchen-sales';
import swal from 'sweetalert2';
import { kitcheinStaff } from 'src/app/model/kitchen/staff';
import { Validation } from 'src/app/provider/validation/validation';
import { ValidationType } from 'src/app/provider/validation/validation-type.enum';
import { KitchenFoodMenu } from 'src/app/model/kitchen/kitchen-food-menu';

@Component({
  selector: 'app-capture-kitchen-sales',
  templateUrl: './capture-kitchen-sales.component.html',
  styleUrls: ['./capture-kitchen-sales.component.scss']
})

export class CaptureKitchenSalesComponent implements OnInit {
  @Input() paymentDetails;
  @Output() emitter = new EventEmitter<any>()
  staffMembers: kitcheinStaff[];
  buyer: KitchenSales;
  requests: KitchenSales[];
  validation: Validation;
  tickets: boolean = false;
  credit: boolean = false;
  menu: KitchenFoodMenu[];
  menuDropDown: Array<KitchenSales> = [];

  constructor(private http: HttpRequestComponent) {  
  }
  ngOnInit() {
    this.validate()
    if (!this.buyer) this.buyer = new KitchenSales();
    this.getMenu();
  }

  getStaff(){
    this.http.get('/staff', (staff) => this.getBuyers(staff));  
  }
getFoodRequests(){
  this.http.get('/food/requests', (data) => this.getRequest(data));  
  this.getStaff();
}
  validate() {
    this.validation = new Validation();
    this.validation.addField({ name: 'foodRequestId', display: 'Food request number', type: ValidationType.Required });
    this.validation.addField({ name: 'paymentTypeId', display: 'Payment Method', type: ValidationType.Required });
    if(this.tickets) this.validation.addField({name: 'ticketNumber', display: 'Ticket Number', type: ValidationType.Required})
    if(this.credit) this.validation.addField({name: 'buyerId', display: 'Buyer Name', type: ValidationType.Required})
  }

  getMenu(){
    this.http.get('/food/menu', (menu)=> this.getFoodMenu(menu));
    this.getFoodRequests();
  }

  getRequest(sale: KitchenSales[]) {
    this.requests = sale;
    sale.forEach(s=> {
      s.foodMenu = this.mapRequests(s.foodMenuId)
      this.menuDropDown.push(s);
    });
    console.log(this.menuDropDown);
    
  }

  getFoodMenu(menu: KitchenFoodMenu[]){
    this.menu = menu;
  }
  mapRequests(foodMenuId: number): KitchenFoodMenu{
    return this.menu.find(m=> m.id == foodMenuId);
  }

  getBuyers(buyers: kitcheinStaff[]) {
    this.staffMembers = buyers;
  }

  switchPayment(event: any) {
    if (event.target.value == 1) {
      this.tickets = true;
      this.credit = false;
    }
    else if (event.target.value == 2) {
      this.credit = true;
      this.tickets = false;
    }
    this.validate()
  }

  submit() {
    this.http.post('/kitchen/sales', this.buyer, (result) => this.onSuccess(result.message));
  }

  onSuccess(result) {
    swal('', result, 'success');
    this.emitter.emit(this.buyer);
  }
}


