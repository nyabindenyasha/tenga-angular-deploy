import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CaptureKitchenSalesComponent } from './capture-kitchen-sales.component';

describe('CaptureKitchenSalesComponent', () => {
  let component: CaptureKitchenSalesComponent;
  let fixture: ComponentFixture<CaptureKitchenSalesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CaptureKitchenSalesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CaptureKitchenSalesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
