import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { TableCompose } from 'src/app/provider/table/table-compose';
import { KitchenSales } from 'src/app/model/kitchen/kitchen-sales';
import { PaymentType } from 'src/app/model/kitchen/kitchen-payment-type';
import { HttpRequestComponent } from 'src/app/provider/http-request/http-request.component';
import { DataType } from 'src/app/provider/table/data-type.enum';

@Component({
  selector: 'app-kitchen-sales',
  templateUrl: './kitchen-sales.component.html',
  styleUrls: ['./kitchen-sales.component.scss']
})
export class KitchenSalesComponent implements OnInit {
  @Input() step: any;
  @Output() result = new EventEmitter<any>();
  tableData: TableCompose;
  salesDetails: KitchenSales[];
  paymentDetails: PaymentType[];
  selected: KitchenSales;
  isAdd: boolean;
  _search : boolean = false;

  constructor(private http: HttpRequestComponent) {
  }

  ngOnInit() {
    this._search = true;
    this.getPaymentType()
  }

  getPaymentType() {
    this.http.get('payment/type', (paymentType) => {
      this.paymentDetails = paymentType;
      this.loadSales();
    })
  }
  loadSales() {
    this.http.get('kitchen/sales', (sales) => this.getKitchenSales(sales));
  }

  mapPaymentType(paymentType: number): PaymentType {
    return this.paymentDetails.find(paymentTypes => paymentTypes.id == paymentType);
  }

  getKitchenSales(salesDetail: KitchenSales[]) {
    salesDetail.forEach(payment => payment.paymentTypeName = this.mapPaymentType(payment.paymentType));
    this.salesDetails = salesDetail;
    this.tableData = new TableCompose()
      .composeHeader('foodName', 'Food Name', DataType.Plain)
      .composeHeader('paymentTypeName', 'Payment Type', DataType.Selection, 'name')
      .composeHeader('cost', 'Cost', DataType.Money)
      .composeHeader('dateCreated', 'Date Sold', DataType.Date)

      .setBody(this.salesDetails);
  }

  itemClick(item) {
    this.selected = item;
    this.isAdd = false;
  }

  addClick(){
    this.selected = null;
    this.isAdd = true;
  }

  reloadKitchenSales($event) {
    this.loadSales()
    this.isAdd = false;
    this.selected = null;
  }
}
