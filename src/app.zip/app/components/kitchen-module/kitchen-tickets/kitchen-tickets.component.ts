import { Component, OnInit } from '@angular/core';
import { TableCompose } from 'src/app/provider/table/table-compose';
import { DataType } from 'src/app/provider/table/data-type.enum';
import { KitchenTickets } from 'src/app/model/kitchen/kitchen-tickets';
import { HttpRequestComponent } from 'src/app/provider/http-request/http-request.component';
import { KitchenStaff } from 'src/app/model/kitchen/kitchen-staff';
import swal from 'sweetalert2';

@Component({
  selector: 'app-kitchen-tickets',
  templateUrl: './kitchen-tickets.component.html',
  styleUrls: ['./kitchen-tickets.component.scss']
})
export class KitchenTicketsComponent implements OnInit {
  _search : boolean = false;
  ticketsDetails: KitchenTickets[];
  staffDetails: KitchenStaff[];
  resultDetails: any[] = []
  tableData: TableCompose;
  selected: KitchenTickets;
  isAdd: boolean;
  response: boolean;


  constructor(private http: HttpRequestComponent) {
  }

  ngOnInit() {
    this._search = true;
    this.getStaff()
  }

  getStaff() {
    this.http.get('/staff', (staff) => {
      this.staffDetails = staff;
      this.loadTickets();
    })
  }

  loadTickets() {
    this.http.get('/tickets', (tickets) => this.loadKitchenTickets(tickets));
  }

  mapStaff(staffid: number): KitchenStaff {
    return this.staffDetails.find(staff => staff.id == staffid);
  }

  loadKitchenTickets(tickets: KitchenTickets[]) {
    tickets.forEach(ticket => ticket.staffName = this.mapStaff(ticket.staffId));
    this.ticketsDetails = tickets;

    this.tableData = new TableCompose()
      .composeHeader('dateCreated', 'Date Created', DataType.Date)
      .composeHeader('staffName', 'Staff Name', DataType.Selection, 'username')
      .composeHeader('ticketNumber', 'Ticket Number', DataType.Plain)
      .composeHeader('isUsed', 'Valid?', DataType.Check)
      .setBody(this.ticketsDetails);
  }

  itemClick(item) {
    this.selected = item;
    this.isAdd = false;
  }

  addClick() {
    this.selected = new KitchenTickets();
    this.isAdd = true;
  }

  loadResult(result) {
    // console.log(result);
 
    this.response = true;
    result.forEach(result => result.staffName = this.mapStaff(result.staffId));
    this.resultDetails = result;

    this.tableData = new TableCompose()
      .composeHeader('staffName', 'Staff Name',DataType.Selection, 'username')
      .composeHeader('message', 'Message', DataType.Plain)
      .composeHeader('success', 'Success', DataType.Check)
      .composeHeader('ticketNumber', 'Ticket number', DataType.Plain)
      .setBody(this.resultDetails);
   
    }

}
