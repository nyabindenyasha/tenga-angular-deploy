import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { KitchenTicketsComponent } from './kitchen-tickets.component';

describe('KitchenTicketsComponent', () => {
  let component: KitchenTicketsComponent;
  let fixture: ComponentFixture<KitchenTicketsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ KitchenTicketsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(KitchenTicketsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
