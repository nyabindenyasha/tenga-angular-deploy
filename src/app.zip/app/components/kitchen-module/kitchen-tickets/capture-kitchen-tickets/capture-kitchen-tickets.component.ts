import { Component, OnInit, Input, Output, EventEmitter, ElementRef, ViewChild } from '@angular/core';
import { HttpRequestComponent } from 'src/app/provider/http-request/http-request.component';
import { KitchenStaff } from 'src/app/model/kitchen/kitchen-staff';
import { TableCompose } from 'src/app/provider/table/table-compose';
import { DataType } from 'src/app/provider/table/data-type.enum';
import swal from 'sweetalert2';
import { KitchenTickets } from 'src/app/model/kitchen/kitchen-tickets';
import { KitchenStaffTicketSelection } from 'src/app/model/kitchen/kitchen-staff-ticket-selection';

@Component({
  selector: 'app-capture-kitchen-tickets',
  templateUrl: './capture-kitchen-tickets.component.html',
  styleUrls: ['./capture-kitchen-tickets.component.scss']
})
export class CaptureKitchenTicketsComponent implements OnInit {
  @Input('show-modal') showModal: boolean;
  @Input() ticket: KitchenTickets
  @Output() data: EventEmitter<any> = new EventEmitter<KitchenStaff>();
  staff: KitchenStaff;
  @Input() staffTickets: any[] = []
  staffDetails: KitchenStaffTicketSelection[];
  ticketDetails: KitchenTickets[];
  tableData: TableCompose;
  selected: KitchenStaffTicketSelection;
  isAdd: boolean;
  constructor(private http: HttpRequestComponent) { }

  ngOnInit() {
    if (this.ticket == null) this.ticket = new KitchenTickets();
    this.getAllStaff();
  }
  getAllStaff() {
    this.http.get('/staff', (staff) => this.DisplayStaff(staff));
  }
  hide() {
    this.showModal = false
  }
  DisplayStaff(staffMember: KitchenStaff[]) {
    this.staffDetails = staffMember;
    this.tableData = new TableCompose()
      .composeHeader('username', 'Staff Name', DataType.Plain)
      .composeHeader('buyTicket', 'Buy Ticket', DataType.Check)
      .setBody(this.staffDetails);
  }

  itemClick(item: KitchenStaff) {
    this.selected = item;
    this.selected.buyTicket = !this.selected.buyTicket;
  }

  addClick() {
    let obj = this.staffDetails.filter(obj => obj.buyTicket == true)
    this.ticketDetails = []
    for (let i = 0; i < obj.length; i++) {
      this.ticket = new KitchenTickets()
      this.ticket.staffId = obj[i].id
      this.ticketDetails.push(this.ticket)
    }
    if(!Array.isArray(this.ticketDetails) || !this.ticketDetails.length) {
      swal("","Please select staff member","warning")
    }
    else {
      this.http.post('/tickets', this.ticketDetails, (result) => this.data.emit(result))
    }
  }
}