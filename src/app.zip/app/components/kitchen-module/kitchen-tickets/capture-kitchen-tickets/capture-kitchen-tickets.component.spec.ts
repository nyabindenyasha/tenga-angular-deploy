import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CaptureKitchenTicketsComponent } from './capture-kitchen-tickets.component';

describe('CaptureKitchenTicketsComponent', () => {
  let component: CaptureKitchenTicketsComponent;
  let fixture: ComponentFixture<CaptureKitchenTicketsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CaptureKitchenTicketsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CaptureKitchenTicketsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
