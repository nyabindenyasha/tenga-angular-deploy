import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-kitchen-home',
  templateUrl: './kitchen-home.component.html',
  styleUrls: ['./kitchen-home.component.scss']
})
export class KitchenHomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
