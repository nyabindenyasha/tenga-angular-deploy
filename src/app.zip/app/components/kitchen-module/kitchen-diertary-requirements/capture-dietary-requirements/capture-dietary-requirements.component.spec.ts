import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CaptureDietaryRequirementsComponent } from './capture-dietary-requirements.component';

describe('CaptureDietaryRequirementsComponent', () => {
  let component: CaptureDietaryRequirementsComponent;
  let fixture: ComponentFixture<CaptureDietaryRequirementsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CaptureDietaryRequirementsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CaptureDietaryRequirementsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
