import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';
import { KitchenDietaryRequirements } from 'src/app/model/kitchen/kitchen-dietary-requirements';
import { HttpRequestComponent } from 'src/app/provider/http-request/http-request.component';
import swal from 'sweetalert2';
import { ValidationType } from 'src/app/provider/validation/validation-type.enum';
import { KitchenDietaryCategory } from 'src/app/model/kitchen/kitchen-dietary-category';
import { KitchenFoodMenu } from 'src/app/model/kitchen/kitchen-food-menu';
import { Validation } from 'src/app/provider/validation/validation';
import { PatientModel } from 'src/app/model/kitchen/patients-model';

@Component({
  selector: 'app-capture-dietary-requirements',
  templateUrl: './capture-dietary-requirements.component.html',
  styleUrls: ['./capture-dietary-requirements.component.scss']
})
export class CaptureDietaryRequirementsComponent implements OnInit {

  @Input() requirement: KitchenDietaryRequirements;
  @Input() patients;
  @Input() categories;
  @Input() foodMenu;
  @Output() emitter = new EventEmitter<KitchenDietaryRequirements>()
  validation: Validation;
  patient: any;
  test: any;

  constructor(private http: HttpRequestComponent) { 
  }

  ngOnInit() {
    if (!this.requirement) this.requirement = new KitchenDietaryRequirements();
    if (! this.patients) this.patients = new PatientModel();
    if (!this.foodMenu) this.foodMenu = new KitchenFoodMenu();
    if (!this.categories) this.categories = new KitchenDietaryCategory();
    this.loadValidation();
  }

  loadValidation() {
    this.validation = new Validation();
    this.validation.addField({ name: 'patientId', display: 'Patient Name', type: ValidationType.Required });
    this.validation.addField({ name: 'foodMenuId', display: 'Food Menu Items', type: ValidationType.Required });
    this.validation.addField({ name: 'categoryId', display: 'Category', type: ValidationType.Required });
  }

  onSubmit() {
    if (this.requirement.id)
      this.http.put('dietary/requirements/' + this.requirement.id, this.requirement, (result) => swal(result.message, '', 'success'));
    else
      this.http.post('dietary/requirements', this.requirement, (result) => swal(result.message, '', 'success'));
    this.emitter.emit(this.requirement);
  }
}
