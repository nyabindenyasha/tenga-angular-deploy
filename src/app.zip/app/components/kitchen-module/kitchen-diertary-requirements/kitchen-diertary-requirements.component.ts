import { Component, OnInit } from '@angular/core';
import { HttpRequestComponent } from 'src/app/provider/http-request/http-request.component';
import { KitchenDietaryRequirements } from 'src/app/model/kitchen/kitchen-dietary-requirements';
import { DataType } from 'src/app/provider/table/data-type.enum';
import { TableCompose } from 'src/app/provider/table/table-compose';
import swal from 'sweetalert2';
import { KitchenDietaryCategory } from 'src/app/model/kitchen/kitchen-dietary-category';
import { KitchenFoodMenu } from 'src/app/model/kitchen/kitchen-food-menu';
import { PatientModel } from 'src/app/model/kitchen/patients-model';

@Component({
  selector: 'app-kitchen-diertary-requirements',
  templateUrl: './kitchen-diertary-requirements.component.html',
  styleUrls: ['./kitchen-diertary-requirements.component.scss']
})
export class KitchenDiertaryRequirementsComponent implements OnInit {
  _search : boolean = false;
  isAdd: boolean;
  selected: any;
  dietaryRequirements: any;
  tableData: TableCompose;
  dietaryCategory: KitchenDietaryCategory[];
  foodMenu: KitchenFoodMenu[] = [];
  patients: PatientModel[] = [];
  Requirements: KitchenDietaryRequirements[];
  tableData2: TableCompose;
  patientRequirements: PatientModel[];
  viewCategories: boolean;
  selectedPatient: any;

  constructor(private http: HttpRequestComponent) {
    this.http.get('dietary/category', (dietarycategory) => this.getDietaryCategory(dietarycategory))
    this.http.get('food/menu', (foodMenu) => this.getFoodMenu(foodMenu))
  }

  ngOnInit() {
    this._search = true;
    this.getPatients();
  }

  getDietaryCategory(dietaryCategory: KitchenDietaryCategory[]) {
    this.dietaryCategory = dietaryCategory;
  }

  getFoodMenu(foodMenu: KitchenFoodMenu[]) {
    this.foodMenu = foodMenu;
  }
  getPatients() {
    this.http.get('patient', (patients) => this.loadPatientsWithSpecialDiets(patients))
  }

  mapCategory(categoryId: number): KitchenDietaryCategory {
    return this.dietaryCategory.find(category => category.id == categoryId);
  }
  mapMenu(foodMenuId: number): KitchenFoodMenu {
    return this.foodMenu.find(f => f.id == foodMenuId);
  }

  mapPatients(patientId: number): PatientModel {
    return this.patients.find(p => p.id == patientId);
  }

  loadPatientsWithSpecialDiets(patients: PatientModel[]) {
    this.patients = patients;
    var patientsWithSpecialRequirements = patients.filter(s => s.afcDietaryRequirementsList.length > 0)
    this.patientRequirements = patientsWithSpecialRequirements;
    this.tableData2 = new TableCompose()
      .composeHeader('fullName', 'Patient Name', DataType.Plain)
      .setBody(this.patientRequirements)
  }

  loadDietaryRequirements(requirements: KitchenDietaryRequirements[]) {
    this.isAdd = false;
    requirements.forEach(req => req.category = this.mapCategory(req.categoryId));
    requirements.forEach(menu => menu.foodMenu = this.mapMenu(menu.foodMenuId));
    this.Requirements = requirements;
    this.tableData = new TableCompose()
      .composeHeader('foodMenu', 'Food Menu', DataType.Selection, 'name')
      .composeHeader('category', 'Category', DataType.Selection, 'name')
      .setBody(this.Requirements);
  }

  itemClick(item) {
    this.selected = item;
    this.isAdd = false;
  }

  patientClick(item){
    this.http.get('dietary/requirements/patient/' +item.id, (patients) => this.loadDietaryRequirements(patients))
    this.selectedPatient = item;
    this.selected = null;
    this.viewCategories = true; 
  }

  addClick() {
    this.selected = {};
    this.isAdd = true;
  }

  editClick(item) {
    this.selected = item;
    this.isAdd = true;
  }

  backClick() {
    this.viewCategories = false;
    this.selected = null;
  }

  deleteClick(requirement: KitchenDietaryRequirements) {
    this.http.delete('dietary/requirements/' + requirement.id, (result) => {
      swal('', result.message, 'success');
      this.reloadRequirements(result)
    });
  }

  reloadRequirements($event) {
    this.viewCategories = false;
    this.isAdd = false;
    this.selected = null;
    setTimeout(()=> this.getPatients(), 100);
  }
}
