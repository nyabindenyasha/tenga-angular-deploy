import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { KitchenDiertaryRequirementsComponent } from './kitchen-diertary-requirements.component';

describe('KitchenDiertaryRequirementsComponent', () => {
  let component: KitchenDiertaryRequirementsComponent;
  let fixture: ComponentFixture<KitchenDiertaryRequirementsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ KitchenDiertaryRequirementsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(KitchenDiertaryRequirementsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
