import { Component, OnInit } from '@angular/core';
import { HttpRequestComponent } from 'src/app/provider/http-request/http-request.component';
import { InventoryTracker } from 'src/app/model/kitchen/kitchen-inventory-tracker';

@Component({
  selector: 'app-kitchen-dashboard',
  templateUrl: './kitchen-dashboard.component.html',
  styleUrls: ['./kitchen-dashboard.component.scss']
})
export class KitchenDashboardComponent implements OnInit {

  public cartegoryTypes: any;
  public inventoryData: InventoryTracker[];
  public issued: number;
  public available: number;
  public selected:number;

  public chartType: string = 'doughnut';
  public chartData: Array<any> = [this.available, this.issued];
  public chartLabels: Array<any> = ['Available', 'Issued'];
  public chartOptions: any = {
    responsive: true
  };
  public chartClicked(e: any): void { }
  public chartHovered(e: any): void { }

  public chartColors: Array<any> = [{
    backgroundColor: this.getColors()
  }];


  constructor(private http: HttpRequestComponent) {
    this.getDisplayedData()
  }

  ngOnInit() {
  }

  getDisplayedData() {
    this.http.get('/kitchen/inventory/category', (data) => this.cartegoryTypes = data); 
    this.http.get('/kitchen/inventory/tracker', (inventoryData) => this.inventoryData = inventoryData);
    this.http.get('/kitchen/inventory/tracker', (inventoryData) => this.getTotal(inventoryData));
  }
  getTotal(inventoryData) {
    this.inventoryData = inventoryData;
    var available = 0;
    var issued = 0;

    if (this. inventoryData != null && this. inventoryData.length > 0) {
      this. inventoryData.forEach(item => available += item.storageQuantity);
      this. inventoryData.forEach(item => issued += item.issuedQuantity);
      this.available = available;
      this.issued = issued;
      this.chartData = [this.available, this.issued];
    }
  }
  getColor(data:number){
    switch (data % 10) {
      case 0:
        return '#A11D0D';
      default:
        return '#0A3981';
    }
  }

 private getColors(){
    var colors: string[] = [];
    for (var count: number = 0; count < 10; count++) {
      colors.push(this.getColor(count))
    }
    return colors;
  }

  selectItem(selected) {
    this.selected = selected;
    this.loadChartData();
  }
  loadChartData(){
    var selectedItem = this.inventoryData.find((item) => item. categoryId == this.selected);
    if (!selectedItem) selectedItem = new InventoryTracker();
    this.chartData = [selectedItem.storageQuantity, selectedItem.issuedQuantity];
  }
}
