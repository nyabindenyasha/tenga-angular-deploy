import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { KitchenDutyRoasterComponent } from './kitchen-duty-roaster.component';

describe('KitchenDutyRoasterComponent', () => {
  let component: KitchenDutyRoasterComponent;
  let fixture: ComponentFixture<KitchenDutyRoasterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ KitchenDutyRoasterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(KitchenDutyRoasterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
