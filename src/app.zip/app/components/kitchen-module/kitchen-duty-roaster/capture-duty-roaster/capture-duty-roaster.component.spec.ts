import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CaptureDutyRoasterComponent } from './capture-duty-roaster.component';

describe('CaptureDutyRoasterComponent', () => {
  let component: CaptureDutyRoasterComponent;
  let fixture: ComponentFixture<CaptureDutyRoasterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CaptureDutyRoasterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CaptureDutyRoasterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
