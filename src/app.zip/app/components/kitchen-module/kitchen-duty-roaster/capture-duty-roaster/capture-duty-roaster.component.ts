import { Component, OnInit, EventEmitter, Input, Output } from '@angular/core';
import { HttpRequestComponent } from 'src/app/provider/http-request/http-request.component';
import { dutyRoaster } from 'src/app/model/kitchen/duty-roaster';
import { Validation } from 'src/app/provider/validation/validation';
import { kitcheinStaff } from 'src/app/model/kitchen/staff';
import { kitchenTask } from 'src/app/model/kitchen/task';
import swal from 'sweetalert2';
import { ValidationType } from 'src/app/provider/validation/validation-type.enum';

@Component({
  selector: 'app-capture-duty-roaster',
  templateUrl: './capture-duty-roaster.component.html',
  styleUrls: ['./capture-duty-roaster.component.scss']
})
export class CaptureDutyRoasterComponent implements OnInit {
  @Input() newTask: dutyRoaster;
  @Input() kitchein: kitcheinStaff[];
  @Input() tasks: kitchenTask[];
  @Output() emitter = new EventEmitter<any>()
  validation: Validation;


  constructor(private http: HttpRequestComponent) {
    this.http.get('/staff/job/role/1', (data) => this.getStaff(data))
  }

  ngOnInit() {
    this.loadValidation();
    if (!this.newTask) {
      this.newTask = new dutyRoaster();
      this.newTask.id = 0;
    }
  }

  getStaff(staff: kitcheinStaff[]) {
    this.kitchein = staff.filter(x => x.isAvailable == true);
  }

  loadValidation() {
    this.validation = new Validation();
    this.validation.addField({ name: 'staffId', display: 'Staff name', type: ValidationType.Required });
    this.validation.addField({ name: 'taskId', display: 'Task name', type: ValidationType.Required })
  }

  submit() {
    if (this.newTask.id)
      this.http.put('/duty/roster/' + this.newTask.id, this.newTask, (result) => this.onSuccess(result.message));
    else
      this.http.post('/duty/roster', this.newTask, (result) => this.onSuccess(result.message));
  }

  onSuccess(result) {
    swal('', result, 'success');
    this.emitter.emit(this.newTask);
  }
}