import { Component, OnInit } from '@angular/core';
import { TableCompose } from 'src/app/provider/table/table-compose';
import { HttpRequestComponent } from 'src/app/provider/http-request/http-request.component';
import { dutyRoaster } from 'src/app/model/kitchen/duty-roaster';
import { DataType } from 'src/app/provider/table/data-type.enum';
import { kitchenTask } from 'src/app/model/kitchen/task';
import { kitcheinStaff } from 'src/app/model/kitchen/staff';

@Component({
  selector: 'app-kitchen-duty-roaster',
  templateUrl: './kitchen-duty-roaster.component.html',
  styleUrls: ['./kitchen-duty-roaster.component.scss']
})
export class KitchenDutyRoasterComponent implements OnInit {
  _search : boolean = false;
  dutyRosters = new Array<dutyRoaster>();
 // dutyRosters:dutyRoaster[];
  tasks: kitchenTask[];
  staffMembers: kitcheinStaff[];
  tableData: TableCompose;
  selectedStaff: any;
  isAdd: boolean;

  constructor(private http: HttpRequestComponent) {
  }

  ngOnInit() {
    this._search = true;
    this.getKitchenTask();
  }  
  getKitchenTask() {
    this.http.get('/kitchen/task', (data) => {
      this.tasks = data;
      this. getKitchenStaff();
    })
  }

  getKitchenStaff(){
    this.http.get('/staff', (staff) =>{ 
      this.staffMembers= staff;
      this.getDutyRoster();
    });
   
  }
  getDutyRoster() { 
    this.http.get('/duty/roster', (duties) => this.loadDutyRoster(duties));
  }
 
  mapTask(taskId: number): kitchenTask {
    return this.tasks.find(x => x.id == taskId);
  }

  mapStaff(userId: number): kitcheinStaff {
    return this.staffMembers.find(x => x.id == userId);
  }

  loadDutyRoster(duties: dutyRoaster[]) {
    duties.forEach(x => x.kitchein_task = this.mapTask(x.taskId));
    duties.forEach(x => x.kitchein_staff = this.mapStaff(x.staffId))
    this.dutyRosters = duties;
    this.tableData = new TableCompose()
      .composeHeader('kitchein_staff', 'Staff', DataType.Selection, 'username')
      .composeHeader('kitchein_task', 'Task', DataType.Selection, 'name')
      .setBody(this.dutyRosters);
  }

  itemClick(item) {
    this.selectedStaff = item;
    this.isAdd = false;
  }

  addClick() {
    this.selectedStaff = new dutyRoaster();
    this.selectedStaff.id = 0;;
    this.isAdd = true;
  }

  editClick(item) {
    this.selectedStaff = item;
    this.isAdd = true;
  }

  reloadRequirements($event) {
    this.getDutyRoster();
    this.isAdd = false;
    this.selectedStaff = null;
  }
}
