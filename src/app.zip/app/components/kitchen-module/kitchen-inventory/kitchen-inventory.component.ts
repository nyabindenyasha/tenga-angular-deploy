import { Component, OnInit} from '@angular/core';
import { TableCompose } from 'src/app/provider/table/table-compose';
import { HttpRequestComponent } from 'src/app/provider/http-request/http-request.component';
import { KitchenInventoryCategory } from 'src/app/model/kitchen/kitchen-inventory-category';
import { DataType } from 'src/app/provider/table/data-type.enum';
import { QuantityTypes } from 'src/app/model/kitchen/quantityTypes';
import { KitchenInventoryType } from 'src/app/model/kitchen/kitchen-inventory-type';

@Component({
  selector: 'app-kitchen-inventory',
  templateUrl: './kitchen-inventory.component.html',
  styleUrls: ['./kitchen-inventory.component.scss']
})
export class KitchenInventoryComponent implements OnInit {
  inventoryCategoryDetails: KitchenInventoryCategory[];
  quantityTypeDetails: QuantityTypes[];
  inventoryTypeDetails: KitchenInventoryType[];
  tableData: TableCompose;
  selected: any;
  viewOptions: boolean;
  inventoryCategoryId: number;

  constructor(private http: HttpRequestComponent) { }

  ngOnInit() {
    this.getKitchenQuantityType();
    this.getKitchenInventoryType();
  }

  getKitchenQuantityType() {
    this.http.get('/kitchen/inventory/quantity/type', (quantityType) => {
      this.quantityTypeDetails = quantityType;
      this.loadCategories();
    })
  }

  getKitchenInventoryType() {
    this.http.get('/kitchen/inventory/type', (inventoryType) => {
      this.inventoryTypeDetails = inventoryType;
    })
  }

  loadCategories() {
    this.http.get('/kitchen/inventory/category', (categories) => this.loadInventoryCategory(categories));
  }

  mapQuantityType(quantityTypeid: number): QuantityTypes {
    return this.quantityTypeDetails.find(type => type.id == quantityTypeid);
  }

  mapInventoryType(typeId: number): KitchenInventoryType {
    return this.inventoryTypeDetails.find(type => type.id == typeId);
  }

  loadInventoryCategory(categories: KitchenInventoryCategory[]) {
    categories.forEach(category => category.quantityTypeName = this.mapQuantityType(category.quantityTypeid));
    categories.forEach(category => category.typeName = this.mapInventoryType(category.typeId));
    this.inventoryCategoryDetails = categories
    this.tableData = new TableCompose()
      .composeHeader('name', ' Name ', DataType.Plain)
      .composeHeader('typeName', 'Type', DataType.Selection, 'name')
      .composeHeader('quantityTypeName', 'Quantity Type', DataType.Selection, 'name')
      .setBody(this.inventoryCategoryDetails);
  }
  itemClick(item) {
    this.selected = item;
    this.inventoryCategoryId = this.selected.id;
    this.viewOptions = true;
  }
}