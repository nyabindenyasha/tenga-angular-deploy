import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DietaryModuleComponent } from './dietary-module.component';

describe('DietaryModuleComponent', () => {
  let component: DietaryModuleComponent;
  let fixture: ComponentFixture<DietaryModuleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DietaryModuleComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DietaryModuleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
