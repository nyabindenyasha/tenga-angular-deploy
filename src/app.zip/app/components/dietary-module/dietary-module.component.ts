import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dietary-module',
  templateUrl: './dietary-module.component.html',
  styleUrls: ['./dietary-module.component.scss']
})
export class DietaryModuleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
