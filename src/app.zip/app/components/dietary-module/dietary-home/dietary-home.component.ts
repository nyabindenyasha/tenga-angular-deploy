import { Component, OnInit } from '@angular/core';
import { HttpRequestComponent } from 'src/app/provider/http-request/http-request.component';
import { KitchenDietaryRequirements } from 'src/app/model/kitchen/kitchen-dietary-requirements';
import { KitchenDietaryCategory } from 'src/app/model/kitchen/kitchen-dietary-category'

@Component({
  selector: 'app-dietary-home',
  templateUrl: './dietary-home.component.html',
  styleUrls: ['./dietary-home.component.scss']
})
export class DietaryHomeComponent implements OnInit {
  requirements: KitchenDietaryRequirements[];
  choices: KitchenDietaryCategory[];
  allergies: number;
  recommended: number;
  prefered: number;
  arrayFilter = [];

  constructor(private http: HttpRequestComponent) {
    this.http.get('/dietary/category', (choices) => this.getCategories(choices));
  }

  ngOnInit() {
    this.http.get('/dietary/requirements', (data) => this.requirements = (data));
    this.http.get('/dietary/requirements', () => this.getRequirements());
  }

  getRequirements() {
    var count = {};
    this.requirements.forEach(function (i) { count[i.categoryId] = (count[i.categoryId] || 0) + 1; });
    for (const e of Object.values(count)) this.arrayFilter.push(e);
    this.chartData = this.arrayFilter;
  }

  getCategories(category: KitchenDietaryCategory[]) {
    this.choices = category;
    category.forEach(i => this.chartLabels.push(i.name));
  }

  public chartType: string = 'doughnut';
  public chartData: Array<any> = [];
  public chartLabels: Array<any> = [];
  public chartColors: Array<any> = [{
    backgroundColor: this.getColors()
  }];

  public chartOptions: any = {
    responsive: true
  };
  public chartClicked(e: any): void { }
  public chartHovered(e: any): void { }

  private getColors(): string[] {
    var colors: string[] = [];
    for (var count: number = 0; count < 10; count++) {
      colors.push(this.getColor(count))
    }
    return colors;
  }

  getColor(data: number) {
    switch (data % 10) {
      case 0:
        return '#0A3981';
      case 1:
        return '#A11D0D';
      default:
        return ' #47A10D';
    }
  }
}
