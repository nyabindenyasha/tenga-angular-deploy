import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DietaryHomeComponent } from './dietary-home.component';

describe('DietaryHomeComponent', () => {
  let component: DietaryHomeComponent;
  let fixture: ComponentFixture<DietaryHomeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DietaryHomeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DietaryHomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
