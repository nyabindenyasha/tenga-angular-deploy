import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LaundryHomeComponent } from './laundry-home.component';

describe('LaundryHomeComponent', () => {
  let component: LaundryHomeComponent;
  let fixture: ComponentFixture<LaundryHomeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LaundryHomeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LaundryHomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
