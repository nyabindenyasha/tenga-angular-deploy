import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-laundry-home',
  templateUrl: './laundry-home.component.html',
  styleUrls: ['./laundry-home.component.scss']
})
export class LaundryHomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
