import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LaundryModuleComponent } from './laundry-module.component';

describe('LaundryModuleComponent', () => {
  let component: LaundryModuleComponent;
  let fixture: ComponentFixture<LaundryModuleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LaundryModuleComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LaundryModuleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
