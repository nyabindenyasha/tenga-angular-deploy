import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-laundry-system-parameter',
  templateUrl: './laundry-system-parameter.component.html',
  styleUrls: ['./laundry-system-parameter.component.scss']
})
export class LaundrySystemParameterComponent implements OnInit {
  constructor() { }

  ngOnInit() {
  }
 
}
