import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LaundrySystemParameterComponent } from './laundry-system-parameter.component';

describe('LaundrySystemParameterComponent', () => {
  let component: LaundrySystemParameterComponent;
  let fixture: ComponentFixture<LaundrySystemParameterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LaundrySystemParameterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LaundrySystemParameterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
