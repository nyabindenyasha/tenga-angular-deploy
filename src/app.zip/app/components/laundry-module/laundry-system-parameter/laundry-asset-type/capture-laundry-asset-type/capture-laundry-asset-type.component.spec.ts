import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CaptureLaundryAssetTypeComponent } from './capture-laundry-asset-type.component';

describe('CaptureLaundryAssetTypeComponent', () => {
  let component: CaptureLaundryAssetTypeComponent;
  let fixture: ComponentFixture<CaptureLaundryAssetTypeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CaptureLaundryAssetTypeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CaptureLaundryAssetTypeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
