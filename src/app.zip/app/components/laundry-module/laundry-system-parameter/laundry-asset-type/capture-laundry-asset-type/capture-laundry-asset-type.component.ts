import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Validation } from 'src/app/provider/validation/validation';
import { ValidationType } from 'src/app/provider/validation/validation-type.enum';
import { HttpRequestComponent } from 'src/app/provider/http-request/http-request.component';
import { LaundryAssetType } from 'src/app/model/laundry/laundry-asset-type';
import swal from 'sweetalert2';


@Component({
  selector: 'app-capture-laundry-asset-type',
  templateUrl: './capture-laundry-asset-type.component.html',
  styleUrls: ['./capture-laundry-asset-type.component.scss']
})
export class CaptureLaundryAssetTypeComponent implements OnInit {
  @Input() asset: LaundryAssetType
  @Output() data: EventEmitter<any> = new EventEmitter<LaundryAssetType>()
  validation: Validation;

  constructor(private http: HttpRequestComponent) { }

  ngOnInit() {
    if (this.asset == null)
      this.asset = new LaundryAssetType();
    this.loadValidation();
  }

  loadValidation() {
    this.validation = new Validation();
    this.validation.addField({ name: 'name', display: 'Asset Type', type: ValidationType.Required });
  }

  onSubmitAsset() {
    if (this.asset.id > 0) {
      this.http.update('laundry/asset/type/' + this.asset.id, this.asset, (result) => this.submitResult(result));
      return;
    }
    this.http.post('laundry/asset/type', this.asset, (result) => this.submitResult(result));
  }

  submitResult(result) {
    swal('', 'Assets successfully updated', 'success');
    this.data.emit(this.asset);
  }
}