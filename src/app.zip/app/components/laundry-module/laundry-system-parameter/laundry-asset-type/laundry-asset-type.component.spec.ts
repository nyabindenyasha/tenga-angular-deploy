import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LaundryAssetTypeComponent } from './laundry-asset-type.component';

describe('LaundryAssetTypeComponent', () => {
  let component: LaundryAssetTypeComponent;
  let fixture: ComponentFixture<LaundryAssetTypeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LaundryAssetTypeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LaundryAssetTypeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
