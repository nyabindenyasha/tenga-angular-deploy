import { Component, OnInit } from '@angular/core';
import { TableCompose } from 'src/app/provider/table/table-compose';
import { DataType } from 'src/app/provider/table/data-type.enum';
import { HttpRequestComponent } from 'src/app/provider/http-request/http-request.component';
import { LaundryAssetType } from 'src/app/model/laundry/laundry-asset-type';
import swal from 'sweetalert2';

@Component({
  selector: 'app-laundry-asset-type',
  templateUrl: './laundry-asset-type.component.html',
  styleUrls: ['./laundry-asset-type.component.scss']
})
export class LaundryAssetTypeComponent implements OnInit {
  laundry: LaundryAssetType[] = [];
  tableData: TableCompose;
  selected: any;
  isAdd: boolean;
  assetDetails: any[];


  constructor(private http: HttpRequestComponent) {
    this.fetchAssetTypes();
  }

  fetchAssetTypes() {
    this.http.get('/laundry/asset/type', (assets) => this.getAssetTypes(assets))
  }

  ngOnInit() {
  }


  getAssetTypes(asset: LaundryAssetType[]) {
    this.assetDetails = asset;
    this.tableData = new TableCompose()
      .composeHeader('id', 'Id', DataType.Plain)
      .composeHeader('name', 'Asset Name', DataType.Plain)
      .composeHeader('active', 'Active', DataType.Plain)
      .setBody(this.assetDetails);
  }

  itemClick(item) {
    this.selected = item;
    this.isAdd = false;
  }

  addClick() {
    this.selected = {};
    this.isAdd = true;
  }

  editClick(item) {
    this.selected = item;
    this.isAdd = true;
  }

  deleteClick(item: LaundryAssetType) {
    this.http.delete('laundry/asset/type/' + item.id, (result) => {
      swal('', result.message, 'success');
      this.reloadLaundryAssetType(result)
    });
  }

  reloadLaundryAssetType($event) {
    this.fetchAssetTypes();
    this.isAdd = false;
    this.selected = null;
  }
}