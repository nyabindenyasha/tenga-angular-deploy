import { Component, OnInit } from '@angular/core';
import { TableCompose } from 'src/app/provider/table/table-compose';
import { DataType } from 'src/app/provider/table/data-type.enum';
import { LaundryAsset } from 'src/app/model/laundry/laundry-assets';
import { HttpRequestComponent } from 'src/app/provider/http-request/http-request.component';
import { LaundryAssetType } from 'src/app/model/laundry/laundry-asset-type';

@Component({
  selector: 'app-laundry-assets',
  templateUrl: './laundry-assets.component.html',
  styleUrls: ['./laundry-assets.component.scss']
})
export class LaundryAssetsComponent implements OnInit {
  assetsDetails: LaundryAsset[];
  assetTypes: LaundryAssetType[];
  tableData: TableCompose;
  selected: LaundryAsset;
  isAdd: boolean;

  constructor(private http: HttpRequestComponent) {

  }

  ngOnInit() {
    this.getAssets()
  }

  getAssets() {
    this.http.get('/laundry/asset/type', (assetTypes) => {
      this.assetTypes = assetTypes;
      this.loadAssets();
    })
  }

  loadAssets() {
    this.http.get('/laundry/asset', (assets) => this.loadLaundryAssets(assets));
  }

  mapAssetType(assetTypeId: number): LaundryAssetType {
    return this.assetTypes.find(type => type.id == assetTypeId);
  }

  loadLaundryAssets(assets: LaundryAsset[]) {
    assets.forEach(asset => asset.assetType = this.mapAssetType(asset.assetTypeId));
    this.assetsDetails = assets;
    this.tableData = new TableCompose()
      .composeHeader('dateCreated', 'Date Created', DataType.Date)
      .composeHeader('assetType', 'Asset Type', DataType.Selection, 'name')
      .composeHeader('quantity', 'Quantity', DataType.Plain)
      .setBody(this.assetsDetails);
  }

  itemClick(item) {
    this.selected = item;
    this.isAdd = false;
  }

  addClick() {
    this.selected = new LaundryAsset();
    this.isAdd = true;
  }

  editClick(item) {
    this.selected = item;
    this.isAdd = true;
  }
  
  reloadLaundryAssets(asset) {
    this.isAdd = false;
    this.selected = null;
    this.getAssets()
  }
}
