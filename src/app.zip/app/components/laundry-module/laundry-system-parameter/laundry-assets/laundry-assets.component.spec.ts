import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LaundryAssetsComponent } from './laundry-assets.component';

describe('LaundryAssetsComponent', () => {
  let component: LaundryAssetsComponent;
  let fixture: ComponentFixture<LaundryAssetsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LaundryAssetsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LaundryAssetsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
