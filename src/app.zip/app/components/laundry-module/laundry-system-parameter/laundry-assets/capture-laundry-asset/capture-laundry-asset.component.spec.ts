import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CaptureLaundryAssetComponent } from './capture-laundry-asset.component';

describe('CaptureLaundryAssetComponent', () => {
  let component: CaptureLaundryAssetComponent;
  let fixture: ComponentFixture<CaptureLaundryAssetComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CaptureLaundryAssetComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CaptureLaundryAssetComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
