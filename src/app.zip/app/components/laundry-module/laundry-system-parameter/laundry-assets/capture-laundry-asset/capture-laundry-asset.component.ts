import { Component, OnInit, Input, Output } from '@angular/core';
import { MortuaryShelf } from 'src/app/model/mortuary/mortuary-shelf';
import { Validation } from 'src/app/provider/validation/validation';
import { ValidationType } from 'src/app/provider/validation/validation-type.enum';
import { HttpRequestComponent } from 'src/app/provider/http-request/http-request.component';
import swal from 'sweetalert2';
import { EventEmitter } from '@angular/core';
import { LaundryAsset } from 'src/app/model/laundry/laundry-assets';

@Component({
  selector: 'app-capture-laundry-asset',
  templateUrl: './capture-laundry-asset.component.html',
  styleUrls: ['./capture-laundry-asset.component.scss']
})
export class CaptureLaundryAssetComponent implements OnInit {
  @Input() asset: LaundryAsset;
  @Output() data: EventEmitter<any> = new EventEmitter<LaundryAsset>();

  validation: Validation;
  assetType: any[];
  constructor(private http: HttpRequestComponent) {
    this.http.get("/laundry/asset/type", ((result) => this.getAssetType(result)));
  }

  ngOnInit() {
    console.log(this.asset);
    if (this.asset == null) this.asset = new LaundryAsset();
    this.loadValidation();
  }
  getAssetType(assetType) {
    this.assetType = assetType;
  }

  loadValidation() {
    this.validation = new Validation();
    this.validation.addField({ name: 'assetTypeId', display: 'Asset Type', type: ValidationType.Required });
    this.validation.addField({ name: 'quantity', display: 'Quantity', type: ValidationType.GreaterThan }, 0);
    this.validation.addField({ name: 'dateCreated', display: 'Date Recieved ', type: ValidationType.Date },  new Date(this.asset.dateCreated).getTime());

  }

  getDate(value){
    this.loadValidation();
  }
  
  onSubmit() {
    this.http.post('/laundry/asset', this.asset, (result) => swal('', result.message, 'success'));
    this.data.emit(this.asset);
  }
}