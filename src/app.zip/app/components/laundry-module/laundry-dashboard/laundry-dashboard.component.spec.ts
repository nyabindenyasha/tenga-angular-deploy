import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LaundryDashboardComponent } from './laundry-dashboard.component';

describe('LaundryDashboardComponent', () => {
  let component: LaundryDashboardComponent;
  let fixture: ComponentFixture<LaundryDashboardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LaundryDashboardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LaundryDashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
