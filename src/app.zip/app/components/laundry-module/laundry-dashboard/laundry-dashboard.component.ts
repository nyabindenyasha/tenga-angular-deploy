import { Component, OnInit } from '@angular/core';
import { HttpRequestComponent } from 'src/app/provider/http-request/http-request.component';
import { laundryTracker } from 'src/app/model/laundry/laundry-tracker';
import swal from 'sweetalert2';

@Component({
  selector: 'app-laundry-dashboard',
  templateUrl: './laundry-dashboard.component.html',
  styleUrls: ['./laundry-dashboard.component.scss']
})
export class LaundryDashboardComponent implements OnInit {
  assetTypes: any;
  laundryTracker: laundryTracker[];
  selectedType: number;
  clean: number;
  dirty: number;
  issued: number;

  laundryTotal: laundryTracker;
  constructor(private http: HttpRequestComponent) {
    this.http.get('/laundry/asset/type', (data) => this.assetTypes = data);
    this.http.get('/laundry/track', (laundryData) => this.laundryTracker = laundryData);
    this.http.get('/laundry/track', (laundryData) => this.getTotal(laundryData));
  }

  ngOnInit() {
   
  }

  selectAssetType(selected) {
    this.selectedType = selected;
    this.loadChartData();
  }

  loadChartData() {
    var selectedTracker = this.laundryTracker.find((tracker) => tracker.assetTypeId == this.selectedType);
    if (!selectedTracker) selectedTracker = new laundryTracker();
    this.chartData = [selectedTracker.cleanQuantity, selectedTracker.dirtyQuantity, selectedTracker.issuedQuantity];
  }

  getTotal(laundryData: any) {
    this.laundryTracker = laundryData
    var clean = 0;
    var dirty = 0;
    var issued = 0;

    if (this.laundryTracker != null && this.laundryTracker.length > 0) {
      this.laundryTracker.forEach(x => clean += x.cleanQuantity);
      this.laundryTracker.forEach(x => dirty += x.dirtyQuantity);
      this.laundryTracker.forEach(x => issued += x.issuedQuantity);
      this.clean = clean;
      this.dirty = dirty;
      this.issued = issued;
      this.chartData = [this.clean, this.dirty, this.issued];
    }
  }

  public chartType: string = 'doughnut';
  public chartData: Array<any> = [this.clean, this.dirty, this.issued];
  public chartLabels: Array<any> = ['Clean', 'Dirty', 'Issued'];
  public chartColors: Array<any> = [{
    backgroundColor: this.getColors()
  }];

  public chartOptions: any = {
    responsive: true
  };
  public chartClicked(e: any): void { }
  public chartHovered(e: any): void { }

  private getColors(): string[] {
    var colors: string[] = [];
    for (var count: number = 0; count < 10; count++) {
      colors.push(this.getColor(count))
    }
    return colors;
  }

  getColor(data: number) {
    switch (data % 10) {
      case 0:
        return '#0A3981';
      case 1:
        return '#A11D0D';
      default:
        return ' #47A10D';
    }
  }
}




