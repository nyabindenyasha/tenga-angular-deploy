import { Component, OnInit } from '@angular/core';
import { HttpRequestComponent } from 'src/app/provider/http-request/http-request.component';
import { LaundryOut } from 'src/app/model/laundry/laundry-out';
import { TableCompose } from 'src/app/provider/table/table-compose';
import { DataType } from 'src/app/provider/table/data-type.enum';
import swal from 'sweetalert2';
import { LaundryAssetType } from 'src/app/model/laundry/laundry-asset-type';

@Component({
  selector: 'app-laundry-out',
  templateUrl: './laundry-out.component.html',
  styleUrls: ['./laundry-out.component.scss']
})
export class LaundryOutComponent implements OnInit {
  _search : boolean = false;
  assetTypes = new Array<LaundryAssetType>();
  laundry:LaundryOut[]=[];
  tableData: TableCompose;
  selected: any;
  isAdd: boolean;
  constructor(private http: HttpRequestComponent) {
    this.getAssetTypes();
  }

  ngOnInit() {
    this._search = true;
    this.getLaundryOut();
  }

  getAssetTypes() {
    this.http.get('/laundry/asset/type', (assetTypes) => {
      this.assetTypes = assetTypes;
      this.getLaundryOut();
    })
  }

  getLaundryOut() {
    this.http.get('/laundry/out', (laundry) => this.loadLaundryItems(laundry));
  }

  mapAssetTypes(assetTypeId: number): LaundryAssetType {
    return this.assetTypes.find(q => q.id == assetTypeId);
  }

  loadLaundryItems(laundry: LaundryOut[]) {
    console.log(this.assetTypes, laundry);
    return;
    laundry.forEach(laundry => laundry.assetType = this.mapAssetTypes(laundry.assetTypeId));
    this.laundry = laundry;
    this.tableData = new TableCompose()
      .composeHeader('assetType', ' Asset Type', DataType.Selection, 'name')
      .composeHeader('quantity', 'Quantity', DataType.Plain)
      .composeHeader('username', 'Username', DataType.Plain)
      .composeHeader('dateCreated', 'Date Created', DataType.Date)
      .setBody(this.laundry);
  }

  itemClick(item) {
    this.selected = item;
    this.isAdd = false;
  }

  addClick() {
    this.selected = {};
    this.isAdd = true;
  }

  editClick(item) {
    this.selected = item;
    this.isAdd = true;
  }

  reloadLaundryOut($event) {
    this.getLaundryOut()
    this.isAdd = false;
    this.selected = null;
  }
}
