import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { HttpRequestComponent } from 'src/app/provider/http-request/http-request.component';
import { Validation } from 'src/app/provider/validation/validation';
import swal from 'sweetalert2';
import { LaundryOut } from 'src/app/model/laundry/laundry-out';
import { ValidationType } from 'src/app/provider/validation/validation-type.enum';
import { LaundryAssetType } from 'src/app/model/laundry/laundry-asset-type';
import { LaundryLocation, LaundryLocationHelper } from 'src/app/model/laundry/laundry-location';

@Component({
  selector: 'app-capture-laundry-out',
  templateUrl: './capture-laundry-out.component.html',
  styleUrls: ['./capture-laundry-out.component.scss']
})
export class CaptureLaundryOutComponent implements OnInit {
  @Input() laundryOut: LaundryOut;
  assetTypes: LaundryAssetType[];
  @Output() result = new EventEmitter<any>();
  validation: Validation;
  locations: Array<LaundryLocation> = [LaundryLocation.Ward, LaundryLocation.Laundry, LaundryLocation.Donated, LaundryLocation.Obsolete];
  laundryLocations: Array<any> = [];
  locationHelper: LaundryLocationHelper;
  selectedAssetTypeStatus: any;
  limitValue: any = 1;
  message: boolean;
  location: string;
  type: any;
  staff: any[];

  constructor(private http: HttpRequestComponent) {
    this.http.get('/laundry/asset/type', (assetTypes) => this.getAssetTypes(assetTypes));
    this.http.get('staff', (staff) => this.staff = staff);
  }

  ngOnInit() {
    if (!this.laundryOut) this.laundryOut = new LaundryOut();
    this.loadValidation();
    this.loadLocations();
  }

  getAssetTypes(assetTypes: LaundryAssetType[]) {
    this.assetTypes = assetTypes;
  }

  loadValidation() {
    this.validation = new Validation();
    this.validation.addField({ name: 'username', display: 'Receiver Name', type: ValidationType.Required });
    this.validation.addField({ name: 'assetTypeId', display: 'Laundry Type', type: ValidationType.Required });
    this.validation.addField({ name: 'locationId', display: 'To', type: ValidationType.Required });
    this.validation.addField({ name: 'quantity', display: 'Quantity', type: ValidationType.Between }, this.limitValue);
  }

  loadLocations() {
    this.locations.forEach(element => {
      var locationObject = { id: element, name: LaundryLocationHelper.get(element) };
      this.laundryLocations.push(locationObject);
    });
  }

  getQuantities(assetType: any) {
    this.laundryOut.quantity = null;
    this.selectedAssetTypeStatus = null;
    this.laundryOut.locationId = null;
    this.message = false;
    this.laundryOut.assetTypeId = parseInt(this.laundryOut.assetTypeId.toString());
    this.http.get('/laundry/track/asset/type/' + assetType, (assetStatus) => this.getAssetStatus(assetStatus));
  }

  getAssetStatus(assetStatus) {
    this.selectedAssetTypeStatus = assetStatus;
  }

  getQuantityLimits(location) {
    this.laundryOut.quantity = null;
    this.limitValue = 1;
    this.message = false;
    this.laundryOut.locationId = parseInt(this.laundryOut.locationId.toString());
    if (LaundryLocation.Ward == location || LaundryLocation.Donated == location)
      this.limitValue += this.selectedAssetTypeStatus.cleanQuantity;
    if (LaundryLocation.Laundry == location)
      this.limitValue += this.selectedAssetTypeStatus.dirtyQuantity;
    if (LaundryLocation.Obsolete == location)
      this.limitValue += this.selectedAssetTypeStatus.dirtyQuantity + this.selectedAssetTypeStatus.cleanQuantity;
    if (this.limitValue > 1) this.loadValidation();
    else this.laundryValidation();
  }

  laundryValidation() {
    this.message = true;
    this.location = LaundryLocationHelper.get(this.laundryOut.locationId);
    var obj = this.assetTypes.filter(a => a.id == this.laundryOut.assetTypeId);
    this.type = obj[0].name;
  }

  submit() {
    this.http.post('laundry/out', this.laundryOut, (result) => {
      swal('', result.message, 'success');
      this.result.emit(this.laundryOut);
    });
  }
}
