import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CaptureLaundryOutComponent } from './capture-laundry-out.component';

describe('CaptureLaundryOutComponent', () => {
  let component: CaptureLaundryOutComponent;
  let fixture: ComponentFixture<CaptureLaundryOutComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CaptureLaundryOutComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CaptureLaundryOutComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
