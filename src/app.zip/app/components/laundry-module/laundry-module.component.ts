import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-laundry-module',
  templateUrl: './laundry-module.component.html',
  styleUrls: ['./laundry-module.component.scss']
})
export class LaundryModuleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
