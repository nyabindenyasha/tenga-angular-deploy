import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { TableCompose } from 'src/app/provider/table/table-compose';
import { HttpRequestComponent } from 'src/app/provider/http-request/http-request.component';
import { LaundryBatch } from 'src/app/model/laundry/laundry-batch';
import { DataType } from 'src/app/provider/table/data-type.enum';
import { LaundryLocationHelper } from 'src/app/model/laundry/laundry-location';
import { LaundryAssetType } from 'src/app/model/laundry/laundry-asset-type';
import { LaundryOut } from 'src/app/model/laundry/laundry-out';


@Component({
  selector: 'app-laundry-batches',
  templateUrl: './laundry-batches.component.html',
  styleUrls: ['./laundry-batches.component.scss']
})
export class LaundryBatchesComponent implements OnInit {
  _search : boolean = false;
  laundryBatchesDetails: LaundryBatch[];
  tableData: TableCompose;
  selectedBatch: LaundryBatch;
  @Output() result = new EventEmitter<any>();
  isAdd: boolean;
  assetTypes:LaundryAssetType[];
  laundryOut: LaundryOut[];
  viewBatches: boolean;
  constructor(private http:HttpRequestComponent ) {
  }

  ngOnInit() { 
  this.getLaundryOut();
  this._search = true;
  }

  getLaundryOut() {
    this.http.get('laundry/out', (laundry) => this.laundryOut = laundry);
    this.getAssetTypes();
  } 

  getAssetTypes() {
    this.http.get('/laundry/asset/type', (assetTypes) => {
      this.assetTypes = assetTypes;
      this.loadBatches();
    })
  }

  loadBatches() {
    this.http.get('/laundry/batch', (batches) => this.getLaundryBatches(batches));
  }
  mapAssetTypes(assetTypeId: number):LaundryAssetType{
    return this.assetTypes.find(q=> q.id == assetTypeId);
  }

  mapLaundryOut(batchId: number): LaundryOut {
    var laundry = this.laundryOut.find(l => l.batchId == batchId);
    return laundry ? laundry : new LaundryOut(0);
  }

  getLaundryBatches(batches: LaundryBatch[]) {
    batches.forEach(batch => {
      batch.assetTypeName = this.mapAssetTypes(batch.assetTypeId);
      batch.location = LaundryLocationHelper.get(batch.locationId);
      batch.laundryOut = this.mapLaundryOut(batch.id);
    });

    this.laundryBatchesDetails = batches.sort((x, y) => y.quantity - x.quantity);

    this.tableData = new TableCompose()
      .composeHeader('assetTypeName', ' Asset', DataType.Selection, 'name')
      .composeHeader('laundryOut', 'Total', DataType.Selection, 'quantity')
      .composeHeader('quantity', 'Balance', DataType.Plain)
      .composeHeader('location', 'Location', DataType.Plain)
      .composeHeader('dateCreated', 'Date Added', DataType.Date)
      .composeHeader('isTaken', 'Closed', DataType.Check)
      .setBody(this.laundryBatchesDetails);
  }

  itemClick(batch) {
    this.selectedBatch = batch;
    this.viewBatches = false;
    this.isAdd = false;
  }

  addClick() {
    this.selectedBatch = new LaundryBatch();
    this.viewBatches = true;
    this.isAdd = true;
  }

  editClick(batch) {
    this.selectedBatch = batch;   
    this.isAdd = true;
  }

  deleteClick(batch) {
  }
  back(){  
    this.selectedBatch = null;
    this.result.emit();
  }
      
  reloadLaundryBatches($event){
    this. loadBatches()
    this.isAdd = false;
    this.selectedBatch = null;
  }
  
  
  
}
