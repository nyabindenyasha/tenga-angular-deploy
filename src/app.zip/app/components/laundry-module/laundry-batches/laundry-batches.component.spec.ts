import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LaundryBatchesComponent } from './laundry-batches.component';

describe('LaundryBatchesComponent', () => {
  let component: LaundryBatchesComponent;
  let fixture: ComponentFixture<LaundryBatchesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LaundryBatchesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LaundryBatchesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
