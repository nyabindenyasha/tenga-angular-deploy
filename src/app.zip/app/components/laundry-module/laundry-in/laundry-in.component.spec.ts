import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LaundryInComponent } from './laundry-in.component';

describe('LaundryInComponent', () => {
  let component: LaundryInComponent;
  let fixture: ComponentFixture<LaundryInComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LaundryInComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LaundryInComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
