import { Component, OnInit, Input, OnChanges, Output, EventEmitter } from '@angular/core';
import { HttpRequestComponent } from 'src/app/provider/http-request/http-request.component';
import { TableCompose } from 'src/app/provider/table/table-compose';
import { DataType } from 'src/app/provider/table/data-type.enum';

@Component({
  selector: 'app-laundry-in',
  templateUrl: './laundry-in.component.html',
  styleUrls: ['./laundry-in.component.scss']
})
export class LaundryInComponent implements OnInit, OnChanges {
  @Input() batch;
  laundries: any[];
  tableData: TableCompose;
  selected: any;
  isAdd: boolean;
  @Output() emitter= new EventEmitter<any>();
  constructor(private http: HttpRequestComponent) { }

  ngOnInit() {
    this.getLaundryIns();
  }

  ngOnChanges(changes: any): void {
    this.getLaundryIns();
  }

  getLaundryIns() {
    var url = this.batch ? `laundry/in/batch/${this.batch.id}` : 'laundry/in';
    this.http.get(url, (laundries) => this.loadLaundryTable(laundries));
  }

  loadLaundryTable(laundries: any[]) {
    this.laundries = laundries;
    this.tableData = new TableCompose()
      .composeHeader('username', 'Sister', DataType.Plain)
      .composeHeader('quantity', 'Quantity', DataType.Plain)
      .composeHeader('dateCreated', 'Date Added', DataType.Date)
      .setBody(this.laundries);
  }

  itemClick(item) {
    this.selected = item;
    this.isAdd = false;
  }

  addClick() {
    this.selected = {};
    this.isAdd = true;
  }

  backClick() {
    this.emitter.emit();
  }

  editClick(item) {
    this.selected = item;
    this.isAdd = true;
  }

  addedClick() {
    this.getLaundryIns();
    this.isAdd = false;
    this.selected = null;
  }
}