import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CaptureLaundryInComponent } from './capture-laundry-in.component';

describe('CaptureLaundryInComponent', () => {
  let component: CaptureLaundryInComponent;
  let fixture: ComponentFixture<CaptureLaundryInComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CaptureLaundryInComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CaptureLaundryInComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
