import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { LaundryIn } from 'src/app/model/laundry/laundry-in';
import { Validation } from 'src/app/provider/validation/validation';
import { ValidationType } from 'src/app/provider/validation/validation-type.enum';
import { HttpRequestComponent } from 'src/app/provider/http-request/http-request.component';
import swal from 'sweetalert2';
import { LaundryBatch } from 'src/app/model/laundry/laundry-batch';
import { log } from 'util';
import { LaundryLocationHelper } from 'src/app/model/laundry/laundry-location';

@Component({
  selector: 'app-capture-laundry-in',
  templateUrl: './capture-laundry-in.component.html',
  styleUrls: ['./capture-laundry-in.component.scss']
})
export class CaptureLaundryInComponent implements OnInit {
  validQuantity = 1;
  @Input() batch: LaundryBatch;
  @Input() laundryIn: LaundryIn;
  @Output() result = new EventEmitter<any>();
  validation: Validation;
  constructor(private http: HttpRequestComponent) { }

  ngOnInit() {
    if (!this.laundryIn) this.laundryIn = new LaundryIn();
    this.laundryIn.batchId = this.batch.id;
    this.loadValidation();
    this.validateBatch();
  }
  loadValidation() {
    this.validation = new Validation();
    this.validation.addField({ name: 'username', display: 'Sister/Nurse', type: ValidationType.Required });
    this.validation.addField({ name: 'quantity', display: 'Quantity', type: ValidationType.Between }, this.validQuantity);
  }
  validateBatch() {
    this.validQuantity += this.batch.quantity;
    this.loadValidation();
    this.validQuantity = 1;
  }

  submit(laundryIn) {
    this.http.post('laundry/in', this.laundryIn, (result) => {
      swal('', result.message, 'success');
      this.result.emit();
    });
  }
}