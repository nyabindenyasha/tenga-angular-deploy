import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { MDBBootstrapModule } from 'angular-bootstrap-md';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { AppComponent } from './app.component';
import { FormViewComponent } from './provider/form-view/form-view.component';
import { HttpRequestComponent } from './provider/http-request/http-request.component';
import { TableViewComponent } from './provider/table/table-view/table-view.component';
import { routingComponents, AppRoutingModule } from './app-routing.module';
import { HttpRequest2Component } from './provider/http-request/http-request2/http-request2.component';
import { TablePaginationComponent } from './provider/table/table-pagination/table-pagination.component';
import { httpInterceptorProviders } from './auth/auth/auth-interceptor';
import { LoadingSpinnerComponent } from './loading-spinner/loading-spinner.component';
import { AuthMainComponent } from './auth/auth-main/auth-main.component';


@NgModule({
  declarations: [
    AppComponent,
    HttpRequestComponent,
    HttpRequest2Component,
    TableViewComponent,
    TablePaginationComponent,
    FormViewComponent,
    LoadingSpinnerComponent,
    routingComponents,
    AuthMainComponent
    
  ],
  imports: [
    BrowserModule,
    FormsModule,
    MDBBootstrapModule.forRoot(),
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    FormsModule,
    HttpClientModule,
    FormsModule,
    AppRoutingModule
  ],
  providers: [
    HttpRequestComponent,
    HttpRequest2Component,
    httpInterceptorProviders
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }