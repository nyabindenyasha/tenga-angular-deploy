import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { RegisterComponentAuth } from './auth/register/register.component';
import { LoginComponentAuth } from './auth/login/login.component';
import { HomeComponentAuth } from './auth/home/home.component';
import { UserComponent } from './auth/user/user.component';
import { PmComponent } from './auth/pm/pm.component';
import { AdminComponent } from './auth/admin/admin.component';
import { MotuaryModuleComponent } from './components/motuary-module/motuary-module.component';
import { CaptureDeceasedComponent } from './components/motuary-module/capture-deceased/capture-deceased.component';
import { CapturePersonalInformationComponent } from './components/motuary-module/capture-deceased/capture-personal-information/capture-personal-information.component';
import { CaptureDeathInformationComponent } from './components/motuary-module/capture-deceased/capture-death-information/capture-death-information.component';
import { CaptureNextOfKinComponent } from './components/motuary-module/capture-deceased/capture-next-of-kin/capture-next-of-kin.component';
import { AssignShelfComponent } from './components/motuary-module/capture-deceased/assign-shelf/assign-shelf.component';
import { PostMotermComponent } from './components/motuary-module/post-moterm/post-moterm.component';
import { CapturePostMotermComponent } from './components/motuary-module/post-moterm/capture-post-moterm/capture-post-moterm.component';
import { CaptureCollectionInformationComponent } from './components/motuary-module/deceased-collection/capture-collection-information/capture-collection-information.component';
import { SystemParameterComponent } from './components/motuary-module/system-parameter/system-parameter.component';
import { MotuaryRoomsComponent } from './components/motuary-module/system-parameter/motuary-rooms/motuary-rooms.component';
import { CaptureMotuaryRoomComponent } from './components/motuary-module/system-parameter/motuary-rooms/capture-motuary-room/capture-motuary-room.component';
import { MotuaryShelvesComponent } from './components/motuary-module/system-parameter/motuary-shelves/motuary-shelves.component';
import { CaptureMortuaryShelfComponent } from './components/motuary-module/system-parameter/motuary-shelves/capture-mortuary-shelf/capture-mortuary-shelf.component';
import { DocumentViewerComponent } from './provider/document-viewer/document-viewer.component';
import { CaptureInstructionsComponent } from './components/motuary-module/capture-deceased/capture-instructions/capture-instructions.component';
import { MotuaryInhabitantsComponent } from './components/motuary-module/motuary-inhabitants/motuary-inhabitants.component';
import { ConfirmInformationComponent } from './components/motuary-module/capture-deceased/confirm-information/confirm-information.component';
import { DeceasedCollectionComponent } from './components/motuary-module/deceased-collection/deceased-collection.component';
import { HomeComponent } from './components/home/home.component';
import { LaundryModuleComponent } from './components/laundry-module/laundry-module.component';
import { MotuaryHomeComponent } from './components/motuary-module/motuary-home/motuary-home.component';
import { LaundryHomeComponent } from './components/laundry-module/laundry-home/laundry-home.component';
import { LaundryDashboardComponent } from './components/laundry-module/laundry-dashboard/laundry-dashboard.component';
import { LaundryOutComponent } from './components/laundry-module/laundry-out/laundry-out.component';
import { CaptureLaundryOutComponent } from './components/laundry-module/laundry-out/capture-laundry-out/capture-laundry-out.component';
import { CaptureLaundryInComponent } from './components/laundry-module/laundry-in/capture-laundry-in/capture-laundry-in.component';
import { LaundryInComponent } from './components/laundry-module/laundry-in/laundry-in.component';
import { LaundrySystemParameterComponent } from './components/laundry-module/laundry-system-parameter/laundry-system-parameter.component';
import { LaundryAssetsComponent } from './components/laundry-module/laundry-system-parameter/laundry-assets/laundry-assets.component';
import { CaptureLaundryAssetComponent } from './components/laundry-module/laundry-system-parameter/laundry-assets/capture-laundry-asset/capture-laundry-asset.component';
import { LaundryAssetTypeComponent } from './components/laundry-module/laundry-system-parameter/laundry-asset-type/laundry-asset-type.component';
import { CaptureLaundryAssetTypeComponent } from './components/laundry-module/laundry-system-parameter/laundry-asset-type/capture-laundry-asset-type/capture-laundry-asset-type.component';
import { LaundryBatchesComponent } from './components/laundry-module/laundry-batches/laundry-batches.component';
import { KitchenModuleComponent } from './components/kitchen-module/kitchen-module.component';
import { KitchenDashboardComponent } from './components/kitchen-module/kitchen-dashboard/kitchen-dashboard.component';
import { KitchenSystemParameterComponent } from './components/kitchen-module/kitchen-system-parameter/kitchen-system-parameter.component';
import { KitchenMenuTypeComponent } from './components/kitchen-module/kitchen-system-parameter/kitchen-menu-type/kitchen-menu-type.component';
import { CaptureKitchenMenuTypeComponent } from './components/kitchen-module/kitchen-system-parameter/kitchen-menu-type/capture-kitchen-menu-type/capture-kitchen-menu-type.component';
import { KitchenQuantityTypeComponent } from './components/kitchen-module/kitchen-system-parameter/kitchen-quantity-type/kitchen-quantity-type.component';
import { CaptureKitchenQuantityComponent } from './components/kitchen-module/kitchen-system-parameter/kitchen-quantity-type/capture-kitchen-quantity/capture-kitchen-quantity.component';
import { KitchenInventoryCategoryComponent } from './components/kitchen-module/kitchen-system-parameter/kitchen-inventory-category/kitchen-inventory-category.component';
import { CaptureKitchenInventoryCategoryComponent } from './components/kitchen-module/kitchen-system-parameter/kitchen-inventory-category/capture-kitchen-inventory-category/capture-kitchen-inventory-category.component';
import { KitchenHomeComponent } from './components/kitchen-module/kitchen-home/kitchen-home.component';
import { MotuaryDashboardComponent } from './components/motuary-module/motuary-dashboard/motuary-dashboard.component';

import { KitchenTaskComponent } from './components/kitchen-module/kitchen-system-parameter/kitchen-task/kitchen-task.component';
import { CaptureKitchenTasksComponent } from './components/kitchen-module/kitchen-system-parameter/kitchen-task/capture-kitchen-tasks/capture-kitchen-tasks.component';
import { KitchenDutyRoasterComponent } from './components/kitchen-module/kitchen-duty-roaster/kitchen-duty-roaster.component';
import { CaptureDutyRoasterComponent } from './components/kitchen-module/kitchen-duty-roaster/capture-duty-roaster/capture-duty-roaster.component';
import { KitchenPaymentTypeComponent } from './components/kitchen-module/kitchen-system-parameter/kitchen-payment-type/kitchen-payment-type.component';
import { CaptureKitchenPaymentTypeComponent } from './components/kitchen-module/kitchen-system-parameter/kitchen-payment-type/capture-kitchen-payment-type/capture-kitchen-payment-type.component';
import { KitchenTicketsComponent } from './components/kitchen-module/kitchen-tickets/kitchen-tickets.component';
import { CaptureKitchenTicketsComponent } from './components/kitchen-module/kitchen-tickets/capture-kitchen-tickets/capture-kitchen-tickets.component';
import { KitchenDiertaryRequirementsComponent } from './components/kitchen-module/kitchen-diertary-requirements/kitchen-diertary-requirements.component';
import { CaptureDietaryRequirementsComponent } from './components/kitchen-module/kitchen-diertary-requirements/capture-dietary-requirements/capture-dietary-requirements.component';
import { KitchenPurchasesComponent } from './components/kitchen-module/kitchen-purchases/kitchen-purchases.component';
import { DietaryModuleComponent } from './components/dietary-module/dietary-module.component';
import { DietaryHomeComponent } from './components/dietary-module/dietary-home/dietary-home.component';
import { CaptureKitchenPurchaseComponent } from './components/kitchen-module/kitchen-purchases/capture-kitchen-purchase/capture-kitchen-purchase.component';
import { KitchenInventoryComponent } from './components/kitchen-module/kitchen-inventory/kitchen-inventory.component';
import { KitchenInventoryOutComponent } from './components/kitchen-module/kitchen-inventory-out/kitchen-inventory-out.component';
import { CaptureKitchenInventoryOutComponent } from './components/kitchen-module/kitchen-inventory-out/capture-kitchen-inventory-out/capture-kitchen-inventory-out.component';
import { CaptureKitchenInventoryInComponent } from './components/kitchen-module/kitchen-inventory-in/capture-kitchen-inventory-in/capture-kitchen-inventory-in.component';
import { KitchenInventoryInComponent } from './components/kitchen-module/kitchen-inventory-in/kitchen-inventory-in.component';
import { KitchenInventoryTypeComponent } from './components/kitchen-module/kitchen-system-parameter/kitchen-inventory-type/kitchen-inventory-type.component';
import { CaptureKitchenInventoryTypeComponent } from './components/kitchen-module/kitchen-system-parameter/kitchen-inventory-type/capture-kitchen-inventory-type/capture-kitchen-inventory-type.component';
import { KitchenSalesComponent } from './components/kitchen-module/kitchen-sales/kitchen-sales.component';
import { CaptureKitchenSalesComponent } from './components/kitchen-module/kitchen-sales/capture-kitchen-sales/capture-kitchen-sales.component';
import { KitchenOrderLocationComponent } from './components/kitchen-module/kitchen-system-parameter/kitchen-order-location/kitchen-order-location.component';
import { CaptureKitchenOrderLocationComponent } from './components/kitchen-module/kitchen-system-parameter/kitchen-order-location/capture-kitchen-order-location/capture-kitchen-order-location.component';
import { KitchenTransactionsComponent } from './components/kitchen-module/kitchen-transactions/kitchen-transactions.component';
import { KitchenCreditTransactionsComponent } from './components/kitchen-module/kitchen-transactions/kitchen-credit-transactions/kitchen-credit-transactions.component';
import { KitchenFoodRequestsComponent } from './components/kitchen-module/kitchen-food-requests/kitchen-food-requests.component';
import { CaptureKitchenFoodRequestComponent } from './components/kitchen-module/kitchen-food-requests/capture-kitchen-food-request/capture-kitchen-food-request.component';
import { InterpolationTestComponent } from './components/tutorials/interpolation-test/interpolation-test.component';
import { BindingTestComponent } from './components/tutorials/binding-test/binding-test.component';
import { TutorialsComponent } from './components/tutorials/tutorials.component';
import { ComponentInteractionComponent } from './components/tutorials/component-interaction/component-interaction.component';
import { TutorialsHomeComponent } from './components/tutorials/tutorials-home/tutorials-home.component';
import { EmployeeModuleComponent } from './components/employee-module/employee-module.component';
import { EmployeeHomeComponent } from './components/employee-module/employee-home/employee-home.component';
import { EmployeeComponent } from './components/employee-module/employee/employee.component';
import { BankComponent } from './components/employee-module/bank/bank.component';
import { BranchesComponent } from './components/employee-module/branches/branches.component';
import { CaptureBankComponent } from './components/employee-module/bank/capture-bank/capture-bank.component';
import { CaptureBranchComponent } from './components/employee-module/branches/capture-branch/capture-branch.component';
import { CaptureEmployeeComponent } from './components/employee-module/employee/capture-employee/capture-employee.component';
import { StudentUserComponent } from './components/student-user/student-user.component';
import { StudentComponent } from './components/student-user/student/student.component';
import { CaptureStudentComponent } from './components/student-user/student/capture-student/capture-student.component';
import { StudentHomeComponent } from './components/student-user/student-home/student-home.component';
import { InstitutionComponent } from './components/student-user/institution/institution.component';
import { CaptureInstitutionComponent } from './components/student-user/institution/capture-institution/capture-institution.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { DocumentUploaderComponent } from './provider/document-uploader/document-uploader.component';
import { StudentUserParametersComponent } from './components/student-user/student-user-parameters/student-user-parameters.component';
import { AreasOfInterestComponent } from './components/student-user/student-user-parameters/areas-of-interest/areas-of-interest.component';
import { CaptureAreasOfInterestComponent } from './components/student-user/student-user-parameters/areas-of-interest/capture-areas-of-interest/capture-areas-of-interest.component';
import { CountriesListComponent } from './components/student-user/student-user-parameters/countries-list/countries-list.component';
import { ProgramsComponent } from './components/student-user/student-user-parameters/programs/programs.component';
import { CaptureProgramsComponent } from './components/student-user/student-user-parameters/programs/capture-programs/capture-programs.component';
import { ProvinceComponent } from './components/student-user/student-user-parameters/province/province.component';
import { CaptureProvinceComponent } from './components/student-user/student-user-parameters/province/capture-province/capture-province.component';
import { AuthMainComponent } from './auth/auth-main/auth-main.component';


const routes: Routes = [
    {
        path: 'home',
        component: AuthMainComponent
    },
    {
        path: 'user',
        component: UserComponent
    },
    {
        path: 'pm',
        component: PmComponent
    },
    {
        path: 'admin',
        component: AdminComponent
    },
    {
        path: 'auth/login',
        component: LoginComponentAuth
    },
    {
        path: 'signup',
        component: RegisterComponentAuth
    },
    {
        path: '',
        redirectTo: 'home',
        pathMatch: 'full'
    },
    {
        path: 'signed',
        component: HomeComponent
    },

   // { path: '', component: LoginComponent },
  //  { path: 'register', component: RegisterComponent },

    {
        path: 'mortuary', component: MotuaryModuleComponent, children: [
        { path: '', component: MotuaryHomeComponent },
        // { path: 'sys-params', component: SystemParameterComponent },
        // { path: 'capture-deceased', component: CaptureDeceasedComponent },
        // { path: 'autopsy', component: PostMotermComponent },
        // { path: 'collection', component: DeceasedCollectionComponent },
        // { path: 'sys-params', component: SystemParameterComponent },
        // { path: 'mortuary-dashboard', component: MotuaryDashboardComponent },
        // {
        //   path: 'sys-params', component: SystemParameterComponent, children: [
        //     { path: 'rooms', component: MotuaryRoomsComponent },
        //     { path: 'shelves', component: MotuaryShelvesComponent }
        //   ]
        // }
      ]
    },
    {
      path: 'laundry', component: LaundryModuleComponent, children: [
        { path: '', component: LaundryHomeComponent },
        // { path: 'dashboard', component: LaundryDashboardComponent },
        // { path: 'laundry-batches', component: LaundryBatchesComponent },
        // { path: 'laundry-out', component: LaundryOutComponent },
        // { path: 'laundry-in', component: LaundryInComponent },
        // {
        //   path: 'sys-params', component: LaundrySystemParameterComponent, children: [
        //     { path: 'assets', component: LaundryAssetsComponent },
        //     { path: 'assetType', component: LaundryAssetTypeComponent }
        //   ]
        // }
      ]
    },
    {
      path: 'kitchen', component: KitchenModuleComponent, children: [
        { path: '', component: KitchenHomeComponent },
        // { path: 'dashboard', component: KitchenDashboardComponent },
        // { path: 'sales', component: KitchenSalesComponent },
        // { path: 'duty-roaster', component: KitchenDutyRoasterComponent },
        // { path: 'tickets', component: KitchenTicketsComponent },
        // {
        //   path: 'inventory', component: KitchenInventoryComponent, children: [
        //     { path: 'purchases', component: KitchenPurchasesComponent },
        //     { path: 'inventory-out', component: KitchenInventoryOutComponent },
        //     { path: 'inventory-in', component: KitchenInventoryInComponent },
        //   ]
        // },
        // { path: 'food-requests', component: KitchenFoodRequestsComponent },
        // {
        //   path: 'transactions', component: KitchenTransactionsComponent, children: [
        //     { path: 'sales', component: KitchenSalesComponent },
        //     { path: 'creditSales', component: KitchenCreditTransactionsComponent },
        //     { path: 'tickets', component: KitchenTicketsComponent },
        //   ]
        // },
        // {
        //   path: 'sys-params', component: KitchenSystemParameterComponent, children: [
        //     { path: 'kitchenFoodMenu', component: KitchenMenuTypeComponent },
        //     { path: 'kitchenInventoryCategory', component: KitchenInventoryCategoryComponent },
        //     { path: 'kitchenPaymentType', component: KitchenPaymentTypeComponent },
        //     { path: 'kitchenTask', component: KitchenTaskComponent },
        //     { path: 'kitchenQuantityType', component: KitchenQuantityTypeComponent },
        //     { path: 'KitchenOrderLocation', component: KitchenOrderLocationComponent },
        //   ]
        // }
      ]
    },

    {
      path: 'dietary', component: DietaryModuleComponent, children: [
        { path: '', component: DietaryHomeComponent },
          // { path: 'home', component: DietaryHomeComponent },
          // { path: 'requirements', component: KitchenDiertaryRequirementsComponent }
        ]
      },
      {
        path: 'tutorials', component: TutorialsComponent, children: [
          { path: '', component: TutorialsHomeComponent },
          { path: 'interpolation', component: InterpolationTestComponent },
          { path: 'binding', component: BindingTestComponent },
          { path: 'comp-int', component: ComponentInteractionComponent }
        ]
      },
      {
        path: 'employees', component: EmployeeModuleComponent, children: [
          { path: '', component: EmployeeHomeComponent },
          { path: 'employees', component: EmployeeComponent },
          { path: 'banks', component: BankComponent },
          { path: 'branches', component: BranchesComponent }
        ]
      },
      
    {
      path: 'student-user', component: StudentUserComponent, children: [
        { path: '', component: StudentHomeComponent }, 
        { path: 'student', component: StudentComponent },
        { path: 'institution', component: InstitutionComponent },
  
        { path: 'student-user-parameters', component: StudentUserParametersComponent, children: [
            { path: 'areas-of-interest', component: AreasOfInterestComponent },
           { path: 'countries', component: CountriesListComponent },
           { path: 'programs', component: ProgramsComponent },
           { path: 'province', component: ProvinceComponent },
          ]
        }
      ]
    }
];

@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
})
export class AppRoutingModule { }

export const routingComponents = [
    MotuaryModuleComponent,
    CaptureDeceasedComponent,
    CapturePersonalInformationComponent,
    CaptureDeathInformationComponent,
    CaptureNextOfKinComponent,
    AssignShelfComponent,
    PostMotermComponent,
    CapturePostMotermComponent,
    CaptureCollectionInformationComponent,
    SystemParameterComponent,
    MotuaryRoomsComponent,
    CaptureMotuaryRoomComponent,
    DocumentUploaderComponent,
    MotuaryShelvesComponent,
    CaptureMortuaryShelfComponent,
    DocumentViewerComponent,
    CaptureInstructionsComponent,
    MotuaryInhabitantsComponent,
    ConfirmInformationComponent,
    DeceasedCollectionComponent,
    HomeComponent,
    LaundryModuleComponent,
    MotuaryHomeComponent,
    LaundryHomeComponent,
    LaundryDashboardComponent,
    LaundryOutComponent,
    CaptureLaundryOutComponent,
    CaptureLaundryInComponent,
    LaundryInComponent,
    LaundrySystemParameterComponent,
    LaundryAssetsComponent,
    CaptureLaundryAssetComponent,
    LaundryAssetTypeComponent,
    CaptureLaundryAssetTypeComponent,
    LaundryBatchesComponent,
    KitchenHomeComponent,
    KitchenModuleComponent,
    KitchenDashboardComponent,
    KitchenSystemParameterComponent,
    KitchenMenuTypeComponent,
    CaptureKitchenMenuTypeComponent,
    KitchenQuantityTypeComponent,
    CaptureKitchenQuantityComponent,
    KitchenInventoryCategoryComponent,
    CaptureKitchenInventoryCategoryComponent,
    MotuaryDashboardComponent,
    KitchenTaskComponent,
    CaptureKitchenTasksComponent,
    KitchenDutyRoasterComponent,
    CaptureDutyRoasterComponent,
    KitchenPaymentTypeComponent,
    CaptureKitchenPaymentTypeComponent,
    KitchenTicketsComponent,
    CaptureKitchenTicketsComponent,
    KitchenDiertaryRequirementsComponent,
    CaptureDietaryRequirementsComponent,
    DietaryModuleComponent,
    DietaryHomeComponent,
    KitchenPurchasesComponent,
    CaptureKitchenPurchaseComponent,
    KitchenInventoryComponent,
    KitchenInventoryOutComponent,
    CaptureKitchenInventoryOutComponent,
    CaptureKitchenInventoryInComponent,
    KitchenInventoryInComponent,
    KitchenInventoryTypeComponent,
    CaptureKitchenInventoryTypeComponent,
    KitchenSalesComponent,
    CaptureKitchenSalesComponent,
    KitchenOrderLocationComponent,
    CaptureKitchenOrderLocationComponent,
    KitchenTransactionsComponent,
    KitchenCreditTransactionsComponent,
    KitchenFoodRequestsComponent,
    CaptureKitchenFoodRequestComponent,
    InterpolationTestComponent,
    BindingTestComponent,
    TutorialsComponent,
    ComponentInteractionComponent,
    TutorialsHomeComponent,
    EmployeeModuleComponent,
    EmployeeHomeComponent,
    EmployeeComponent,
    BankComponent,
    BranchesComponent,
    CaptureBankComponent,
    CaptureBranchComponent,
    CaptureEmployeeComponent,
    StudentUserComponent,
    StudentComponent,
    CaptureStudentComponent,
    StudentHomeComponent,
    InstitutionComponent,
    CaptureInstitutionComponent,
    RegisterComponent,
    LoginComponent,
    LoginComponentAuth,
    UserComponent,
    RegisterComponentAuth,
    HomeComponent,
    AdminComponent,
    PmComponent,
    HomeComponentAuth,
    StudentUserParametersComponent,
    AreasOfInterestComponent,
    CaptureAreasOfInterestComponent,
    StudentUserParametersComponent,
    CountriesListComponent,
    ProgramsComponent,
    CaptureProgramsComponent,
    ProvinceComponent,
    CaptureProvinceComponent,
    AuthMainComponent
]
