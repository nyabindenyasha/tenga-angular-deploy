import { Component, OnInit } from '@angular/core';
import { User } from '../model/user';
import { Router } from '@angular/router';
import { UserReg } from '../model/user-reg';
import { AuthService } from '../auth/auth/auth.service';
import { TokenStorageService } from '../auth/auth/token-storage.service';
import { AuthLoginInfo } from '../auth/auth/login-info';


@Component({
  selector: 'app-login',
    templateUrl: './login.component.html',
    styleUrls: ['./login.component.scss'],
})
export class LoginComponent implements OnInit {

  submitted = false;
  registered = true;
  userModel = new User('', '');
  regUserModel = new UserReg('','','','');

  // form: any = {};
  // isLoggedIn = false;
  // isLoginFailed = false;
  // errorMessage = '';
  // roles: string[] = [];
  // private loginInfo: AuthLoginInfo;

  //constructor(private router: Router, private authService: AuthService, private tokenStorage: TokenStorageService) { }
  constructor(private router: Router) { }

   ngOnInit() {
  //   if (this.tokenStorage.getToken()) {
  //     this.isLoggedIn = true;
  //     this.roles = this.tokenStorage.getAuthorities();
  //   }
   }


  onLoginSubmit(){
    this.submitted = true;
    console.log(this.userModel);
    if(this.userModel.username == "nyasha" && this.userModel.password=="nyasha")
       this.router.navigate(['/signed']);
    else
       alert("Incorrect username and password");
       this.submitted = false;
  }

  // onLoginSubmit() {
  //   console.log(this.form);

  //   this.loginInfo = new AuthLoginInfo(
  //     this.form.username,
  //     this.form.password);

  //   this.authService.attemptAuth(this.loginInfo).subscribe(
  //     data => {
  //       this.tokenStorage.saveToken(data.accessToken);
  //       this.tokenStorage.saveUsername(data.username);
  //       this.tokenStorage.saveAuthorities(data.authorities);

  //       this.isLoginFailed = false;
  //       this.isLoggedIn = true;
  //       this.roles = this.tokenStorage.getAuthorities();
  //       this.reloadPage();
  //     },
  //     error => {
  //       console.log(error);
  //       this.errorMessage = error.error.message;
  //       this.isLoginFailed = true;
  //     }
  //   );
  // }

  // reloadPage() {
  //   window.location.reload();
  // }

  onRegisterSubmit(){
    this.submitted = true;
    console.log(this.userModel);

  }

  registeredProcess(){
    console.log("i was clicked")
    this.registered = !this.registered;
  }
}
