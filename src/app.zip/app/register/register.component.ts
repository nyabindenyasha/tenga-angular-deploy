import { Component, OnInit, Input } from '@angular/core';
import { RegisterUser } from '../Model/register-user';
import { Validation } from '../provider/validation/validation';
import { ValidationType } from '../provider/validation/validation-type.enum';
import { UserReg } from '../model/user-reg';


@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss']
})
export class RegisterComponent implements OnInit {

  validation: Validation;
  regUserModel = new UserReg('','','','');

  constructor() { }

  ngOnInit() {
    // if (this.regUserModel == null)
    //   this.regUserModel = new RegisterUser('','','','');
     //this.loadValidation();
  }
  registerUser() {
    this.validation.getError()
  }

  // loadValidation() {
  //   this.validation = new Validation();
  //   this.validation.addField({ name: 'username', display: 'Username', type: ValidationType.Required });
  //   this.validation.addField({ name: 'email', display: 'Email', type: ValidationType.Required });
  //   this.validation.addField({ name: 'password', display: 'Password', type: ValidationType.Required });
  //   this.validation.addField({ name: 'confirmPassword', display: 'Confirm Password', type: ValidationType.Required });
  // }
}
