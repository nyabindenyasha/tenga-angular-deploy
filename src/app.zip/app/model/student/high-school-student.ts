import { Countries } from "./countries";
import { Provinces } from "./provinces";
import { Institutions } from "./institutions";
import { AreasOfInterest } from "./areas-of-interest";
import { Programs } from "./programs";
import { Contacts } from "./contacts";
import { Addresses } from "./addresses";
import { Gender } from "../gender";

export class HighSchoolStudent {
  
    id: number; 
    firstName: string;
    lastName: string;
    email: string;
    contactId: number;
    contactPhoneNumber?: Contacts;
    addressId: number;
    addressNumber?: Addresses;
    addressStreet?: Addresses;
    genderId: number;
    genderName?: Gender;
    provinceId?: number;
    provinceName?: Provinces;
    institutionId: number;
    institutionName?: Institutions;
    areaOfInterestId: number;
    areaOfInterestName?: AreasOfInterest;
    programId:number;
    programName?: Programs;
    countryId: number;
    countryName?: Countries;
    cvURL: string;
    profilePictureURL: string;
    videoURL: string;
    experience: string;
    personalStatement: string;
    dateOfBirth: string;
    dateCreated: string;

}