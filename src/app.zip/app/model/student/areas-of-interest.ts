export class AreasOfInterest {
  
    id: number; 
    name: string;
    description: string;
}