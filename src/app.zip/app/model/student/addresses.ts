export class Addresses {
  
    id: number; 
   // street: string;
   // city: string;
    province: string;

    constructor(
        public street, 
        public city){
     }
    
}