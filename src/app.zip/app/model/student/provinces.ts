export class Provinces {
  
    id: number; 
    //name: string;
    countryId: number;

    constructor(
        public name
    ){}

}