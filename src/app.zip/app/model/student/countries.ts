export class Countries {

    id: number;
    code: string;
    areaCode: string;

    constructor(
        public name) {
    }

}