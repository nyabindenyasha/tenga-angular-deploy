export class Locations {
  
    id: number; 
    name: string;

}