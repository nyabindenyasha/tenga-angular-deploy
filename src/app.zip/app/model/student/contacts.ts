export class Contacts {
    id: number; 
    
    constructor(
       public phoneNumber){
    }
}