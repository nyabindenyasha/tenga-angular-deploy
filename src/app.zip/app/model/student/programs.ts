export class Programs {
  
    id: number; 
   // name: string;

    constructor(
        public name){
     }

}