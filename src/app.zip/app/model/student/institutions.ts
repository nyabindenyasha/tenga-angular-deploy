import { Contacts } from "./contacts";
import { Countries } from "./countries";
import { Provinces } from "./provinces";
import { Addresses } from "./addresses";
import { Locations } from "./locations";

export class Institutions {

    //id: number;
    //  name: string;
    //contact?: Contacts;
    contactId: number;
    phoneNumber?: Contacts;
    addressId: number;
    addressNumber?: Addresses;
    // address?: Addresses;
    addressStreet?: Addresses;
    // email: string;
    // countryId: number;
    countryName?: Countries;
    country?: Countries;
    // provinceId: number;
    provinceName?: Provinces;
    province?: Provinces;

    constructor(
        public id, public name, public email,
        public contact: Contacts,
        public address: Addresses,
        public provinceId: number,
        public countryId: number
    ) {
    }

}