import { Bank } from "./bank";

export class Branch{

    branchId: number;
    bankId: number;
    bankName?: Bank;
    branchName: String

}

