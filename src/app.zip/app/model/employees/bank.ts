export class Bank {
  
    bankId: number; 
    bankName: string;
    shortName: string
}