export class MaritalStatus{
    
    id: number;
    description: string
}