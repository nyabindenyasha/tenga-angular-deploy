import { Bank } from "./bank";
import { Branch } from "./branch";
import { Gender } from "../mortuary/gender";
import { MaritalStatus } from "./marital-status";

export class Employee {

    adress: string;
    bankId: number;
    bankName?: Bank;
    branchId: number;
    branchName?: Branch;
    created: string;
    d_o_b: string;
    email: string;
    genderId: number;
    genderName?: Gender;
    id: number;
    maritalStatusId: number;
    maritalStatusName?: MaritalStatus;
    name: string;
    phoneNumber: string;
    surname: string
}