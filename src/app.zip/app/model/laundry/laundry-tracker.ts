export class laundryTracker{
    id:number;
    cleanQuantity: number;
    dirtyQuantity: number;
    issuedQuantity:number;
    assetTypeId: number;

    constructor(){
        this.cleanQuantity = 0;
        this.dirtyQuantity = 0;
        this.issuedQuantity = 0;
    }
}