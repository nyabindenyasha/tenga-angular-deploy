export class LaundryAssetType {
    id : number;
    name : string
}