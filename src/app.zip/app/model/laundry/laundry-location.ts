export enum LaundryLocation {
    Ward = 1,
    Laundry,
    Obsolete,
    Donated
}

export class LaundryLocationHelper{
    public static get(location: LaundryLocation):string{
        switch(location){
            case 1: return 'Ward';
            case 2: return 'Laundry';
            case 3: return 'Obsolete';
            case 4: return 'Donated';
        }
    }
}