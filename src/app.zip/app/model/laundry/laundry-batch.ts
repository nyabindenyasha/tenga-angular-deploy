import { LaundryIn } from "./laundryIn";
import { LaundryOut } from "./laundry-out";
import { LaundryAssetType } from "./laundry-asset-type";


export class LaundryBatch {
    afcLaundryInList: LaundryIn[];
    laundryOut?: LaundryOut;
    assetTypeId: number;
    dateCreated: string;
    dateModified: string;
    id: number;
    isTaken: boolean;
    locationId: number;
    location?: string;
    assetTypeName?:LaundryAssetType;
    quantity: number;
    taken: boolean;
}