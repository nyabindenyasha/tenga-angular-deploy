import { LaundryAssetType } from './laundry-asset-type';
export class LaundryAsset {
	id: number;
	assetTypeId: number;
	assetType?: LaundryAssetType;
	quantity: number;
	dateCreated: string;
}