import { LaundryAssetType } from "./laundry-asset-type";

export class LaundryOut{
    batchId:number;
    dateCreated:number;
    id:number;
    quantity:number;
    username:string;
    assetTypeId: number;
    locationId: number;
    assetType?: LaundryAssetType;

    constructor(quantity?:number){
        this.quantity = quantity;
    }
}