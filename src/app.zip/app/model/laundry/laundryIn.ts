export class LaundryIn{
    batchId: number;
    dateCreated: string;
    id: number;
    quantity: number;
    username: string;
}