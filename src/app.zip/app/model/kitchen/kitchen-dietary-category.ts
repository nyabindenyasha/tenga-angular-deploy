export class KitchenDietaryCategory{
    id:number;
    name: string;
}