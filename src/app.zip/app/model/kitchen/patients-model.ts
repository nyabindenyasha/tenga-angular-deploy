import { KitchenDietaryRequirements } from "./kitchen-dietary-requirements";

export class PatientModel {
    id: number;
    fullName: string;
    dateCreated: Date;
    afcDietaryRequirementsList?: Array<KitchenDietaryRequirements>;
}