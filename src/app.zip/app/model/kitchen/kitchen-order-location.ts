export class KitchenOrderLocation {
    id: number;
    name: string;
}
