import { KitchenInventoryCategory } from './kitchen-inventory-category';
import { KitchenFoodRequest } from './kitchen-food-request';
export class KitchenInventoryOut {
    id: number;
    quantity: number;
    dateCreated: Date;
    categoryId: number;
    categoryName?: KitchenInventoryCategory;
    foodRequestId: number;
    requestUsername?: KitchenFoodRequest;
    category?: KitchenInventoryCategory;
}