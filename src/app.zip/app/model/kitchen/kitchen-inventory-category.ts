import {QuantityTypes } from 'src/app/model/kitchen/quantityTypes';
import {KitchenInventoryType } from 'src/app/model/kitchen/kitchen-inventory-type';
export class KitchenInventoryCategory{
    id : number;
    name : string;
    quantityTypeid : number;
    quantityTypeName?:QuantityTypes;
    typeId : number;
    typeName?:KitchenInventoryType
}