import { KitchenFoodMenu } from "./kitchen-food-menu";
import { KitchenDietaryCategory } from "./kitchen-dietary-category";

export class KitchenDietaryRequirements{
    id:number;
    patientId: number;
    patient?: any;
    foodMenuId: number;
    foodMenu?: KitchenFoodMenu;
    categoryId: number;
    category?: KitchenDietaryCategory;
    dateCreated: Date;
}