export class KitchenTasks{
    id : number;
    name : string;
}