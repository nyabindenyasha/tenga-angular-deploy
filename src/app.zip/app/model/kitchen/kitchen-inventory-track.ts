export class InventoryTrack{
    id : number;
    issuedQuantity : number;
    storageQuantity : number;
    thresholdQuantity : number;
    categoryId : number;
}