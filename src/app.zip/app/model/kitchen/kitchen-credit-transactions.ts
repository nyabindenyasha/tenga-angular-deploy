import { KitchenStaff } from 'src/app/model/kitchen/kitchen-staff';
import { KitchenSales } from 'src/app/model/kitchen/kitchen-sales'
export class KitchenCreditTransactions{
    id : number;
    isPaid : boolean;
    dateCreated : Date;
    dateModified : Date;
    kitchenSalesId : number;
    amount? : KitchenSales;
    foodItem? : KitchenSales;
    staffId : number;
    staffName? : KitchenStaff;
    active : boolean
}


