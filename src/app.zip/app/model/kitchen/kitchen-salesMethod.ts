export enum salesMethod {
    ticket=1,
    credit
}
