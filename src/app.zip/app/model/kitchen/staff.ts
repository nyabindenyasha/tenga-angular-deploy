export class kitcheinStaff{
  id:number;
  username:string;
  password: string;
  dateCreated:Date;
  isAvailable: boolean;
  jobRoleId: number;
}