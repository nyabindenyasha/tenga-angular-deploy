export class KitchenInventoryType{
    id : number;
    name : string
}