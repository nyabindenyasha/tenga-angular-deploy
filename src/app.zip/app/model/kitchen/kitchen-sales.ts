import { PaymentType } from "./kitchen-payment-type";
import { KitchenFoodRequest } from "./kitchen-food-request";
import { KitchenFoodMenu } from "./kitchen-food-menu";


export class KitchenSales {
    id: number;
    dateCreated: string;
    foodRequestId: number;
    paymentType: number;
    foodRequest?: KitchenFoodRequest;
    paymentTypeId: number;
    buyerId: number;
    foodMenuId: number;
    foodMenu?: KitchenFoodMenu;
    ticketNumber: string;
    foodName: string;
    paymentTypeName?: PaymentType;
    cost: number;

}