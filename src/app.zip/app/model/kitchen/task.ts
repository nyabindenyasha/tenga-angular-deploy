export class kitchenTask{
    id:number;
    name:string;
}