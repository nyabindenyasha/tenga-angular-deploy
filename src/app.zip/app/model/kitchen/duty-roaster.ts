import { kitchenTask } from "./task";
import { kitcheinStaff } from "./staff";

export class dutyRoaster{
    id:number;
    taskId:number;
    staffId:number;
    kitchein_task ?:kitchenTask;
    kitchein_staff ?:kitcheinStaff;
}