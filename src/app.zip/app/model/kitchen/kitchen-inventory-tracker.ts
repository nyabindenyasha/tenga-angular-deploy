export class InventoryTracker{
    id: number;
    issuedQuantity: number;
    storageQuantity: number;
    thresholdQuantity: number;
    categoryId: number;

    constructor(){
        this.storageQuantity = 0;
        this.issuedQuantity = 0;
    }
}