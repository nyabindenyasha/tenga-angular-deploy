export class QuantityTypes {
id:number;
name:string;
}
