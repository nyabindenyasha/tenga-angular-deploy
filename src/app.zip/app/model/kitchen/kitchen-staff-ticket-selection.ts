import { KitchenStaff } from "./kitchen-staff";

export class KitchenStaffTicketSelection extends KitchenStaff{
    buyTicket?: boolean;
}