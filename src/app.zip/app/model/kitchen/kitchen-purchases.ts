import {KitchenInventoryCategory} from './kitchen-inventory-category'
export class KitchenPurchases{
    
    id : number;
    quantity : number;
    cost : number;
    dateCreated : Date;
    dateModified : Date;
    categoryId : number;
    categoryName? : KitchenInventoryCategory
    processingId : number
    process? : string

}
