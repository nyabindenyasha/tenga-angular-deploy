export class FoodRequestStatus{
    id : number;
    name : string;
}