import { KitchenStaff } from './kitchen-staff';
export class KitchenTickets {
    id:number;
    dateCreated:string;
    dateModified:string;  
    isUsed: boolean;
    staffId:number;
    staffName?:KitchenStaff;
    ticketNumber: string;   
    }