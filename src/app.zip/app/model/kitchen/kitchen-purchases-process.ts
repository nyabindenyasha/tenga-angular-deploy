export enum KitchenPurchasesProcess {
    request = 1,
    approval,
    collection,
    reject,
    delivered
}

export class KitchenPurchasesProcessHelper {
    public static get(process: KitchenPurchasesProcess): string {
        switch (process) {
            case 1: return 'Request';
            case 2: return 'Approval';
            case 3: return 'Collection';
            case 4: return 'Reject';
            case 5: return 'Delivered'
        }
    }
}