import { KitchenFoodMenu } from 'src/app/model/kitchen/kitchen-food-menu';
import { KitchenOrderLocation } from 'src/app/model/kitchen/kitchen-order-location';
import { KitchenFoodRequestStatus } from 'src/app/model/kitchen/kitchen-food-request-status';

export class KitchenFoodRequest{
    id : number;
    username : string;
    numberOfOrders : number;
    dateCreated : Date;
    dateModified : Date;
    statusId : number;
    status:KitchenFoodRequestStatus;
    foodMenuId : number;
    foodMenuItem?:KitchenFoodMenu;
    orderLocationId : number;
    location:KitchenOrderLocation;
}