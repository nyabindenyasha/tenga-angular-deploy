import { KitchenInventoryOut } from "./kitchen-inventory-out";
import { KitchenInventoryCategory } from "./kitchen-inventory-category";

export class KitchenInventoryIn{
    id: number;
    quantity: number;
    dateCreated: Date;
    category?: KitchenInventoryCategory;
    kitchenInventoryOutId: number;
    kitchenInventoryOut: KitchenInventoryOut;
}