export class KitchenStaff {
    id: number;
    username: string;
    password: string;
    dateCreated
    isAvailable: boolean;
    jobRoleId: boolean;
}
