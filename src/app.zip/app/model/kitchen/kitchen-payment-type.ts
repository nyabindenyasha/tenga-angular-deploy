export class PaymentType{
    id : number;
    name : string;
}