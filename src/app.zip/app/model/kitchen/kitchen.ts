import { KitchenInventoryCategory } from 'src/app/model/kitchen/kitchen-inventory-category';
export class Kitchen{
    id: number;
    categoryId: number;
    categoryName?: KitchenInventoryCategory;
    name: string;
    quantity: number;
    dateCreated: Date;

}