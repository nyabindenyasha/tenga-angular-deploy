export class KitchenFoodMenu{
    id:number;
    name: string;
    cost: number;
    isAvailable: string;
}