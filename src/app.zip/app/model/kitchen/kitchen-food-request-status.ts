export class KitchenFoodRequestStatus{
    id: number;
    name: string;
}
