export class LoginUser{
  
    constructor(
        username: string,
        password: string
    ){}

}