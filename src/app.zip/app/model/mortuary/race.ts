export class Race {
    raceId: number;
    raceName: string;
}