export class NextOfKin {
    contactInfo: string;
    deceasedId: number;
    deceasedNextOfKinId: number;
    fullName: string;
    relationshipId: number;
}