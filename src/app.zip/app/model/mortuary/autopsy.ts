import { Deceased } from "./deceased";

export class Autopsy {
    causeOfDeath: string;
    deceasedId: number;
    deceasedID?: Deceased;
    postMortemId: number;
    timeOfDeath: string;
    userId: number;
}