
export const rooms = [{ id: 1, roomNumber: 1, roomName: "room1", description: "dead people", isActive: 0 }, { id: 2, roomNumber: 2, roomName: "room2", description: "dead people", isActive: 1 }];