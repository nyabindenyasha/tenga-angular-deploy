export class Relationship{
    relationshipId: number;
    relationshipDescription: string;
}