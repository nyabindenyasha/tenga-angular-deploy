import { MortuaryShelf } from "./mortuary-shelf";

export class MortuaryRoom {
    afcMortuaryShelvesList: MortuaryShelf[]
    roomName: string;
    roomNumber: string;
    description: string;
}