import { NextOfKin } from "./nextOfKin";
import { MortuaryShelf } from "./mortuary-shelf";

export class Deceased {
    dateOfBirth: string;
    dateOfDeath: string;
    deceasedId: number;
    doctorId: number;
    genderId: number;
    genderName?: string;
    identificationnumber: string;
    location: string;
    plce_of_birth: string;
    processId: number;
    raceId: number;
    race?: string;
    firstName: string;
    lastName: string;
    nextOfKin?: NextOfKin;
    shelf?: MortuaryShelf;
    active : boolean
}

