export class MortuaryShelf {
    description	:string;
    isOccupied	:boolean;
    roomNumber	:string;
    shelfNumber	:string;
    
}
