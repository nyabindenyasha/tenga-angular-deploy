export class Collection {
    collectionDate: string;
    collectorFullName: string;
    collectorNationalIdNumber: string;
    deceasedCollectionId: number;
    documentDetailsId: number;
    deceasedId: number;
}