export class Doctor {
    doctorId: number;
    doctorName: string;
}