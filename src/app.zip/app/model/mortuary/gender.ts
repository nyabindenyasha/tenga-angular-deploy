export class Gender {
    genderId: number;
    genderDescription: string;
}